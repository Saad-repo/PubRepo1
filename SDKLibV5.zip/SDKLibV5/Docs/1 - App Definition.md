<title>Md2Html - 01 - App Definition</title>

Markdown to HTML Converter
================================
This app converts a given a Markdown file to an HTML document (1 file to 1 file conversion)


![IDescribeMyFunctionality](imgs/IDescFunc2.jpg)


01 - App Definition
======================================
* Md2Html converts MD files to HTML files using its predefined rules
* 

Use Cases
---------------------------------
1. Given an MD file --> generate a HTML file with proper rendering
2. When a TITLE tag is provided in the MarkDown content, it becomes the TITLE of the produced HTML doc
3. MarkDown content that is surrounded with triple tick marks is converted to content that is surrounded by the CODE tag
4. Once I issue a command with specific parameter values, I want to be able to run the same command with the same params in the future without having to type the same param values


Advantages of doing this
---------------------------------
* Control over how conversion takes places
* implementing certain conventions. ex. Copy to Clipboard button for each Code element
* preferred styling to certain tables


Features
---------------------------------
* Convert MD file to HTML
* Ability to add to the list of default input parameters
	* Each implementation class provides one or more default parameters for readily running one of its functionalities. The user is able to pick on of the available input parameters and quickly execute the implementation. Having the ability to add a new default input parameter allows user to repeat the same operation in the future.
* 

Potential Enhancements
---------------------------------

Currently the app relies on reflection to provide information about features of the system. This is great as it provides the most up-to-date info on system features. However, the code complexity/increased code maintenance concerns that come with using reflection is not that cool. It's might be a good idea to provide a Settings screen that provides a Button for updating a data source (SqLite is great candidate) to refresh system info. This can potentially improve the performance of the app. At this point the performance is fine. As more and more features get added things might change. This enhancement can be more necessary then.

