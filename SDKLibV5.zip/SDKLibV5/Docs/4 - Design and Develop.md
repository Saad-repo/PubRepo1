<title>Design and Develop</title>

Design and Develop
================================


Conventions
-------------------------
* Each implementation class is to have a static property of DescribeMyFunctionality<InputParamsBase> and named **Info**. 
  * Each implementation class **describes its functionality** inside the Info property
* Info property requires one or more FunctionalityInfo objects that have **unique names**. The name used for a FunctionalityInfo **must match the respective implementation method**.

