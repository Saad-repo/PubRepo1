*this doc might contain some programming related idealogical/philosophical statements*

1. Development is driven by clear and well documented "Requirements" -- *See MD files numbered 1 through 8*
	* So, no requirements, no code. This is a practice of PwDI -- *Programming with Documented Intent*
2. Each Implementation project has a respective Unit Test project named as in the following example. 
	* Example: 

```
Implementation Project Name: MyCoolClassLib
Implementation Class Name:   MyCoolClassImp

Test Project Name:           MyCoolClassLib_Tests
Test Class Name:             MyCoolClassImp_Tests
```

3. Make it a habit to start your journey from documentation section to the coding section


Each implementation class is to provide a static member that reveals the followings:
1. Overall description for what the class does
2. Individual description for each and every functionality provided by the class
3. Sample input parameters
	1. Hard-coded values
	2. File based values: ```SampleInputParams\{ClassName}.{FunctionalityName}.{TS or Seq#}.txt```
4. InputParams object might have properties with null values
	* Null properties are ignored
	* Parameters of some functionalities might require only some of the properties in the InputParams object

```C#
// known friend assemblies -- declared in Constants.cs for now
[assembly: InternalsVisibleTo("ConsoleApp1")]
[assembly: InternalsVisibleTo("SDKLibV5_Tests")]
[assembly: InternalsVisibleTo("WpfApp1")]
```


 DRAFT note: Reason for using the model of InputArgs -- ease of configurability and of changing input params to achieve a desired outcome


 The Workflow for adding a new functionality class
 -------------------------------------------
 1. Create a new ```public sealed class <classname>  : FunctionalityBase``` inside the Functionality folder.
 2. Add and implement the ```static Info``` property just like the other implementation classes. You can use the following code reference:

```C#
        #region IDescribeMyFunctionality
        private static DescribeMyFunctionality<InputParamsBase> _info;

        /// <summary>
        ///     Functionality Info
        /// </summary>
        internal static DescribeMyFunctionality<InputParamsBase> Info
        {
            get
            {
                if (_info is null)
                {
                    #region Class Functionality Definitions and sample inputs
                    var description = @"This class provides generic functionality";
                    var desc4Convert2Html = @"Displays documentation for all the functionality provided across implementation classes";
                    var desc4SearchFunctionality = @"Searches functionality documentation for the given keyword and returns matching Tabs and Button names";

                    FunctionalityInfo<InputParamsBase> funcCatalog = new("ShowFunctionalityCatalog", desc4Convert2Html,
                            new List<InputParams> { new InputParams() });
                    FunctionalityInfo<InputParamsBase> funcSearch = new("SearchCatalog", desc4SearchFunctionality,
                            new List<InputParams> { new InputParams { SearchKeyword = "Convert" } });

                    List<FunctionalityInfo<InputParamsBase>> functionalities = new()
                    {
                        funcCatalog,
                        funcSearch,
                    };
                    #endregion

                    _info = new DescribeMyFunctionality<InputParamsBase>(description, functionalities);
                }
                return _info;
            }
        }

        internal class InputParams : InputParamsBase
        {
            public string OwnerClassName { get; set; }
            public string SearchKeyword { get; set; }

            public InputParams() { }
        }
        #endregion

        #region Implementation
        // Notice there is one method for each registered functionality. And the name of each method must be same as the registered name
        internal string ShowFunctionalityCatalog(InputParams inputParams)
        {
            return "TODO: implement";
        }

        internal string SearchCatalog(InputParams inputParams)
        {
            return "TODO: implement";
        }

        #endregion
```






