<title>Plan for Implementation</title>

Plan for Implementation
================================


Ability to add to the list of default input parameters
---------------------------------------------------------
The application will have a folder containing files with the following naming pattern to expand the list of default parameters for the respective command/functionality:
Files in this folder should have this naming convention:
{ClassName}.{FunctionalityName}.{TS or Seq#}.txt

Candidates for the Folder Name
---------------------------------
* DefaultParams
* InputParams
* SampleInputParams


User Experience Considerations
-----------------------------
* A separate Button for saving the content of the current input parameters textbox can be provided.
* When clicked, the event handler should produce a file name adhering to the above naming conventions and saved to the InputParams folder
* 



