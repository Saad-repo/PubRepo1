﻿using System;
using System.IO;
using System.Security.Cryptography;

namespace FileHash
{
    class Program
    {
        static void Main(string[] args)
        {
            if (args.Length > 0 && !string.IsNullOrEmpty(args[0]))
            {
                var currDir = Environment.CurrentDirectory;
                if (args[0] == ".") // current dir
                {
                    args[0] = currDir;
                }
                else if (args[0] == "..") // parent dir
                {
                    args[0] = Path.GetDirectoryName(currDir);
                }

                Console.WriteLine("MD5 Hashes for files\r\n");
                // could be either a directory or a file
                if (File.Exists(args[0]))
                {
                    var bytesMD5 = MyTools.GetHashMD5(args[0]);
                    Console.WriteLine(Convert.ToBase64String(bytesMD5));
                }
                else if (Directory.Exists(args[0]))
                {
                    var files = Directory.GetFiles(args[0]);

                    foreach (var file in files)
                    {
                        var bytesMD5 = MyTools.GetHashMD5(file);
                        Console.WriteLine(Convert.ToBase64String(bytesMD5));
                    }
                }
                else
                {
                    Console.WriteLine($"File or directory '{args[0]}' not found.");
                }
            }
            else
                Console.WriteLine("Required param: Full path to a file or folder\r\n");

        }
    }

    public class MyTools
    {
        public static byte[] GetHashMD5(string fileName)
        {
            using var md5 = MD5.Create();
            using var stream = File.OpenRead(fileName);
            return md5.ComputeHash(stream);
        }

        public static string Base64Encode(string plainText)
        {
            var plainTextBytes = System.Text.Encoding.UTF8.GetBytes(plainText);
            return Convert.ToBase64String(plainTextBytes);
        }

        public static string Base64Decode(string base64EncodedData)
        {
            var base64EncodedBytes = Convert.FromBase64String(base64EncodedData);
            return System.Text.Encoding.UTF8.GetString(base64EncodedBytes);
        }
    }

}
