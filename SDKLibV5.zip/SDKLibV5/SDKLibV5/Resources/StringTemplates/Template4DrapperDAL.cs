﻿using Dapper;
using Microsoft.Data.Sqlite;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace SDKLibV5.{{{DBName}}}
{
    #region Dtos
{{{dtos}}}
    #endregion

    public sealed class SqLiteOps : FunctionalityBase
    {
{{{selectAllMethods}}}

        private System.Data.IDbConnection GetDbConnection(string fullPath)
        {
            return new SqliteConnection($"Data Source=\"{fullPath}\";");
        }
    }
}