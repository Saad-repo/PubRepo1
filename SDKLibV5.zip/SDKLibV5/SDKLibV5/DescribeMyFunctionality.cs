﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;

namespace SDKLibV5
{
    public abstract class FunctionalityBase { }

    /// <summary>
    ///     Interface for revealing description and sample input parameters for each functionality provided by the implementing class
    /// </summary>
    internal sealed class DescribeMyFunctionality<T>
        where T : InputParamsBase
    {
        public DescribeMyFunctionality()
        {

        }

        public DescribeMyFunctionality(string description, List<FunctionalityInfo<T>> functionalityInfo, DateTime dateCreated)
        {
            Description = description;
            Functionalities = functionalityInfo;
            CreatedDate = dateCreated;
        }

        /// <summary>
        ///     Provides a high level description for all the functionalities provided by the class
        /// </summary>
        internal string Description { get; private set; }
        internal DateTime CreatedDate { get; private set; }

        /// <summary>
        ///     Iterates over the functionalities in the <see cref="Functionalities"/> to provide concatenated <see cref="Description"/> and the predefined sample input parameters
        /// </summary>
        internal string DescribeAll(string ownerImplementationClassName)
        {
            var sb = new StringBuilder();
            sb.AppendLine($"{ownerImplementationClassName}");
            sb.AppendLine($"=========================================================");
            sb.AppendLine(Description);

            var funcsUnboxed = UnboxFuncs();
            foreach (var functionItem in funcsUnboxed.OrderBy(f => f.Name))
            {
                sb.AppendLine($"\r\n{functionItem.Name}");
                sb.AppendLine($"--------------------------\r\n{functionItem.Description}\r\nParameters---");
                sb.AppendLine("```Shell");
                int i = 1;
                foreach (var par in functionItem.Params)
                {
                    var prefix = string.Empty;

                    if (functionItem.Params.Count() > 1)
                        prefix = $"Sample Input Parameters #{i++}\r\n";
                    var t1 = prefix + par.ToString();
                    sb.AppendLine(t1);
                }
                sb.AppendLine("```");
            }

            Functionality.MarkDown2Html markDown2Html = new(sb.ToString());
            return markDown2Html.Md2Html(new Functionality.MarkDown2Html.InputParams { MdContent = sb.ToString() });
        }

        /// <summary>
        ///     List of Functionality objects for enumerating the tasks this class performs
        /// </summary>
        internal List<FunctionalityInfo<T>> Functionalities { get; private set; }

        internal IEnumerable<string> FunctionalyNames => Functionalities.Select(f => ((FunctionalityInfo<T>)f).Name);

        internal T GetSampleInput(string functionality)
        {
            if (Functionalities is null || !Functionalities.Any(f => ((FunctionalityInfo<T>)f).Name == functionality))
                return null;

            return ((FunctionalityInfo<T>)Functionalities.First(f => ((FunctionalityInfo<T>)f).Name == functionality)).GetNextSampleInputParams();
        }

        internal IEnumerable<T> GetSampleInputs(string functionality)
        {
            if (Functionalities is null || !Functionalities.Any(f => ((FunctionalityInfo<T>)f).Name == functionality))
                return null;

            return ((FunctionalityInfo<T>)Functionalities.First(f => ((FunctionalityInfo<T>)f).Name == functionality)).Params;
        }

        #region Misc Helper Methods

        internal static List<Type> GetAllFunctionalityTypes()
        {
            var assemblySDKLib = Assembly.Load(Constants.AssemblyName);
            return assemblySDKLib.GetTypes()
                                 .Where(t => t.FullName.StartsWith($"{Constants.AssemblyName}.Functionality")
                                          && t.BaseType == typeof(FunctionalityBase))
                                 .ToList();
        }

        private IEnumerable<FunctionalityInfo<T>> UnboxFuncs()
        {
            foreach (var item in Functionalities)
            {
                yield return (FunctionalityInfo<T>)item;
            }
        }

        #endregion
    }

    /// <summary>
    ///     Class for listing functionalities
    /// </summary>
    public class FunctionalityInfo<T>
        where T : InputParamsBase
    {
        public FunctionalityInfo(string functionalityName, string description, IEnumerable<T> parameters)
        {
            Name = functionalityName;
            Description = description;
            Params = parameters;
        }

        public string Name { get; private set; }

        /// <summary>
        ///     Provides description for this functionalities
        /// </summary>
        public string Description { get; private set; }

        public IEnumerable<T> Params { get; private set; }

        private static int _dx = 0;

        /// <summary>
        ///     Gets the next set of parameters for quick, ready execution
        /// </summary>
        /// <returns></returns>
        public T GetNextSampleInputParams()
        {
            return Params.ElementAt(_dx++ % Params.Count());
        }
    }

    /// <summary>
    ///     Class containing all the parameters needed for executing a functionality
    /// </summary>
    public abstract class InputParamsBase
    {
        public override string ToString()
        {
            var propInfos = this.GetType().GetProperties(System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Instance);
            StringBuilder sb = new();
            foreach (var prop in propInfos)
            {
                var val = prop.GetValue(this);

                if (val != null)
                    sb.AppendLine($"\t{prop.Name}: {val}");
            }

            return sb.ToString();
        }

        /// <summary>
        ///     Parses the passed string and converts it to an "Input Parameters" object
        /// </summary>
        /// <param name="inputStr">Input String</param>
        /// <returns>Input Parameter</returns>
        public static InputParamsBase FromString(string inputStr, InputParamsBase paramObj)
        {
            var propInfos = paramObj.GetType().GetProperties(System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Instance);
            bool removeComments = !inputStr.Contains("RemoveComments: False");
            var lines = inputStr.Split(new string[] { "\r\n" }, System.StringSplitOptions.None);

            StringBuilder sbMultiLineValue = new();
            bool isMultiLine = false;
            for (int i = 0; i < lines.Length; i++)
            {
                var line = lines[i];
                if (isMultiLine)
                {
                    sbMultiLineValue.AppendLine(line);
                    continue;
                }

                foreach (var prop in propInfos)
                {
                    if (line.Trim().StartsWith(prop.Name))
                    {
                        SetPropertyValue(prop, paramObj, removeComments, lines, ref i, ref line);
                    }
                }
            }

            return paramObj;
        }

        private static void SetPropertyValue(PropertyInfo prop, InputParamsBase obj, bool removeComments, string[] lines, ref int i, ref string line)
        {
            var value = line.Split($"{prop.Name}:")[1].Trim();
            value = StripOutComment(value);

            if (value.Contains(Constants.MultiLineIndicator))
            {
                Regex rgxParamLine = new("\t\\w+:\\s*");
                value = GetMultiLineInput(lines, rgxParamLine, ref i, ref line, value);
            }

            if (prop.PropertyType == typeof(int) || prop.PropertyType == typeof(int?))
                prop.SetValue(obj, int.Parse(value));
            else if (prop.PropertyType == typeof(bool) || prop.PropertyType == typeof(bool?))
                prop.SetValue(obj, bool.Parse(value));
            else
                prop.SetValue(obj, value);
        }

        private static string GetMultiLineInput(string[] lines, Regex rgxParamLine, ref int i, ref string line, string value)
        {
            StringBuilder sbMultiLineValue = new();
            sbMultiLineValue.AppendLine(value.Replace(Constants.MultiLineIndicator, ""));
            i++;
            bool nextParamLineReached = false;
            for (; i < lines.Length && !nextParamLineReached; i++)
            {
                line = StripOutComment(lines[i]);
                if (rgxParamLine.IsMatch(line))
                {
                    nextParamLineReached = true;
                    i--;
                    break;
                }
                sbMultiLineValue.AppendLine(line);
            }

            return sbMultiLineValue.ToString();
        }

        private static string StripOutComment(string value)
        {
            if (value.Contains(Constants.CommentIndicator))
                return value.Substring(0, value.IndexOf(Constants.CommentIndicator)).Trim();

            return value;
        }
    }
}