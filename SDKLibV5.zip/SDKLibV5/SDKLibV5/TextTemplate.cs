﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SDKLibV5
{
    /// <summary>
    ///     Simple text templating class
	///     Keywords to be replaced are between "StartChars" and "EndChars"
    /// </summary>
    internal class TextTemplate
    {
        private StringBuilder _templateText;
        private const string StartChars = "{{{";
        private const string EndChars = "}}}";

        public TextTemplate(string template)
        {
            _templateText = new StringBuilder(template);
        }

        public void Fill(Dictionary<string, string> tags)
        {
            foreach (var t in tags)
            {
                _templateText = _templateText.Replace($"{StartChars}{t.Key}{EndChars}", t.Value);
            }
        }

        public string GetText()
        {
            return _templateText.ToString();
        }
    }
}
