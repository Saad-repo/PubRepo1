﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace SDKLibV5.Functionality
{
    internal sealed class HTML : FunctionalityBase
    {
        #region IDescribeMyFunctionality
        private static DescribeMyFunctionality<InputParamsBase> _info;

        /// <summary>
        ///     Functionality Info
        /// </summary>
        internal static DescribeMyFunctionality<InputParamsBase> Info
        {
            get
            {
                if (_info is null)
                {
                    #region Class Functionality Definitions and sample inputs
                    var desc4Class = @"This class provides functions that either produces or manipulates HTML";
                    var desc4Classes2HtmlTables = @"Converts a given set of C# classes to nested HTML tables to provide a visual rendering that's easier on the eyes and mind than raw code";
                    var desc4Wrap = "Wraps a given partial HTML content in HTML page for rendering";

                    FunctionalityInfo<InputParamsBase> funcDataTable2Html = new(nameof(Classes2HtmlTables), desc4Classes2HtmlTables,
                        new List<InputParams> {
                            new InputParams(SDKLibV5.Constants.MultiLineIndicator + @"   
    public class RideTypeObj
    {
        public Category[] categories { get; set; }
        public Ride_Types[] ride_types { get; set; }
    }

    public class Category
    {
        public string[] ride_type_keys { get; set; }
        public string display_name { get; set; }
    }

    public class Ride_Types
    {
        public string display_name { get; set; }
        public string category_key { get; set; }
        public string image_url { get; set; }
        public Pricing_Details pricing_details { get; set; }
        public int seats { get; set; }
        public string ride_type { get; set; }
    }

    public class Pricing_Details
    {
        public int base_charge { get; set; }
        public int cost_per_mile { get; set; }
        public int cost_per_minute { get; set; }
        public int cost_minimum { get; set; }
        public int trust_and_service { get; set; }
        public string currency { get; set; }
        public int cancel_penalty_amount { get; set; }
    }

")  });



                    FunctionalityInfo<InputParamsBase> funcWrap = new(nameof(RenderPartialHTML), desc4Wrap,
                        new List<InputParams> {
                            new InputParams{ PartialHtml = SDKLibV5.Constants.MultiLineIndicator + @"    <div class=""postcell post-layout--right"">
        <div class=""s-prose js-post-body"" itemprop=""text"">
            <p><em>This is a possible duplicate of <a href=""https://stackoverflow.com/questions/3662506/set-the-default-date-of-wpf-date-picker-to-current-date"">Set the Default Date of WPF Date Picker to Current Date</a> but I have tried the code from the question and it doesn't work, hopefully I am missing something simple</em> </p>
            <p>OK as the question states, I want to display the current date when the view loads, however, I have the SelectedDate property bounded to a property of mine, and I dont think you can use ""Text"" because the property that I am binding to is a DateTime property. yes, I could do a convert in the model but XAML (I think) should be able to do this for me.</p>
            <p>OK I know what is the problem, the date is coming out ""01/01/0001"" because of course, its binding to my property which is defaulted to 01/01/0001, so I guess I will need to do some C# code in my property to say if its 01/01/0001, use DateTime.Now and if not, use the property.   </p>
            <p>The XAML</p>
<pre><code>    &lt;DatePicker HorizontalAlignment=""Left"" 
                DisplayDate=""{x:Static System:DateTime.Now}""
                SelectedDate=""{Binding AvailableFrom, Mode=TwoWay}""
                Margin=""139,58,0,0"" 
                VerticalAlignment=""Top"" 
                Width=""120""/&gt; 
</code></pre>
            <p>Am happy to delete this after if the big reps think it is a duplicate, </p>
            <p>What I did to resolve...</p>
<pre><code>     get
     {
         if (m_AvailableFrom == DateTime.MinValue)
             return DateTime.Now;
        return m_AvailableFrom;
     }
</code></pre>
            <p>Cheers for the help</p>
        </div>
        <div class=""mt24 mb12"">
            <div class=""post-taglist grid gs4 gsy fd-column"">
                <div class=""grid ps-relative"">
                    <a href=""/questions/tagged/c%23"" class=""post-tag"" title=""show questions tagged &#39;c#&#39;"" rel=""tag"">c#</a> <a href=""/questions/tagged/wpf"" class=""post-tag"" title=""show questions tagged &#39;wpf&#39;"" rel=""tag"">wpf</a> <a href=""/questions/tagged/xaml"" class=""post-tag"" title=""show questions tagged &#39;xaml&#39;"" rel=""tag"">xaml</a> <a href=""/questions/tagged/datepicker"" class=""post-tag"" title=""show questions tagged &#39;datepicker&#39;"" rel=""tag"">datepicker</a>
                </div>
            </div>
        </div>
</div>
" }  });

                    var desc4DataTable2HtmlTable = @"Converts a given tab delimited table to HTML table";
                    FunctionalityInfo<InputParamsBase> funcDataTable2HtmlTable = new(nameof(Data2HtmlTbl), desc4DataTable2HtmlTable,
                        new List<InputParams> {
                            new InputParams(SDKLibV5.Constants.MultiLineIndicator
+ @$"Data Type{'\t'}Property Name
string{'\t'}applicationName
string{'\t'}applicationVersion
string{'\t'}appVersionSignature
string{'\t'}callingApplication
string{'\t'}installationSignature
string{'\t'}messageId
string{'\t'}mobileClientId
string{'\t'}receipt
string{'\t'}userAgent
Credentials{'\t'}credentials
string{'\t'}accessToken
object{'\t'}accessTokenExpirationDate
Location{'\t'}from
Location{'\t'}to")  });


                    List<FunctionalityInfo<InputParamsBase>> functionalities = new()
                    {
                        funcDataTable2Html,
                        funcWrap,
                        funcDataTable2HtmlTable
                    };
                    #endregion

                    _info = new DescribeMyFunctionality<InputParamsBase>(desc4Class, functionalities, new DateTime(2021, 5, 10));
                }
                return _info;
            }
        }

        internal class InputParams : InputParamsBase
        {
            public string Data { get; set; } = null;
            public string PartialHtml { get; set; } = null;
            public InputParams() { }
            public InputParams(string dataTable)
            {
                Data = dataTable;
            }
        }
        #endregion

        #region Implementation
        private sealed class Constants
        {
            internal const string CommentChar = "//";
            internal const string CommandChar = ">";

            internal static string HTMLDocHeadTemplate = @"<!DOCTYPE html>
<html>
<head>
    <meta charset=""utf-8"" />
    <title>GetARide - Notes / Classes</title>

    <style>
        body {
            font-family: 'Lato', sans-serif;
            color: #757374;
            font-size: larger;
        }

        h2 {
            color: black;
        }

        li.happy {
            color: green;
        }

        /*  --------  table styles --------  */
        table {
            color: #333; /* Lighten up font color */
            font-family: Helvetica, Arial, sans-serif; /* Nicer font */
            width: 640px;
            border-collapse: collapse;
            border-spacing: 0;
        }

        td, th {
            border: 1px solid #CCC;
            height: 30px;
            text-align:left;
        }
        /* Make cells a bit taller */

        th {
            background: #F3F3F3; /* Light grey background */
            font-weight: bold; /* Make sure they're bold */
        }

        td {
            background: #FAFAFA; /* Lighter grey background */
            text-align: left;
        }

        tr:nth-child(even) td {
            background: #F1F1F1;
        }
        tr:nth-child(odd) td {
            background: #FEFEFE;
        }

        tr td:hover {
            background: #666;
            color: #FFF;
        }

        th {
            background: #45a3de;
            color: navy;
        }
        /*  eo--------  table styles --------  */
        
    </style>
</head>
";
        }



        internal string Data2HtmlTbl(InputParams inputParams)
        {
            StringBuilder sb = new("<table class=\"styled-table\"><thead>");
            string[] lines = inputParams.Data.ToLines();
            for (int i = 0; i < lines.Length; i++)
            {
                string[] cols = lines[i].Split('\t');
                sb.AppendLine("<tr>");
                if (i == 0)
                {
                    for (int j = 0; j < cols.Length; j++)
                    {
                        sb.AppendLine($"\t<th>{cols[j]}</th>");
                    }

                    sb.AppendLine("</tr></thead><tbody>");
                }
                else
                {
                    for (int j = 0; j < cols.Length; j++)
                    {
                        sb.AppendLine($"\t<td>{cols[j]}</td>");
                    }
                }

                sb.AppendLine("</tr>");
            }

            sb.AppendLine("</tbody></table>");
            return sb.ToString().WrapInHTML(MarkDown2Html.Constants.TableStyle1);
        }


        internal string RenderPartialHTML(InputParams inputParams)
        {
            return inputParams.PartialHtml.WrapInHTML();
        }

        internal string Classes2HtmlTables(InputParams input)
        {
            // TODO: implement comment removal logic
            string inCode = GetEnteredCode(input.Data);
            inCode = Regex.Replace(inCode, @"/\*.*[\r\n]*\$*/", "//---------------------", RegexOptions.Multiline);

            List<ClassDef> classes = new List<ClassDef>();

            string[] lines = inCode.Split(new string[] { "\r", "\n" }, StringSplitOptions.RemoveEmptyEntries);

            for (int i = 0; i < lines.Length; i++)
            {
                string line = lines[i];
                bool flagClsStart = false;
                string currClassName;
                ClassDef clsDef = null;

                if (line.Trim().StartsWith("//"))
                    continue;

                if (Regex.IsMatch(line, @"class\s+", RegexOptions.Singleline))
                {
                    flagClsStart = true;
                    currClassName = line.Split(new string[] { "class" }, StringSplitOptions.RemoveEmptyEntries)[1].Trim();

                    clsDef = new ClassDef()
                    {
                        Name = currClassName
                    };
                }

                while (lines[++i] != "}")
                {
                    line = lines[i];
                    if (line == "{" || line.Trim().StartsWith("//"))
                        continue;

                    line = line.Split(new string[] { "{", "=>" }, StringSplitOptions.RemoveEmptyEntries)[0].Trim();
                    string[] propertyInfo = line.Split(new char[] { ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries);

                    if (propertyInfo.Length == 3)
                    {
                        clsDef.Properties.Add(new PropertyDef(propertyInfo[0], propertyInfo[1], propertyInfo[2]));
                    }
                    else if (propertyInfo.Length == 2)
                    {
                        clsDef.Properties.Add(new PropertyDef(propertyInfo[0], propertyInfo[1]));
                    }
                }

                if (clsDef != null)
                    classes.Add(clsDef);
            }

            StringBuilder sbOut = new StringBuilder();

            sbOut.AppendLine(Constants.HTMLDocHeadTemplate + $"<body>\r\n<!-- Generated on {DateTime.Now} -->");

            foreach (var cls in classes)
                sbOut.AppendLine(cls.ToHTMLTable(true));

            sbOut.AppendLine("</body>\r\n</html>\r\n");

            // txtOutput.Text = sbOut.ToString();


            return Constants.HTMLDocHeadTemplate + $"<body>\r\n<!-- Generated on {DateTime.Now} -->" +

                ToLinkedHTMLTables(classes)
                +
            "</body>\r\n</html>\r\n";
        }

        private string GetEnteredCode(string input)
        {
            string[] origLines = input.Split(new string[] { "\r\n", "\n", "\r" }, StringSplitOptions.RemoveEmptyEntries);
            StringBuilder sbInputCode = new();
            for (int i = 0; i < origLines.Length; i++)
            {
                string line = origLines[i].Trim();

                if (!line.StartsWith("#") && !line.StartsWith(Constants.CommentChar) && !line.StartsWith(Constants.CommandChar) && line.Length > 0)
                {
                    sbInputCode.AppendLine(line);
                } // if not a comment
            }

            return sbInputCode.ToString();
        }

        private static string ToLinkedHTMLTables(List<ClassDef> classes)
        {
            Dictionary<string, ClassDef> clss = new();

            foreach (var cls in classes)
            {
                string clsName = cls.Name;
                if (clsName.Contains(":"))
                    clsName = clsName.Split(':')[0].Trim();
                clss.Add(clsName, cls);
            }

            StringBuilder sb = new();

            // foreach (var cls in classes)
            return Environment.NewLine +
                ToHTMLTable(classes[0], clss, true)
                + Environment.NewLine;

            // return sb.ToString();
        }

        private static string ToHTMLTable(ClassDef clsDef, Dictionary<string, ClassDef> allClasses, bool includeTableCaption = false)
        {
            if (!clsDef.HasComplexTypes)
                return clsDef.ToHTMLTable();

            StringBuilder sb = new StringBuilder();

            string tableCaption = string.Empty;

            if (includeTableCaption)
                tableCaption = clsDef.Name;

            sb.AppendLine(@"    <table>
        <caption><strong>" + tableCaption + @"</strong></caption>
        <tr>	<th>Property</th><th>Type</th></tr>");

            //foreach (var prop in Properties)
            //    sb.AppendLine("\t<tr><td>" + prop.AccessModifier + "</td><td>" + prop.DataType + "</td><td>" + prop.Name + "</td></tr>");
            foreach (var prop in clsDef.Properties)
            {
                sb.Append("\t<tr><td>" + prop.Name + "</td><td style=\"color: gray;\">" + prop.DataType);
                if (!Primitives.Any(x => x == prop.DataType.ToLower().Replace("[]", "")))
                {
                    var typeName = prop.DataType.Replace("[]", "")
                        .Replace("List<", "")
                        .Replace(">", "")
                        .Replace("Dictionary<", "");

                    sb.AppendLine(ToHTMLTable(allClasses[typeName], allClasses));
                }

                sb.AppendLine("\t</td></tr>");
            }

            sb.AppendLine("</table>");
            return Environment.NewLine + sb.ToString();
        }

        private class ClassDef
        {
            public ClassDef()
            {
                Properties = new List<PropertyDef>();
            }

            public string Name { get; set; }
            public string AccessModifier { get; set; } // public, protected, internal, private, protected internal, private protected
            public List<PropertyDef> Properties { get; set; }

            public bool HasComplexTypes
            {
                get
                {
                    foreach (var prop in Properties)
                        if (Primitives.Any(x => x != prop.DataType))
                            return true;

                    return false;
                }
            }

            public override string ToString()
            {
                StringBuilder sb = new StringBuilder();

                foreach (var prop in Properties)
                    sb.AppendLine("\t" + prop.AccessModifier + " " + prop.DataType + " " + prop.Name);

                return Name + Environment.NewLine + sb.ToString();
            }

            public string ToHTMLTable(bool includeTableCaption = false)
            {
                StringBuilder sb = new StringBuilder();

                string tableCaption = string.Empty;

                if (includeTableCaption)
                    tableCaption = Name;

                sb.AppendLine(@"    <table>
        <caption>" + tableCaption + @"</caption>
        <tr>	<th>Property Name</th><th>Type</th></tr>");

                //foreach (var prop in Properties)
                //    sb.AppendLine("\t<tr><td>" + prop.AccessModifier + "</td><td>" + prop.DataType + "</td><td>" + prop.Name + "</td></tr>");

                foreach (var prop in Properties)
                    sb.AppendLine("\t<tr><td>" + prop.Name + "</td><td>" + prop.DataType + "</td></tr>");

                sb.AppendLine("</table>");

                return Environment.NewLine + sb.ToString();
            }
        }

        private class PropertyDef
        {
            public string Name { get; set; }
            public string DataType { get; set; } // public, internal, private 
            public string AccessModifier { get; set; }

            public PropertyDef(string accessmodifier, string datatype, string name)
            {
                Name = name.Trim();
                DataType = datatype.Trim();
                AccessModifier = accessmodifier.Trim();
            }

            public PropertyDef(string datatype, string name)
            {
                Name = name;
                DataType = datatype;
            }
        }

        private static string[] Primitives = { "byte","sbyte","int","uint","short","ushort","long","ulong","float","double","char","bool","object","string","decimal","datetime",
                                                "Byte","SByte","Int32","UInt32","Int16","UInt16","Int64","UInt64","Single","Double","Char","Boolean","Object","String","Decimal","DateTime"};

        internal string EscapeString(InputParams inParams)
        {
            return "string strValue = @\""
                + inParams.Data.Replace("\"", "\"\"")
                + "\";";
        }

        internal string EscapeStringV2(InputParams inParams)
        {
            return "string strValue = @$\""
                + inParams.Data.Replace("\"", "\"\"")
                                     .Replace("{", "{{")
                                     .Replace("}", "}}") + "\";";
        }


        #endregion

    }
}
