﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace SDKLibV5.Functionality
{
    internal sealed class RegEx : FunctionalityBase
    {
        #region IDescribeMyFunctionality
        private static DescribeMyFunctionality<InputParamsBase> _info;
        /// <summary>
        ///     Functionality Info
        /// </summary>
        internal static DescribeMyFunctionality<InputParamsBase> Info
        {
            get
            {
                if (_info is null)
                {
                    #region Class Functionality Definitions and sample inputs
                    var description = @"This class provides a Regex Tester as well as a number of commonly used Regex Patterns";
                    var desc4RegexTester = @"Provides a Regex Tester";

                    string sampleHtmlContent = @"<!DOCTYPE html>
<html lang=""en"">
<head prefix=""og: http://ogp.me/ns# fb: http://ogp.me/ns/fb# website: http://ogp.me/ns/website#"">
    <meta charset=""utf-8"">
    <title>Factory Method</title>

    <meta name=""viewport"" content=""width=device-width, initial-scale=1, shrink-to-fit=no"">

    <link rel=""alternate"" href=""https://refactoring.guru/design-patterns/factory-method"" hreflang=""x-default""/>
    <link rel=""alternate"" href=""https://refactoring.guru/es/design-patterns/factory-method"" hreflang=""es""/>
    <link rel=""alternate"" href=""https://refactoring.guru/fr/design-patterns/factory-method"" hreflang=""fr""/>
    <link rel=""alternate"" href=""https://refactoring.guru/pl/design-patterns/factory-method"" hreflang=""pl""/>
    <link rel=""alternate"" href=""https://refactoring.guru/pt-br/design-patterns/factory-method"" hreflang=""pt-br""/>
    <link rel=""alternate"" href=""https://refactoring.guru/ru/design-patterns/factory-method"" hreflang=""ru""/>
    <link rel=""alternate"" href=""https://refactoring.guru/uk/design-patterns/factory-method"" hreflang=""uk""/>
    <link rel=""alternate"" href=""https://refactoringguru.cn/design-patterns/factory-method"" hreflang=""zh""/>

    <meta name=""description"" content=""Factory Method is a creational design pattern that provides an interface for creating objects in a superclass, but allows subclasses to alter the type of objects that will be created."">

    <link rel=""canonical"" href=""https://refactoring.guru/design-patterns/factory-method""/>

    <link rel=""icon"" type=""image/x-icon"" href=""/favicon.ico?id=e1894c5648d77c8db9cb""/>

<script type=""application/ld+json"">
{""@context"": ""http://schema.org"", ""@graph"": [{""@type"":""Person"",""@id"":""https://refactoring.guru/#founder"",""name"":""Alexander Shvets""},{""@type"":""Organization"",""@id"":""https://refactoring.guru/#organization"",""name"":""Refactoring.Guru"",""description"":""Refactoring.Guru makes it easy for you to discover everything you need to know about refactoring, design patterns, SOLID principles, and other smart programming topics."",""image"":{""@type"":""ImageObject"",""@id"":""https://refactoring.guru/#organizationlogo"",""url"":""https://refactoring.guru/images/content-public/logos/logo-plain.png"",""caption"":""Refactoring.Guru""},""logo"":{""@id"":""https://refactoring.guru/#organizationlogo""},""founder"":{""@id"":""https://refactoring.guru/#founder""},""sameAs"":[""https://www.facebook.com/refactoring.guru"",""https://twitter.com/RefactoringGuru"",""https://github.com/RefactoringGuru""]},{""@type"":""WebSite"",""@id"":""https://refactoring.guru/#website"",""url"":""https://refactoring.guru/"",""name"":""Refactoring.Guru"",""description"":""Refactoring.Guru makes it easy for you to discover everything you need to know about refactoring, design patterns, SOLID principles, and other smart programming topics."",""author"":{""@id"":""https://refactoring.guru/#founder""},""publisher"":{""@id"":""https://refactoring.guru/#organization""},""copyrightYear"":2014},{""@type"":""WebPage"",""@id"":""https://refactoring.guru/design-patterns/factory-method#webpage"",""url"":""https://refactoring.guru/design-patterns/factory-method"",""inLanguage"":""en"",""name"":""Factory Method"",""description"":""Factory Method is a creational design pattern that provides an interface for creating objects in a superclass, but allows subclasses to alter the type of objects that will be created."",""isPartOf"":{""@id"":""https://refactoring.guru#website""},""breadcrumb"":{""@id"":""https://refactoring.guru/design-patterns/factory-method#breadcrumb""},""primaryImageOfPage"":{""@id"":""https://refactoring.guru/design-patterns/factory-method#primaryimage""},""image"":{""@type"":""ImageObject"",""@id"":""https://refactoring.guru/design-patterns/factory-method#primaryimage"",""url"":""https://refactoring.guru/images/patterns/content/factory-method/factory-method-en-3x.png"",""width"":1920,""height"":1200}},{""@type"":""Article"",""@id"":""https://refactoring.guru/design-patterns/factory-method#article"",""isPartOf"":{""@id"":""https://refactoring.guru/design-patterns/factory-method#webpage""},""mainEntityOfPage"":{""@id"":""https://refactoring.guru/design-patterns/factory-method#webpage""},""author"":{""@id"":""https://refactoring.guru#founder""},""publisher"":{""@id"":""https://refactoring.guru#organization""},""headline"":""Factory Method"",""datePublished"":""2020-01-01"",""dateModified"":""2021-01-01"",""articleSection"":""Design Patterns"",""image"":{""@id"":""https://refactoring.guru/design-patterns/factory-method#primaryimage""}},{""@type"":""BreadcrumbList"",""@id"":""https://refactoring.guru/design-patterns/factory-method#breadcrumb"",""itemListElement"":[{""@type"":""ListItem"",""position"":1,""name"":""Home"",""item"":""https://refactoring.guru""},{""@type"":""ListItem"",""position"":2,""name"":""Design Patterns"",""item"":""https://refactoring.guru/design-patterns""},{""@type"":""ListItem"",""position"":3,""name"":""Creational Patterns"",""item"":""https://refactoring.guru/design-patterns/creational-patterns""}]}] }
</script>

<meta property=""fb:app_id"" content=""666819623386327"" />
<meta property=""og:type""  content=""website"" />
<meta property=""og:image"" content=""https://refactoring.guru/images/refactoring/social/facebook-share-preview.png?id=dbf9e98269595be86eb6""/>

        <link rel=""stylesheet"" href=""/css/public-packed.min.css?id=7ac1d0d5738b84e7ab43"">

<style type=""text/css"">
    body,html{font-family:""PT Sans"",sans-serif}@font-face{font-family:'PT Sans';font-style:normal;font-weight:400;font-display:swap;src:local(""PT Sans""),local(""PTSans-Regular""),url(/fonts/PTSans/ptsans-regular_cyrillic-ext.woff2?1) format(""woff2"");unicode-range:U+0460-052F,U+1C80-1C88,U+20B4,U+2DE0-2DFF,U+A640-A69F,U+FE2E-FE2F}@font-face{font-family:'PT Sans';font-style:normal;font-weight:400;font-display:swap;src:local(""PT Sans""),local(""PTSans-Regular""),url(/fonts/PTSans/ptsans-regular_cyrillic.woff2?1) format(""woff2"");unicode-range:U+0400-045F,U+0490-0491,U+04B0-04B1,U+2116}@font-face{font-family:'PT Sans';font-style:normal;font-weight:400;font-display:swap;src:local(""PT Sans""),local(""PTSans-Regular""),url(/fonts/PTSans/ptsans-regular_latin-ext.woff2?1) format(""woff2"");unicode-range:U+0100-024F,U+0259,U+1E00-1EFF,U+2020,U+20A0-20AB,U+20AD-20CF,U+2113,U+2C60-2C7F,U+A720-A7FF}@font-face{font-family:'PT Sans';font-style:normal;font-weight:400;font-display:swap;src:local(""PT Sans""),local(""PTSans-Regular""),url(/fonts/PTSans/ptsans-regular_latin.woff2?1) format(""woff2"");unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD}@font-face{font-family:'PT Sans';font-style:normal;font-weight:400;font-display:swap;src:local(""PT Sans""),local(""PTSans-Regular""),url(/fonts/PTSans/ptsans-regular_en.woff2?1) format(""woff2"");unicode-range:U+0-FF,U+131,U+142,U+152,U+153,U+2BB,U+2BC,U+2C6,U+2DA,U+2DC,U+420,U+423,U+430,U+438-43A,U+43D,U+440,U+441,U+443,U+44C,U+457,U+2000-206F,U+2074,U+20AA-20AC,U+20B4,U+20B9,U+20BA,U+20BD,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD}@font-face{font-family:'PT Sans';font-style:normal;font-weight:700;font-display:swap;src:local(""PT Sans Bold""),local(""PTSans-Bold""),url(/fonts/PTSans/ptsans-bold_cyrillic-ext.woff2?1) format(""woff2"");unicode-range:U+0460-052F,U+1C80-1C88,U+20B4,U+2DE0-2DFF,U+A640-A69F,U+FE2E-FE2F}@font-face{font-family:'PT Sans';font-style:normal;font-weight:700;font-display:swap;src:local(""PT Sans Bold""),local(""PTSans-Bold""),url(/fonts/PTSans/ptsans-bold_cyrillic.woff2?1) format(""woff2"");unicode-range:U+0400-045F,U+0490-0491,U+04B0-04B1,U+2116}@font-face{font-family:'PT Sans';font-style:normal;font-weight:700;font-display:swap;src:local(""PT Sans Bold""),local(""PTSans-Bold""),url(/fonts/PTSans/ptsans-bold_latin-ext.woff2?1) format(""woff2"");unicode-range:U+0100-024F,U+0259,U+1E00-1EFF,U+2020,U+20A0-20AB,U+20AD-20CF,U+2113,U+2C60-2C7F,U+A720-A7FF}@font-face{font-family:'PT Sans';font-style:normal;font-weight:700;font-display:swap;src:local(""PT Sans Bold""),local(""PTSans-Bold""),url(/fonts/PTSans/ptsans-bold_latin.woff2?1) format(""woff2"");unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD}@font-face{font-family:'PT Sans';font-style:normal;font-weight:700;font-display:swap;src:local(""PT Sans Bold""),local(""PTSans-Bold""),url(/fonts/PTSans/ptsans-bold_en.woff2?1) format(""woff2"");unicode-range:U+0-FF,U+131,U+142,U+152,U+153,U+2BB,U+2BC,U+2C6,U+2DA,U+2DC,U+420,U+423,U+430,U+438-43A,U+43D,U+440,U+441,U+443,U+44C,U+457,U+2000-206F,U+2074,U+20AA-20AC,U+20B4,U+20B9,U+20BA,U+20BD,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD}
</style>
<link rel=""preload"" href=""/fonts/PTSans/ptsans-regular_en.woff2?1"" as=""font"" type=""font/woff2"" crossorigin>
<link rel=""preload"" href=""/fonts/PTSans/ptsans-bold_en.woff2?1"" as=""font"" type=""font/woff2"" crossorigin>
<link rel=""preload"" href=""/fonts/fontello/fontawesome.woff2?15843843"" as=""font"" type=""font/woff2"" crossorigin>


<script defer src=""/js/public.min.js?id=4fecc5b416d5165b1272""></script>



</head>
<body class=""locale-en    announcement   factory-method"" data-body_class=""factory-method"">

<div class=""body-holder"">


            <div class=""announcement-block prom"" data-id=""DIDP-announcement"" data-creative-id=""en"" data-position=""top""><div class=""announcement-block-inner"">
            <img src=""/images/content-public/announcement-en-1.svg?id=2b6bba0470947f2a60cd"" loading=""lazy"" style=""width: 36px; height:36px;"">
                Hey, I have just reduced the price for all products. Let's prepare our programming skills for the post-COVID era. <a href=""/store"">Check it out »</a>
            <img src=""/images/content-public/announcement-en-2.svg?id=d0c7bf36cfcc7c733fad"" loading=""lazy"" style=""width: 36px; height:36px;"">
        </div></div>
    
    <div class=""cart-placeholder"">
    <div class=""cart-block-container"" style=""display:none"">
        <div class=""cart-block btn-group"">
            <a href=""#checkout"" class=""btn cart open-checkout"">
                <span class=""cart-text""></span>&nbsp;<strong class=""cart-total font-money""></strong>
            </a><a href=""#checkout"" class=""btn btn-secondary checkout open-checkout""><i class=""fa fa-shopping-cart"" aria-hidden=""true""></i> <span class=""btn-text-span d-none d-sm-inline-block d-lg-none d-hg-inline-block""></span></a>
        </div>
    </div>
</div>
    <main role=""main"" class=""main-content top-content center-content "" data-page_class="""">
        <div class=""main-content-container center-content-container"">
                        <div class=""pattern page text"">
<article>
    <div class=""breadcrumb"">
                                    <a class=""home"" href=""/""><i class=""fa fa-home"" aria-hidden=""true""></i></a>
                                                / <a class=""type"" href=""/design-patterns"">Design Patterns</a>
                                                / <a class=""type"" href=""/design-patterns/creational-patterns"">Creational Patterns</a>
                        </div>
    <h1 class=""title"">Factory Method</h1>

    <script type=""text/javascript"">
        // Shorten examples titles for users.
        var h1 = document.getElementsByTagName(""H1"")[0];
        if (h1.offsetHeight > 160) {
            h1.className += ' smaller';
        }

        // Small beautification for pattern examples.
        var title = h1.innerHTML;
        title = title.replace(/^(Java|C\+\+|C#|PHP|Python|Ruby|Delphi): (.*)$/, '<strong>$1:</strong> $2');
        h1.innerHTML = title;
    </script>

            <div class=""aka"">
            Also known as: <span style=""display:inline-block"">Virtual Constructor</span>
        </div>
    
    

    <div class=""section intent"">
<h2 id=""intent""><i class=""fa fa-flip-horizontal fa-comment-alt-dots"" aria-hidden=""true""></i> Intent</h2>
<p><strong>Factory Method</strong> is a creational design pattern that provides an interface for creating objects in a superclass, but allows subclasses to alter the type of objects that will be created.</p>
<figure class=""image""><img src=""/images/patterns/content/factory-method/factory-method-en.png?id=cfa26f33dc8473e803fa"" alt=""Factory Method&amp;nbsp;pattern"" width=""640"" srcset=""/images/patterns/content/factory-method/factory-method-en-2x.png?id=b3961995a4449fb90820 2x"" /></figure>
</div>
<div class=""section problem"">
<h2 id=""problem""><i class=""fa fa-frown"" aria-hidden=""true""></i> Problem</h2>
<p>Imagine that you’re creating a logistics management application. The first version of your app can only handle transportation by trucks, so the bulk of your code lives inside the <code>Truck</code> class.</p>
<p>After a while, your app becomes pretty popular. Each day you receive dozens of requests from sea transportation companies to incorporate sea logistics into the app.</p>
<figure class=""image""><img src=""/images/patterns/diagrams/factory-method/problem1-en.png?id=de638561be0bbb1025ad"" alt=""Adding a new transportation class to the program causes an issue"" width=""600"" srcset=""/images/patterns/diagrams/factory-method/problem1-en-2x.png?id=9a4959d9dde4edadf809 2x"" loading=""lazy"" /><figcaption>
<p>Adding a new class to the program isn’t that simple if the rest of the code is already coupled to existing classes.</p>
</figcaption></figure>
<p>Great news, right? But how about the code? At present, most of your code is coupled to the <code>Truck</code> class. Adding <code>Ships</code> into the app would require making changes to the entire codebase. Moreover, if later you decide to add another type of transportation to the app, you will probably need to make all of these changes again.</p>
<p>As a result, you will end up with pretty nasty code, riddled with conditionals that switch the app’s behavior depending on the class of transportation objects.</p>
</div>
<div class=""section solution"">
<h2 id=""solution""><i class=""fa fa-smile-beam"" aria-hidden=""true""></i> Solution</h2>
<p>The Factory Method pattern suggests that you replace direct object construction calls (using the <code>new</code> operator) with calls to a special <em>factory</em> method. Don’t worry: the objects are still created via the <code>new</code> operator, but it’s being called from within the factory method. Objects returned by a factory method are often referred to as <em>products.</em></p>
<figure class=""image""><img src=""/images/patterns/diagrams/factory-method/solution1.png?id=fc756d2af296b5b4d482"" alt=""The structure of creator classes"" width=""620"" srcset=""/images/patterns/diagrams/factory-method/solution1-2x.png?id=c482b3cd7a4d8dd73b4c 2x"" loading=""lazy"" /><figcaption>
<p>Subclasses can alter the class of objects being returned by the factory method.</p>
</figcaption></figure>
<p>At first glance, this change may look pointless: we just moved the constructor call from one part of the program to another. However, consider this: now you can override the factory method in a subclass and change the class of products being created by the method.</p>
<p>There’s a slight limitation though: subclasses may return different types of products only if these products have a common base class or interface. Also, the factory method in the base class should have its return type declared as this interface.</p>
<figure class=""image""><img src=""/images/patterns/diagrams/factory-method/solution2-en.png?id=db5de848c1d490b83566"" alt=""The structure of the products hierarchy"" width=""490"" srcset=""/images/patterns/diagrams/factory-method/solution2-en-2x.png?id=1209a3156e450b9d7c43 2x"" loading=""lazy"" /><figcaption>
<p>All products must follow the same interface.</p>
</figcaption></figure>
<p>For example, both <code>Truck</code> and <code>Ship</code> classes should implement the <code>Transport</code> interface, which declares a method called <code>deliver</code>. Each class implements this method differently: trucks deliver cargo by land, ships deliver cargo by sea. The factory method in the <code>RoadLogistics</code> class returns truck objects, whereas the factory method in the <code>SeaLogistics</code> class returns ships.</p>
<figure class=""image""><img src=""/images/patterns/diagrams/factory-method/solution3-en.png?id=b6f53911fc0d56f9ef99"" alt=""The structure of the code after applying the factory method pattern"" width=""640"" srcset=""/images/patterns/diagrams/factory-method/solution3-en-2x.png?id=542c0ba89e91ac11ea79 2x"" loading=""lazy"" /><figcaption>
<p>As long as all product classes implement a common interface, you can pass their objects to the client code without breaking it.</p>
</figcaption></figure>
<p>The code that uses the factory method (often called the <em>client</em> code) doesn’t see a difference between the actual products returned by various subclasses. The client treats all the products as abstract <code>Transport</code>. The client knows that all transport objects are supposed to have the <code>deliver</code> method, but exactly how it works isn’t important to the client.</p>
</div>
<div class=""section structure-container"">
<h2 id=""structure""><i class=""fa fa-sitemap"" aria-hidden=""true""></i> Structure</h2>
<div class=""structure"">
<div class=""struct-image1 struct-image"">
<figure class=""image""><img class=""structure-img-non-indexed d-none d-xl-block"" src=""/images/patterns/diagrams/factory-method/structure.png?id=4cba0803f42517cfe854"" alt=""The structure of the Factory Method pattern"" width=""660"" srcset=""/images/patterns/diagrams/factory-method/structure-2x.png?id=9ea3aa8a47f8be22e12e 2x"" loading=""lazy"" /><img class=""structure-img-indexed d-xl-none"" src=""/images/patterns/diagrams/factory-method/structure-indexed.png?id=4c603207859ca1f939b1"" alt=""The structure of the Factory Method pattern"" width=""660"" srcset=""/images/patterns/diagrams/factory-method/structure-indexed-2x.png?id=c794e4f2d05013fb1764 2x"" loading=""lazy"" /></figure>
</div>
<ol><li class=""struct-li1"">
<p>The <strong>Product</strong> declares the interface, which is common to all objects that can be produced by the creator and its subclasses.</p>
</li>
<li class=""struct-li2"">
<p><strong>Concrete Products</strong> are different implementations of the product interface.</p>
</li>
<li class=""struct-li3"">
<p>The <strong>Creator</strong> class declares the factory method that returns new product objects. It’s important that the return type of this method matches the product interface.</p>
<p>You can declare the factory method as abstract to force all subclasses to implement their own versions of the method. As an alternative, the base factory method can return some default product type.</p>
<p>Note, despite its name, product creation is <strong>not</strong> the primary responsibility of the creator. Usually, the creator class already has some core business logic related to products. The factory method helps to decouple this logic from the concrete product classes. Here is an analogy: a large software development company can have a training department for programmers. However, the primary function of the company as a whole is still writing code, not producing programmers.</p>
</li>
<li class=""struct-li4"">
<p><strong>Concrete Creators</strong> override the base factory method so it returns a different type of product.</p>
<p>Note that the factory method doesn’t have to <strong>create</strong> new instances all the time. It can also return existing objects from a cache, an object pool, or another source.</p>
</li></ol>
<style structure type=""text/css"" >
@media (min-width: 1200px) {
.structure {
margin: 0;
width: auto;
height: 600px;
}

.struct-li3 > p:nth-child(3) {
font-size: 12px;
line-height: 18px;
}

.struct-image1 {
left: 240px;
top: 60px;
}

.struct-li1 {
left: 660px;
top: 30px;
width: 240px;
height: 110px;
}

.struct-li2 {
left: 670px;
top: 360px;
width: 220px;
height: 90px;
}

.struct-li3 {
left: 0px;
top: 10px;
width: 230px;
height: 590px;
}

.struct-li4 {
left: 250px;
top: 450px;
width: 400px;
height: 150px;
}

}

</style>
</div></div>
<div class=""section pseudocode"">
<h2 id=""pseudocode""><i class=""fa fa-hashtag"" aria-hidden=""true""></i> Pseudocode</h2>
<p>This example illustrates how the <strong>Factory Method</strong> can be used for creating cross-platform UI elements without coupling the client code to concrete UI classes.</p>
<figure class=""image""><img src=""/images/patterns/diagrams/factory-method/example.png?id=67db9a5cb817913444ef"" alt=""The structure of the Factory Method pattern example"" width=""640"" srcset=""/images/patterns/diagrams/factory-method/example-2x.png?id=a2470830778e31826315 2x"" loading=""lazy"" /><figcaption>
<p>The cross-platform dialog example.</p>
</figcaption></figure>
<p>The base dialog class uses different UI elements to render its window. Under various operating systems, these elements may look a little bit different, but they should still behave consistently. A button in Windows is still a button in Linux.</p>
<p>When the factory method comes into play, you don’t need to rewrite the logic of the dialog for each operating system. If we declare a factory method that produces buttons inside the base dialog class, we can later create a dialog subclass that returns Windows-styled buttons from the factory method. The subclass then inherits most of the dialog’s code from the base class, but, thanks to the factory method, can render Windows-looking buttons on the screen.</p>
<p>For this pattern to work, the base dialog class must work with abstract buttons: a base class or an interface that all concrete buttons follow. This way the dialog’s code remains functional, whichever type of buttons it works with.</p>
<p>Of course, you can apply this approach to other UI elements as well. However, with each new factory method you add to the dialog, you get closer to the <a href=""/design-patterns/abstract-factory"">Abstract Factory</a> pattern. Fear not, we’ll talk about this pattern later.</p>
<figure class=""code"">
<pre class=""code"" lang=""pseudocode"">// The creator class declares the factory method that must
// return an object of a product class. The creator's subclasses
// usually provide the implementation of this method.
class Dialog is
    // The creator may also provide some default implementation
    // of the factory method.
    abstract method createButton():Button

    // Note that, despite its name, the creator's primary
    // responsibility isn't creating products. It usually
    // contains some core business logic that relies on product
    // objects returned by the factory method. Subclasses can
    // indirectly change that business logic by overriding the
    // factory method and returning a different type of product
    // from it.
    method render() is
        // Call the factory method to create a product object.
        Button okButton = createButton()
        // Now use the product.
        okButton.onClick(closeDialog)
        okButton.render()


// Concrete creators override the factory method to change the
// resulting product's type.
class WindowsDialog extends Dialog is
    method createButton():Button is
        return new WindowsButton()

class WebDialog extends Dialog is
    method createButton():Button is
        return new HTMLButton()


// The product interface declares the operations that all
// concrete products must implement.
interface Button is
    method render()
    method onClick(f)

// Concrete products provide various implementations of the
// product interface.
class WindowsButton implements Button is
    method render(a, b) is
        // Render a button in Windows style.
    method onClick(f) is
        // Bind a native OS click event.

class HTMLButton implements Button is
    method render(a, b) is
        // Return an HTML representation of a button.
    method onClick(f) is
        // Bind a web browser click event.


class Application is
    field dialog: Dialog

    // The application picks a creator's type depending on the
    // current configuration or environment settings.
    method initialize() is
        config = readApplicationConfigFile()

        if (config.OS == &quot;Windows&quot;) then
            dialog = new WindowsDialog()
        else if (config.OS == &quot;Web&quot;) then
            dialog = new WebDialog()
        else
            throw new Exception(&quot;Error! Unknown operating system.&quot;)

    // The client code works with an instance of a concrete
    // creator, albeit through its base interface. As long as
    // the client keeps working with the creator via the base
    // interface, you can pass it any creator's subclass.
    method main() is
        this.initialize()
        dialog.render()
</pre>
</figure>
</div>
<div class=""section applicability-container"">
<h2 id=""applicability""><i class=""fa fa-lightbulb-on"" aria-hidden=""true""></i> Applicability</h2>
<div class=""applicability"">
<div class=""applicability-problem"">
<p><i class=""fa fa-fw fa-bug"" aria-hidden=""true""></i> Use the Factory Method when you don’t know beforehand the exact types and dependencies of the objects your code should work with.</p>
</div><div class=""applicability-solution"">
<p><i class=""fa fa-fw fa-bolt"" aria-hidden=""true""></i> The Factory Method separates product construction code from the code that actually uses the product. Therefore it’s easier to extend the product construction code independently from the rest of the code.</p>
<p>For example, to add a new product type to the app, you’ll only need to create a new creator subclass and override the factory method in it.</p>
</div>
<div class=""applicability-problem"">
<p><i class=""fa fa-fw fa-bug"" aria-hidden=""true""></i> Use the Factory Method when you want to provide users of your library or framework with a way to extend its internal components.</p>
</div><div class=""applicability-solution"">
<p><i class=""fa fa-fw fa-bolt"" aria-hidden=""true""></i> Inheritance is probably the easiest way to extend the default behavior of a library or framework. But how would the framework recognize that your subclass should be used instead of a standard component?</p>
<p>The solution is to reduce the code that constructs components across the framework into a single factory method and let anyone override this method in addition to extending the component itself.</p>
<p>Let’s see how that would work. Imagine that you write an app using an open source UI framework. Your app should have round buttons, but the framework only provides square ones. You extend the standard <code>Button</code> class with a glorious <code>RoundButton</code> subclass. But now you need to tell the main <code>UIFramework</code> class to use the new button subclass instead of a default one.</p>
<p>To achieve this, you create a subclass <code>UIWithRoundButtons</code> from a base framework class and override its <code>createButton</code> method. While this method returns <code>Button</code> objects in the base class, you make your subclass return <code>RoundButton</code> objects. Now use the <code>UIWithRoundButtons</code> class instead of <code>UIFramework</code>. And that’s about it!</p>
</div>
<div class=""applicability-problem"">
<p><i class=""fa fa-fw fa-bug"" aria-hidden=""true""></i> Use the Factory Method when you want to save system resources by reusing existing objects instead of rebuilding them each time.</p>
</div><div class=""applicability-solution"">
<p><i class=""fa fa-fw fa-bolt"" aria-hidden=""true""></i> You often experience this need when dealing with large, resource-intensive objects such as database connections, file systems, and network resources.</p>
<p>Let’s think about what has to be done to reuse an existing object:</p>
<ol>
<li>First, you need to create some storage to keep track of all of the created objects.</li>
<li>When someone requests an object, the program should look for a free object inside that pool.</li>
<li>… and then return it to the client code.</li>
<li>If there are no free objects, the program should create a new one (and add it to the pool).</li>
</ol>
<p>That’s a lot of code! And it must all be put into a single place so that you don’t pollute the program with duplicate code.</p>
<p>Probably the most obvious and convenient place where this code could be placed is the constructor of the class whose objects we’re trying to reuse. However, a constructor must always return <strong>new objects</strong> by definition. It can’t return existing instances.</p>
<p>Therefore, you need to have a regular method capable of creating new objects as well as reusing existing ones. That sounds very much like a factory method.</p>
</div>
</div></div>
<div class=""section checklist"">
<h2 id=""checklist""><i class=""fa fa-clipboard-list-check"" aria-hidden=""true""></i> How to Implement</h2>
<ol>
<li>
<p>Make all products follow the same interface. This interface should declare methods that make sense in every product.</p>
</li>
<li>
<p>Add an empty factory method inside the creator class. The return type of the method should match the common product interface.</p>
</li>
<li>
<p>In the creator’s code find all references to product constructors. One by one, replace them with calls to the factory method, while extracting the product creation code into the factory method.</p>
<p>You might need to add a temporary parameter to the factory method to control the type of returned product.</p>
<p>At this point, the code of the factory method may look pretty ugly. It may have a large <code>switch</code> operator that picks which product class to instantiate. But don’t worry, we’ll fix it soon enough.</p>
</li>
<li>
<p>Now, create a set of creator subclasses for each type of product listed in the factory method. Override the factory method in the subclasses and extract the appropriate bits of construction code from the base method.</p>
</li>
<li>
<p>If there are too many product types and it doesn’t make sense to create subclasses for all of them, you can reuse the control parameter from the base class in subclasses.</p>
<p>For instance, imagine that you have the following hierarchy of classes: the base <code>Mail</code> class with a couple of subclasses: <code>AirMail</code> and <code>GroundMail</code>; the <code>Transport</code> classes are <code>Plane</code>, <code>Truck</code> and <code>Train</code>. While the <code>AirMail</code> class only uses <code>Plane</code> objects, <code>GroundMail</code> may work with both <code>Truck</code> and <code>Train</code> objects. You can create a new subclass (say <code>TrainMail</code>) to handle both cases, but there’s another option. The client code can pass an argument to the factory method of the <code>GroundMail</code> class to control which product it wants to receive.</p>
</li>
<li>
<p>If, after all of the extractions, the base factory method has become empty, you can make it abstract. If there’s something left, you can make it a default behavior of the method.</p>
</li>
</ol>
</div>
<div class=""section pros-cons"">
<h2 id=""pros-cons""><i class=""fa fa-balance-scale"" aria-hidden=""true""></i> Pros and Cons</h2>
<div class=""row""><div class=""col-sm-6"">
<ul>
<li>
<i class=""fa fa-fw fa-check"" aria-hidden=""true""></i> You avoid tight coupling between the creator and the concrete products.</li>
<li>
<i class=""fa fa-fw fa-check"" aria-hidden=""true""></i> <em>Single Responsibility Principle</em>. You can move the product creation code into one place in the program, making the code easier to support.</li>
<li>
<i class=""fa fa-fw fa-check"" aria-hidden=""true""></i> <em>Open/Closed Principle</em>. You can introduce new types of products into the program without breaking existing client code.</li>
</ul>
</div><div class=""col-sm-6"">
<ul>
<li>
<i class=""fa fa-fw fa-times"" aria-hidden=""true""></i> The code may become more complicated since you need to introduce a lot of new subclasses to implement the pattern. The best case scenario is when you’re introducing the pattern into an existing hierarchy of creator classes.</li>
</ul>
</div></div></div>
<div class=""section relations"">
<h2 id=""relations""><i class=""fa fa-exchange-alt"" aria-hidden=""true""></i> Relations with Other Patterns</h2>
<ul>
<li>
<p>Many designs start by using <a href=""/design-patterns/factory-method"">Factory Method</a> (less complicated and more customizable via subclasses) and evolve toward <a href=""/design-patterns/abstract-factory"">Abstract Factory</a>, <a href=""/design-patterns/prototype"">Prototype</a>, or <a href=""/design-patterns/builder"">Builder</a> (more flexible, but more complicated).</p>
</li>
<li>
<p><a href=""/design-patterns/abstract-factory"">Abstract Factory</a> classes are often based on a set of <a href=""/design-patterns/factory-method"">Factory Methods</a>, but you can also use <a href=""/design-patterns/prototype"">Prototype</a> to compose the methods on these classes.</p>
</li>
<li>
<p>You can use <a href=""/design-patterns/factory-method"">Factory Method</a> along with <a href=""/design-patterns/iterator"">Iterator</a> to let collection subclasses return different types of iterators that are compatible with the collections.</p>
</li>
<li>
<p><a href=""/design-patterns/prototype"">Prototype</a> isn’t based on inheritance, so it doesn’t have its drawbacks. On the other hand, <em>Prototype</em> requires a complicated initialization of the cloned object. <a href=""/design-patterns/factory-method"">Factory Method</a> is based on inheritance but doesn’t require an initialization step.</p>
</li>
<li>
<p><a href=""/design-patterns/factory-method"">Factory Method</a> is a specialization of <a href=""/design-patterns/template-method"">Template Method</a>. At the same time, a <em>Factory Method</em> may serve as a step in a large <em>Template Method</em>.</p>
</li>
</ul>
</div>
<div class=""section implementations"">
<h2 id=""implementations""><i class=""fa fa-code"" aria-hidden=""true""></i> Code Examples</h2>
<p><a href=""/design-patterns/factory-method/java/example"" title=""Design Patterns: Factory Method in Java"" class=""prog-lang-link""><img width=""53"" height=""53"" loading=""lazy"" src=""/images/patterns/icons/java.svg?id=e6d87e2dca08c953fe3a"" alt=""Design Patterns: Factory Method in Java""></a>
<a href=""/design-patterns/factory-method/csharp/example"" title=""Design Patterns: Factory Method in C#"" class=""prog-lang-link""><img width=""53"" height=""53"" loading=""lazy"" src=""/images/patterns/icons/csharp.svg?id=da64592defc6e86d57c3"" alt=""Design Patterns: Factory Method in C#""></a>
<a href=""/design-patterns/factory-method/cpp/example"" title=""Design Patterns: Factory Method in C++"" class=""prog-lang-link""><img width=""53"" height=""53"" loading=""lazy"" src=""/images/patterns/icons/cpp.svg?id=f7782ed8b8666246bfcc"" alt=""Design Patterns: Factory Method in C++""></a>
<a href=""/design-patterns/factory-method/php/example"" title=""Design Patterns: Factory Method in PHP"" class=""prog-lang-link""><img width=""53"" height=""53"" loading=""lazy"" src=""/images/patterns/icons/php.svg?id=be1906eb26b71ec1d3b9"" alt=""Design Patterns: Factory Method in PHP""></a>
<a href=""/design-patterns/factory-method/python/example"" title=""Design Patterns: Factory Method in Python"" class=""prog-lang-link""><img width=""53"" height=""53"" loading=""lazy"" src=""/images/patterns/icons/python.svg?id=6d815d43c0f7050a1151"" alt=""Design Patterns: Factory Method in Python""></a>
<a href=""/design-patterns/factory-method/ruby/example"" title=""Design Patterns: Factory Method in Ruby"" class=""prog-lang-link""><img width=""53"" height=""53"" loading=""lazy"" src=""/images/patterns/icons/ruby.svg?id=b065b718c914bf8e960e"" alt=""Design Patterns: Factory Method in Ruby""></a>
<a href=""/design-patterns/factory-method/swift/example"" title=""Design Patterns: Factory Method in Swift"" class=""prog-lang-link""><img width=""53"" height=""53"" loading=""lazy"" src=""/images/patterns/icons/swift.svg?id=0b716c2d52ec3a48fbe9"" alt=""Design Patterns: Factory Method in Swift""></a>
<a href=""/design-patterns/factory-method/typescript/example"" title=""Design Patterns: Factory Method in TypeScript"" class=""prog-lang-link""><img width=""53"" height=""53"" loading=""lazy"" src=""/images/patterns/icons/typescript.svg?id=2239d0f16cb703540c20"" alt=""Design Patterns: Factory Method in TypeScript""></a>
<a href=""/design-patterns/factory-method/go/example"" title=""Design Patterns: Factory Method in Go"" class=""prog-lang-link""><img width=""53"" height=""53"" loading=""lazy"" src=""/images/patterns/icons/go.svg?id=1a89927eb99b1ea3fde7"" alt=""Design Patterns: Factory Method in Go""></a></p>
</div>
<div class=""section extras"">
<h2 id=""extras""><i class=""fa fa-gift"" aria-hidden=""true""></i> Extra Content</h2>
<ul>
<li>Read our <a href=""/design-patterns/factory-comparison"">Factory Comparison</a> if you can’t figure out the difference between various factory patterns and concepts.</li>
</ul>
</div>


    <div class=""banner-set2"" id=""book-promo"">
            <div class=""prom banner-content banner-bg banner-striped banner-with-image"" data-id=""DP: 1: Support our free website and own the eBook!"" data-creative-id=""standard-en"" data-position=""content_bottom"">
                <div class=""banner-image"">
                    <a href=""/design-patterns/book"">
                        <img width=""200"" height=""200"" loading=""lazy"" src=""/images/patterns/banners/patterns-book-banner-3.png?id=7d445df13c80287beaab"" srcset=""/images/patterns/banners/patterns-book-banner-3-2x.png?id=0cc3f77ab421d1a5c02e 2x"">
                    </a>
                </div>

                <div class=""banner-text"">
                    <h3 class=""title"">Support our free website and own the eBook!</h3>
                    <ul style=""font-size: 14px;"">
                        <li style=""margin: 0;"">22 design patterns and 8 principles explained in depth.</li>
                        <li style=""margin: 0;"">409 well-structured, easy to read, jargon-free pages.</li>
                        <li style=""margin: 0;"">225 clear and helpful illustrations and diagrams.</li>
                        <li style=""margin: 0;"">An archive with code examples in 9 languages.</li>
                        <li style=""margin: 0;"">All devices supported: PDF/EPUB/MOBI/KFX formats.</li>
                    </ul>
                    <a class=""btn btn-secondary"" href=""/design-patterns/book""><i class=""fa fa-book"" aria-hidden=""true""></i> Learn more…</a>
                </div>
            </div>
        </div>

    </article>

<nav class=""prev-next"">
                    <div class=""next"">
                <h4>Read next</h4>
                <a rel=""next"" href=""/design-patterns/abstract-factory"" class=""btn btn-primary"">Abstract Factory&nbsp;<span class=""fa fa-arrow-right""></span></a>
            </div>
                            <div class=""prev"">
                <h4>Return</h4>
                <a rel=""prev"" href=""/design-patterns/creational-patterns"" class=""btn btn-default""><span class=""fa fa-arrow-left""></span>&nbsp;Creational Patterns </a>
            </div>
            </nav>
</div>

<aside class=""feature content-secondary"">
    <div class=""prom banner-sidebar"" data-id=""DP: Sidebar"" data-creative-id=""standard-sidebar-en"" data-position=""sidebar"">
        <div class=""banner-inner"">
            <div class=""image3d-book-right"">
                <div class=""image3d-cover"" style=""background: #0b3752;"">
                    <a href=""/design-patterns/book"">
                        <img width=""250"" height=""375"" loading=""lazy"" src=""/images/patterns/book/web-cover-en.png?id=328861769fd11617674e"" srcset=""/images/patterns/book/web-cover-en-2x.png?id=02940141c5652ed5a426 2x"">
                    </a>
                </div>
            </div>
            <div style=""margin-top: 1rem"">
                <p class=""text-center"">This article is a part of our eBook<br/><strong>Dive Into Design Patterns</strong>.</p>
                <a href=""/design-patterns/book"" class=""btn btn-secondary btn-block""><i class=""fa fa-book"" aria-hidden=""true""></i> Learn more…</a>
            </div>
        </div>
    </div>


</aside>
                    </div>
    </main>

    <nav class=""navigation"" role=""navigation"">
    <div class=""navigation-container"">
        <a href=""#menu"" class=""navigation-toggle""><i class=""fa fa-bars""></i></a>
        <a class=""navigation-brand"" href=""/"">
            <img alt=""Refactoring.Guru"" src=""/images/content-public/logos/logo-covid-mobile.png?id=8f116d88facf1358d35d"" srcset=""/images/content-public/logos/logo-covid-mobile-2x.png?id=e7a185c976d5365b6ebc 2x""
                  width=""94""                   height=""64""             >
        </a>
        <div class=""social-likes-block"" data-url=""https://refactoring.guru"">
    <div data-service=""facebook"" class=""facebook"" title=""Share on Facebook"">Facebook</div>
        <div data-service=""twitter"" class=""twitter"" title=""Share on Twitter"">Twitter</div>
</div>        <ul class=""navigation-menu"">
                        <li class=""dropdown d-lg-none"">
                <a class=""dropdown-toggle"" id=""dropdownLanguage"" data-toggle=""dropdown"" aria-haspopup=""true"" aria-expanded=""false"">
                    <i class=""fa fa-globe"" aria-hidden=""true""></i> <span class=""caption d-none d-xl-inline-block"">Language</span>
                </a>
                <div class=""dropdown-menu dropdown-menu-right"" aria-labelledby=""dropdownLanguage"">
                                                                                                        <a href=""https://refactoring.guru/design-patterns/factory-method"" class=""dropdown-item locale-link active"" data-locale=""en"" title=""English"">English</a>
                                                                                                                <a href=""https://refactoring.guru/es/design-patterns/factory-method"" class=""dropdown-item locale-link "" data-locale=""es"" title=""Español"">Español</a>
                                                                                                                <a href=""https://refactoring.guru/fr/design-patterns/factory-method"" class=""dropdown-item locale-link "" data-locale=""fr"" title=""Français"">Français</a>
                                                                                                                <a href=""https://refactoring.guru/pl/design-patterns/factory-method"" class=""dropdown-item locale-link "" data-locale=""pl"" title=""Polski"">Polski</a>
                                                                                                                <a href=""https://refactoring.guru/pt-br/design-patterns/factory-method"" class=""dropdown-item locale-link "" data-locale=""pt-br"" title=""Português Brasileiro"">Português Brasileiro</a>
                                                                                                                <a href=""https://refactoring.guru/ru/design-patterns/factory-method"" class=""dropdown-item locale-link "" data-locale=""ru"" title=""Русский"">Русский</a>
                                                                                                                <a href=""https://refactoring.guru/uk/design-patterns/factory-method"" class=""dropdown-item locale-link "" data-locale=""uk"" title=""Українська"">Українська</a>
                                                                                                                <a href=""https://refactoringguru.cn/design-patterns/factory-method"" class=""dropdown-item locale-link "" data-locale=""zh"" title=""中文"">中文</a>
                                                                                                                                                                                                                                                                                                                                                                                                                                                                            </div>
            </li>
                        <li class=""nav-contact"">
                <a class=""userecho-private"" href=""https://feedback.refactoring.guru/?show_feedback_form_private=true"" rel=""nofollow"" title=""Contact us"">
                    <i class=""fa fa-envelope""></i> <span class=""caption d-none d-xl-inline-block"">Contact us</span>
                </a>
            </li>
                                                <li class=""nav-login"">
                        <a href=""https://refactoring.guru/login"" title=""Log in""><i class=""fa fa-user""></i> <span class=""caption d-none d-xl-inline-block"">Log in</span></a>
                    </li>
                                    </ul>
    </div>
</nav>
    <aside class=""sidebar main-menu nano"">
    <a href=""#menu-close"" class=""navigation-toggle""><i class=""fa fa-fw fa-times""></i></a>
    <div class=""nano-content"">
                    <div class=""main-menu-lang d-none d-lg-flex main-menu-lang-count-8"">
                                                                                        <a href=""https://refactoring.guru/design-patterns/factory-method"" class=""locale-link active"" data-locale=""en"" title=""English""><span class=""d-lg-none"">English</span><span class=""d-none d-lg-inline"">English</span></a>
                                                                                                <a href=""https://refactoring.guru/es/design-patterns/factory-method"" class=""locale-link "" data-locale=""es"" title=""Español""><span class=""d-lg-none"">Español</span><span class=""d-none d-lg-inline"">Español</span></a>
                                                                                                <a href=""https://refactoring.guru/fr/design-patterns/factory-method"" class=""locale-link "" data-locale=""fr"" title=""Français""><span class=""d-lg-none"">Français</span><span class=""d-none d-lg-inline"">Français</span></a>
                                                                                                <a href=""https://refactoring.guru/pl/design-patterns/factory-method"" class=""locale-link "" data-locale=""pl"" title=""Polski""><span class=""d-lg-none"">Polski</span><span class=""d-none d-lg-inline"">Polski</span></a>
                                                                                                <a href=""https://refactoring.guru/pt-br/design-patterns/factory-method"" class=""locale-link "" data-locale=""pt-br"" title=""Português Brasileiro""><span class=""d-lg-none"">Português Brasileiro</span><span class=""d-none d-lg-inline"">Português-Br</span></a>
                                                                                                <a href=""https://refactoring.guru/ru/design-patterns/factory-method"" class=""locale-link "" data-locale=""ru"" title=""Русский""><span class=""d-lg-none"">Русский</span><span class=""d-none d-lg-inline"">Русский</span></a>
                                                                                                <a href=""https://refactoring.guru/uk/design-patterns/factory-method"" class=""locale-link "" data-locale=""uk"" title=""Українська""><span class=""d-lg-none"">Українська</span><span class=""d-none d-lg-inline"">Українська</span></a>
                                                                                                <a href=""https://refactoringguru.cn/design-patterns/factory-method"" class=""locale-link "" data-locale=""zh"" title=""中文""><span class=""d-lg-none"">中文</span><span class=""d-none d-lg-inline"">中文</span></a>
                                                                                                                                                                                                                                                                                                                                                                                        </div>
        
        <a class=""menu-brand"" href=""/"">
                            <img width=200 height=241 loading=""lazy"" alt=""Refactoring.Guru"" src=""/images/content-public/logos/logo-covid.png?id=154bc03e0fa6794a28c2"" srcset=""/images/content-public/logos/logo-covid-2x.png?id=f1ba956cd590502c3329 2x"">
                    </a>

        <div class=""menu-container"" style=""position: relative"">
                        <ul class=""menu-list trail"">
                            <li class=""featured"">
            <a href=""/store"">
                <i class=""fa fa-fw fa-star"" aria-hidden=""true""></i> Premium Content
            </a>
    
            <ul >
                            <li class=""featured menu-fs15"">
            <a href=""/design-patterns/book"">
                <i class=""fa fa-fw fa-book"" aria-hidden=""true""></i> Design Patterns eBook
            </a>
    
    
            </li>
                                <li class=""featured menu-fs15"">
            <a href=""/refactoring/course"">
                <i class=""fa fa-fw fa-graduation-cap"" aria-hidden=""true""></i> Refactoring Course
            </a>
    
    
            </li>
                        </ul>
    
            </li>
                                <li class="""">
            <a href=""/refactoring"">
                <i class=""fa fa-fw fa-scissors"" aria-hidden=""true""></i> Refactoring
            </a>
    
            <ul >
                            <li class="""">
            <a href=""/refactoring/what-is-refactoring"">
                What is Refactoring
            </a>
    
            <ul >
                            <li class="""">
            <a href=""/refactoring/what-is-refactoring"">
                Clean code
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/refactoring/technical-debt"">
                Technical debt
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/refactoring/when"">
                When to refactor
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/refactoring/how-to"">
                How to refactor
            </a>
    
    
            </li>
                        </ul>
    
            </li>
                                <li class="""">
            <a href=""/refactoring/catalog"">
                Catalog
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/refactoring/smells"">
                Code Smells
            </a>
    
            <ul >
                            <li class="""">
            <a href=""/refactoring/smells/bloaters"">
                Bloaters
            </a>
    
            <ul >
                            <li class="""">
            <a href=""/smells/long-method"">
                Long Method
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/smells/large-class"">
                Large Class
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/smells/primitive-obsession"">
                Primitive Obsession
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/smells/long-parameter-list"">
                Long Parameter List
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/smells/data-clumps"">
                Data Clumps
            </a>
    
    
            </li>
                        </ul>
    
            </li>
                                <li class="""">
            <a href=""/refactoring/smells/oo-abusers"">
                Object-Orientation Abusers
            </a>
    
            <ul >
                            <li class="""">
            <a href=""/smells/switch-statements"">
                Switch Statements
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/smells/temporary-field"">
                Temporary Field
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/smells/refused-bequest"">
                Refused Bequest
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/smells/alternative-classes-with-different-interfaces"">
                Alternative Classes with Different Interfaces
            </a>
    
    
            </li>
                        </ul>
    
            </li>
                                <li class="""">
            <a href=""/refactoring/smells/change-preventers"">
                Change Preventers
            </a>
    
            <ul >
                            <li class="""">
            <a href=""/smells/divergent-change"">
                Divergent Change
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/smells/shotgun-surgery"">
                Shotgun Surgery
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/smells/parallel-inheritance-hierarchies"">
                Parallel Inheritance Hierarchies
            </a>
    
    
            </li>
                        </ul>
    
            </li>
                                <li class="""">
            <a href=""/refactoring/smells/dispensables"">
                Dispensables
            </a>
    
            <ul >
                            <li class="""">
            <a href=""/smells/comments"">
                Comments
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/smells/duplicate-code"">
                Duplicate Code
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/smells/lazy-class"">
                Lazy Class
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/smells/data-class"">
                Data Class
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/smells/dead-code"">
                Dead Code
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/smells/speculative-generality"">
                Speculative Generality
            </a>
    
    
            </li>
                        </ul>
    
            </li>
                                <li class="""">
            <a href=""/refactoring/smells/couplers"">
                Couplers
            </a>
    
            <ul >
                            <li class="""">
            <a href=""/smells/feature-envy"">
                Feature Envy
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/smells/inappropriate-intimacy"">
                Inappropriate Intimacy
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/smells/message-chains"">
                Message Chains
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/smells/middle-man"">
                Middle Man
            </a>
    
    
            </li>
                        </ul>
    
            </li>
                                <li class="""">
            <a href=""/refactoring/smells/other"">
                Other Smells
            </a>
    
            <ul >
                            <li class="""">
            <a href=""/smells/incomplete-library-class"">
                Incomplete Library Class
            </a>
    
    
            </li>
                        </ul>
    
            </li>
                        </ul>
    
            </li>
                                <li class="""">
            <a href=""/refactoring/techniques"">
                Refactorings
            </a>
    
            <ul >
                            <li class="""">
            <a href=""/refactoring/techniques/composing-methods"">
                Composing Methods
            </a>
    
            <ul >
                            <li class="""">
            <a href=""/extract-method"">
                Extract Method
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/inline-method"">
                Inline Method
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/extract-variable"">
                Extract Variable
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/inline-temp"">
                Inline Temp
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/replace-temp-with-query"">
                Replace Temp with Query
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/split-temporary-variable"">
                Split Temporary Variable
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/remove-assignments-to-parameters"">
                Remove Assignments to Parameters
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/replace-method-with-method-object"">
                Replace Method with Method Object
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/substitute-algorithm"">
                Substitute Algorithm
            </a>
    
    
            </li>
                        </ul>
    
            </li>
                                <li class="""">
            <a href=""/refactoring/techniques/moving-features-between-objects"">
                Moving Features between Objects
            </a>
    
            <ul >
                            <li class="""">
            <a href=""/move-method"">
                Move Method
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/move-field"">
                Move Field
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/extract-class"">
                Extract Class
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/inline-class"">
                Inline Class
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/hide-delegate"">
                Hide Delegate
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/remove-middle-man"">
                Remove Middle Man
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/introduce-foreign-method"">
                Introduce Foreign Method
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/introduce-local-extension"">
                Introduce Local Extension
            </a>
    
    
            </li>
                        </ul>
    
            </li>
                                <li class="""">
            <a href=""/refactoring/techniques/organizing-data"">
                Organizing Data
            </a>
    
            <ul >
                            <li class="""">
            <a href=""/self-encapsulate-field"">
                Self Encapsulate Field
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/replace-data-value-with-object"">
                Replace Data Value with Object
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/change-value-to-reference"">
                Change Value to Reference
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/change-reference-to-value"">
                Change Reference to Value
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/replace-array-with-object"">
                Replace Array with Object
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/duplicate-observed-data"">
                Duplicate Observed Data
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/change-unidirectional-association-to-bidirectional"">
                Change Unidirectional Association to Bidirectional
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/change-bidirectional-association-to-unidirectional"">
                Change Bidirectional Association to Unidirectional
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/replace-magic-number-with-symbolic-constant"">
                Replace Magic Number with Symbolic Constant
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/encapsulate-field"">
                Encapsulate Field
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/encapsulate-collection"">
                Encapsulate Collection
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/replace-type-code-with-class"">
                Replace Type Code with Class
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/replace-type-code-with-subclasses"">
                Replace Type Code with Subclasses
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/replace-type-code-with-state-strategy"">
                Replace Type Code with State/Strategy
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/replace-subclass-with-fields"">
                Replace Subclass with Fields
            </a>
    
    
            </li>
                        </ul>
    
            </li>
                                <li class="""">
            <a href=""/refactoring/techniques/simplifying-conditional-expressions"">
                Simplifying Conditional Expressions
            </a>
    
            <ul >
                            <li class="""">
            <a href=""/decompose-conditional"">
                Decompose Conditional
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/consolidate-conditional-expression"">
                Consolidate Conditional Expression
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/consolidate-duplicate-conditional-fragments"">
                Consolidate Duplicate Conditional Fragments
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/remove-control-flag"">
                Remove Control Flag
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/replace-nested-conditional-with-guard-clauses"">
                Replace Nested Conditional with Guard Clauses
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/replace-conditional-with-polymorphism"">
                Replace Conditional with Polymorphism
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/introduce-null-object"">
                Introduce Null Object
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/introduce-assertion"">
                Introduce Assertion
            </a>
    
    
            </li>
                        </ul>
    
            </li>
                                <li class="""">
            <a href=""/refactoring/techniques/simplifying-method-calls"">
                Simplifying Method Calls
            </a>
    
            <ul >
                            <li class="""">
            <a href=""/rename-method"">
                Rename Method
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/add-parameter"">
                Add Parameter
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/remove-parameter"">
                Remove Parameter
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/separate-query-from-modifier"">
                Separate Query from Modifier
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/parameterize-method"">
                Parameterize Method
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/replace-parameter-with-explicit-methods"">
                Replace Parameter with Explicit Methods
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/preserve-whole-object"">
                Preserve Whole Object
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/replace-parameter-with-method-call"">
                Replace Parameter with Method Call
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/introduce-parameter-object"">
                Introduce Parameter Object
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/remove-setting-method"">
                Remove Setting Method
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/hide-method"">
                Hide Method
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/replace-constructor-with-factory-method"">
                Replace Constructor with Factory Method
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/replace-error-code-with-exception"">
                Replace Error Code with Exception
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/replace-exception-with-test"">
                Replace Exception with Test
            </a>
    
    
            </li>
                        </ul>
    
            </li>
                                <li class="""">
            <a href=""/refactoring/techniques/dealing-with-generalization"">
                Dealing with Generalization
            </a>
    
            <ul >
                            <li class="""">
            <a href=""/pull-up-field"">
                Pull Up Field
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/pull-up-method"">
                Pull Up Method
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/pull-up-constructor-body"">
                Pull Up Constructor Body
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/push-down-method"">
                Push Down Method
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/push-down-field"">
                Push Down Field
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/extract-subclass"">
                Extract Subclass
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/extract-superclass"">
                Extract Superclass
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/extract-interface"">
                Extract Interface
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/collapse-hierarchy"">
                Collapse Hierarchy
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/form-template-method"">
                Form Template Method
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/replace-inheritance-with-delegation"">
                Replace Inheritance with Delegation
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/replace-delegation-with-inheritance"">
                Replace Delegation with Inheritance
            </a>
    
    
            </li>
                        </ul>
    
            </li>
                        </ul>
    
            </li>
                        </ul>
    
            </li>
                                <li class=""trail"">
            <a href=""/design-patterns"">
                <i class=""fa fa-fw fa-puzzle-piece"" aria-hidden=""true""></i> Design Patterns
            </a>
    
            <ul >
                            <li class="""">
            <a href=""/design-patterns/what-is-pattern"">
                What is a Pattern
            </a>
    
            <ul >
                            <li class="""">
            <a href=""/design-patterns/what-is-pattern"">
                What’s a design pattern?
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/design-patterns/history"">
                History of patterns
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/design-patterns/why-learn-patterns"">
                Why should I learn patterns?
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/design-patterns/criticism"">
                Criticism of patterns
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/design-patterns/classification"">
                Classification of patterns
            </a>
    
    
            </li>
                        </ul>
    
            </li>
                                <li class="""">
            <a href=""/design-patterns/catalog"">
                Catalog
            </a>
    
    
            </li>
                                <li class=""menu-third-level trail"">
            <a href=""/design-patterns/creational-patterns"">
                Creational Patterns
            </a>
    
            <ul >
                            <li class=""trail active"">
            <a href=""/design-patterns/factory-method"">
                Factory Method
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/design-patterns/abstract-factory"">
                Abstract Factory
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/design-patterns/builder"">
                Builder
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/design-patterns/prototype"">
                Prototype
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/design-patterns/singleton"">
                Singleton
            </a>
    
    
            </li>
                        </ul>
    
            </li>
                                <li class=""menu-third-level"">
            <a href=""/design-patterns/structural-patterns"">
                Structural Patterns
            </a>
    
            <ul >
                            <li class="""">
            <a href=""/design-patterns/adapter"">
                Adapter
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/design-patterns/bridge"">
                Bridge
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/design-patterns/composite"">
                Composite
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/design-patterns/decorator"">
                Decorator
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/design-patterns/facade"">
                Facade
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/design-patterns/flyweight"">
                Flyweight
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/design-patterns/proxy"">
                Proxy
            </a>
    
    
            </li>
                        </ul>
    
            </li>
                                <li class=""menu-third-level"">
            <a href=""/design-patterns/behavioral-patterns"">
                Behavioral Patterns
            </a>
    
            <ul >
                            <li class="""">
            <a href=""/design-patterns/chain-of-responsibility"">
                Chain of Responsibility
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/design-patterns/command"">
                Command
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/design-patterns/iterator"">
                Iterator
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/design-patterns/mediator"">
                Mediator
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/design-patterns/memento"">
                Memento
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/design-patterns/observer"">
                Observer
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/design-patterns/state"">
                State
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/design-patterns/strategy"">
                Strategy
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/design-patterns/template-method"">
                Template Method
            </a>
    
    
            </li>
                                <li class="""">
            <a href=""/design-patterns/visitor"">
                Visitor
            </a>
    
    
            </li>
                        </ul>
    
            </li>
                                <li class=""menu-code-examples"">
            <a href=""/design-patterns/examples"">
                Code Examples
            </a>
    
            <ul >
                            <li class=""menu-code-examples-item"">
            <a href=""/design-patterns/csharp"">
                C#
            </a>
    
    
            </li>
                                <li class=""menu-code-examples-item"">
            <a href=""/design-patterns/cpp"">
                C++
            </a>
    
    
            </li>
                                <li class=""menu-code-examples-item"">
            <a href=""/design-patterns/go"">
                Go
            </a>
    
    
            </li>
                                <li class=""menu-code-examples-item"">
            <a href=""/design-patterns/java"">
                Java
            </a>
    
    
            </li>
                                <li class=""menu-code-examples-item"">
            <a href=""/design-patterns/php"">
                PHP
            </a>
    
    
            </li>
                                <li class=""menu-code-examples-item"">
            <a href=""/design-patterns/python"">
                Python
            </a>
    
    
            </li>
                                <li class=""menu-code-examples-item"">
            <a href=""/design-patterns/ruby"">
                Ruby
            </a>
    
    
            </li>
                                <li class=""menu-code-examples-item"">
            <a href=""/design-patterns/swift"">
                Swift
            </a>
    
    
            </li>
                                <li class=""menu-code-examples-item"">
            <a href=""/design-patterns/typescript"">
                TypeScript
            </a>
    
    
            </li>
                        </ul>
    
            </li>
                        </ul>
    
            </li>
                        </ul>
    
            </div>
        <div class=""sidebar-controls"">
            <div class=""sidebar-controls-container"">
                <a href=""https://refactoring.guru/login"" title=""Log in""><i
                            class=""fa fa-fw fa-fw fa-user""></i> Log in</a>
                <a href=""https://feedback.refactoring.guru/"" class=""userecho-public"" rel=""nofollow"" title=""Feedback""><i class=""fa fa-fw fa-fw fa-envelope"" aria-hidden=""true""></i> Contact us</a>
            </div>
        </div>
    </div>
</aside>
    <footer class=""footer center-content"">
    <div class=""footer-container center-content-container"">
        <div class=""footer-inner container-fluid"">
            <div class=""row"">
                <div class=""col-8 col-md-10"">
                    <ul class=""footer-list footer-list-horizontal"">
                        <li><a href=""/"">Home</a></li>
                        <li><a href=""/refactoring"">Refactoring</a></li>
                        <li><a href=""/design-patterns"">Design Patterns</a></li>
                        <li><a href=""/store"">Premium Content</a></li>
                        <li><a href=""https://refactoring.userecho.com/"" rel=""nofollow"" class=""userecho-public"">Forum</a></li>
                        <li><a href=""https://refactoring.userecho.com/"" rel=""nofollow"" class=""userecho-private"">Contact us</a></li>
                    </ul>
                </div>
                <div class=""col-4 col-md-2"">
                    <ul class=""footer-list footer-list-iconic"">
                                                    <li><a href=""https://www.facebook.com/refactoring.guru""><i class=""fa fa-facebook-official""></i></a></li>
                                                <li><a href=""https://refactoring.guru/newsletter"" rel=""nofollow""><i class=""fa fa-envelope"" aria-hidden=""true""></i></a></li>
                        <li><a href=""https://github.com/RefactoringGuru""><i class=""fa fa-github-circled""></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class=""footer-second"">
        <div class=""footer-container center-content-container"">
            <div class=""footer-inner container-fluid"">
                <div class=""row"">
                    <div class=""col-12 col-sm-8"">
                        <i class=""fa fa-fw fa-copyright""></i> 2014-2021 <a href=""/"">Refactoring.Guru</a>. <span style=""white-space: nowrap"">All rights reserved.</span><br>
                        <object class=""fa-fw"" style=""height: 0.8rem; filter: invert(50%);""  type=""image/svg+xml"" data=""/images/content-public/icons/fa-building.svg?id=afddb5806968b0a9acfc"">
                            <img class=""fa-fw"" style=""height: 0.8rem;"" src=""/images/content-public/icons/fa-building.svg?id=afddb5806968b0a9acfc"" alt=""Organization address""/>
                        </object> Khmelnitske shosse 19 / 27, Kamianets-Podilskyi, Ukraine, 32305<br>
                        <i class=""fa fa-fw fa-envelope""></i>  Email: support@refactoring.guru

                        <div class=""mt-2"">
                            <i class=""fa fa-fw fa-image""></i> Illustrations by <a href=""http://zhart.us/"" rel=""nofollow""><span style=""white-space: nowrap"">Dmitry Zhart</span></a></div>
                    </div>
                    <div class=""footer-links-right col-12 col-sm-4 mt-4 mt-sm-0"">
                        <div class=""row"">
                            <div class=""col-8 col-sm-12"">
                                <ul class=""footer-list"">
                                    <li><a href=""/terms""><span>Terms &amp; Conditions</span></a>
                                    </li>
                                    <li><a href=""/privacy-policy""><span>Privacy Policy</span></a>
                                    </li>
                                    <li><a href=""/content-usage-policy""><span>Content Usage Policy</span></a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>

</div>


    <script>
function extend(){var extended={};var deep=false;var i=0;var length=arguments[""length""];if(Object[""prototype""][""toString""][""call""](arguments[0])=== '[object Boolean]'){deep= arguments[0];i++};var merge=function(obj){for(var prop in obj){if(Object[""prototype""][""hasOwnProperty""][""call""](obj,prop)){if(deep&& Object[""prototype""][""toString""][""call""](obj[prop])=== '[object Object]'){extended[prop]= extend(true,extended[prop],obj[prop])}else {extended[prop]= obj[prop]}}}};for(;i< length;i++){var obj=arguments[i];merge(obj)};return extended}
function defer(method) {if (window.jQuery) {method();} else {setTimeout(function() { defer(method) }, 50);}}
</script>
<script>
+function(sd){sd = (typeof sd === ""string"") ? JSON.parse(atob(sd)) : sd;for(var property in sd){if(window[property]!== null&&  typeof window[property]=== 'object'){window[property]= extend(true,window[property],sd[property])}else {window[property]= sd[property]}}}(""eyJsb2NhbGUiOiJlbiIsImxvY2FsZV9wcmVmaXgiOiIiLCJsb2NhbGl6ZWRfdXJsX3ByZWZpeF9tIjoiaHR0cHM6XC9cL3JlZmFjdG9yaW5nLmd1cnVcLyIsInVybF9wcmVmaXhfbSI6Imh0dHBzOlwvXC9yZWZhY3RvcmluZy5ndXJ1XC8iLCJsb2NhbGl6ZWRfdXJsX3ByZWZpeCI6Imh0dHBzOlwvXC9yZWZhY3RvcmluZy5ndXJ1XC8iLCJ1cmxfcHJlZml4IjoiaHR0cHM6XC9cL3JlZmFjdG9yaW5nLmd1cnVcLyIsImNoaW5lc2VfaG9tZSI6Imh0dHBzOlwvXC9yZWZhY3RvcmluZ2d1cnUuY25cLyIsInVzZXJfZWNob19hbGlhcyI6InJlZmFjdG9yaW5nIiwidXNlcl9lY2hvX2hvc3QiOiJmZWVkYmFjay5yZWZhY3RvcmluZy5ndXJ1IiwidXNlcl9lY2hvX3ByaXZhdGVfZm9ydW0iOiIyIiwidXNlcl9lY2hvX2xvY2FsZSI6ImVuIiwidXNlcl9lY2hvX3B1YmxpY19mb3J1bSI6IjMiLCJ1c2VyX2VjaG9fcHVibGljX2ZvcnVtX3VybCI6Imh0dHBzOlwvXC9mZWVkYmFjay5yZWZhY3RvcmluZy5ndXJ1XC8iLCJ1c2VyX2VjaG9fc3NvX3Rva2VuIjoiIn0="");
</script>

    <script defer>
        if (window.dataLayer && window.google_optimize) {
            window.dataLayer.push({'event': 'optimize.activate'});
        }
    </script>
<style>.async-hide { opacity: 0 !important} </style>
<script>(function(a,s,y,n,c,h,i,d,e){s.className+=' '+y;h.start=1*new Date;
        h.end=i=function(){s.className=s.className.replace(RegExp(' ?'+y),'')};
        (a[n]=a[n]||[]).hide=h;setTimeout(function(){i();h.end=null},c);h.timeout=c;
    })(window,document.documentElement,'async-hide','dataLayer',4000,
        {'GTM-M58XZN4':true});</script>
<link rel=""preconnect dns-prefetch"" href=""https://www.google-analytics.com"">
<script>
    var getCookie = function(name) {
        var nameEQ = name + ""="";
        var ca = document.cookie.split(';');
        for(var i=0;i < ca.length;i++) {
            var c = ca[i];
            while (c.charAt(0)==' ') c = c.substring(1,c.length);
            if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length,c.length);
        }
        return null;
    };
    var eraseCookie = function (name) {
        document.cookie = name+'=; Path=/; Max-Age=-99999999;';
    };

    window.google_analytics = 'UA-521840-40';

    (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
        (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
        m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
    })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

    var ga_queue = [];
    window.gaOnCreate = function(){
        ga_queue.push(arguments);
    };

            doTracking();
    
    function doTracking(clientId) {
        window.gaOnCreate = function(){
            ga.apply(this, arguments);
        };

        var options = {
            'siteSpeedSampleRate': 100
        };
        if (clientId) {
            options.clientId = clientId;
        }
        ga('create', 'UA-521840-40', options);

                    ga('require', 'GTM-M58XZN4');
            window.google_optimize = 'GTM-M58XZN4';
        
        // Fix broken Social Login referrer.
        window.social_login_provider = window.social_login_provider || getCookie('social_login_provider');
        if (window.social_login_provider) {
            ga('set', 'referrer', null);
            ga('send', 'social', window.social_login_provider, 'login', window.location.href);
            eraseCookie('social_login_provider');
        }

        var user_id = getCookie('user_id');
        if (user_id) {
            ga('set', 'userId', user_id);
        } else {
            ga('set', 'userId', null);
        }

        var location = document.location.href;
        if (typeof window.analytics_path_prefix === 'string') {
            if (/^(https?:\/\/[^\/]+?)\/$/.test(location)) {
                location = location.replace(/(https?:\/\/[^\/]+?)\//, '$1' + window.analytics_path_prefix);
            }
            else {
                location = location.replace(/(https?:\/\/[^\/]+?)\//, '$1' + window.analytics_path_prefix + '/');
            }
            ga('set', 'location', location);
        }

        if (typeof window.analytics_location_prefix === 'string') {
            location = location.replace(/(https?:\/\/[^\/]+?)\//, window.analytics_location_prefix);
            ga('set', 'location', location);
        }

        ga('require', 'ec');
        ga('send', 'pageview', (typeof window.analytics_path_prefix === 'string' ? window.analytics_path_prefix : '') + document.location.pathname);

        ga_queue.forEach(function(item){
            ga.apply(this, item);
        });
    }
</script>

<script defer>
    window.socialLikesButtons = {
                facebook: {
            counterUrl: """",
            convertNumber: null
        },
                        };
</script>

<script defer>
    var CodeMirrorScripts = [""/js/codemirror.min.js?id=ae8d6b195e9f2e68899e""];
</script>



    <script>window.loadContent = true;window.loadCart = true;</script>
</body>
</html>
";
                    FunctionalityInfo<InputParamsBase> funcRegexTeseter = new(nameof(RegexTester), desc4RegexTester,
                        new List<InputParams> {
                            new() {
                                Content = Constants.MultiLineIndicator + sampleHtmlContent,
                                Pattern = "<head.*</head>",
                                Flags = "IgnoreCase, Multiline, Singleline    "
                                        + Constants.CommentIndicator
                                        + "    [IgnoreCase|Multiline|ExplicitCapture|Compiled|Singleline|IgnorePatternWhitespace|RightToLeft|ECMAScript|CultureInvariant]" } });

                    List<FunctionalityInfo<InputParamsBase>> functionalities = new()
                    {
                        funcRegexTeseter
                    };
                    #endregion
                    _info = new DescribeMyFunctionality<InputParamsBase>(description, functionalities, new DateTime(2021, 5, 31));
                }
                return _info;
            }
        }
        public class InputParams : InputParamsBase
        {
            public string Pattern { get; set; }
            public string Flags { get; set; }
            public string Content { get; set; }
            public InputParams() { }
        }
        #endregion
        #region Implementations
        internal string RegexTester(InputParams inputParams)
        {
            RegexOptions regexOptions = GetSelectedOptions(inputParams.Flags);
            Regex regex = new Regex(inputParams.Pattern, regexOptions);

            if (!regex.IsMatch(inputParams.Content))
            {
                return "no match found";
            }

            var matches = regex.Matches(inputParams.Content);
            StringBuilder sb = new();
            for (int i = 0; i < matches.Count; i++)
            {
                sb.AppendLine($"### Match {i + 1} of {matches.Count}");
                sb.AppendLine(matches[i].Value);
                sb.AppendLine("");
            }

            return sb.ToString();
        }

        private RegexOptions GetSelectedOptions(string flags)
        {
            var options = RegexOptions.None;
            flags = flags.ToLower();

            if (flags.Contains("ignorecase")) options = options | RegexOptions.IgnoreCase;
            if (flags.Contains("multiline")) options = options | RegexOptions.Multiline;
            if (flags.Contains("explicitcapture")) options = options | RegexOptions.ExplicitCapture;
            if (flags.Contains("compiled")) options = options | RegexOptions.Compiled;
            if (flags.Contains("singleline")) options = options | RegexOptions.Singleline;
            if (flags.Contains("ignorepatternwhitespace")) options = options | RegexOptions.IgnorePatternWhitespace;
            if (flags.Contains("righttoleft")) options = options | RegexOptions.RightToLeft;
            if (flags.Contains("ecmascript")) options = options | RegexOptions.ECMAScript;
            if (flags.Contains("cultureinvariant")) options = options | RegexOptions.CultureInvariant;

            return options;
        }
        #endregion
    }
}
