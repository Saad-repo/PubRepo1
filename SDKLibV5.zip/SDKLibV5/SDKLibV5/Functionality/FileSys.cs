﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SDKLibV5.Functionality
{
    internal sealed class FileSys : FunctionalityBase
    {
        #region IDescribeMyFunctionality
        private static DescribeMyFunctionality<InputParamsBase> _info;

        /// <summary>
        ///     Functionality Info
        /// </summary>
        internal static DescribeMyFunctionality<InputParamsBase> Info
        {
            get
            {
                if (_info is null)
                {
                    #region Class Functionality Definitions and sample inputs
                    var desc4Class = @"This class provides File System processing related functionality";
                    var desc4GroupByType = @"File sizes in a given root folder grouped by file type";

                    FunctionalityInfo<InputParamsBase> funcEscapeString = new(nameof(GroupByType), desc4GroupByType,
                        new List<InputParams> {
                            new InputParams(@"C:\temp\"), new InputParams(@"c:\SDK\temp\")  });

                    List<FunctionalityInfo<InputParamsBase>> functionalities = new()
                    {
                        funcEscapeString,
                    };
                    #endregion

                    _info = new DescribeMyFunctionality<InputParamsBase>(desc4Class, functionalities, new DateTime(2021, 5, 10));
                }
                return _info;
            }
        }

        internal class InputParams : InputParamsBase
        {
            public string RootFolder { get; set; } = null;
            public string OutputFormat { get; set; } = null;
            public InputParams() { }
            public InputParams(string rootFolder)
            {
                RootFolder = rootFolder;
                OutputFormat = "MD Table //##// imp.pending for: [txt table | html table]";
            }
        }
        #endregion



        #region Implementation
        private class Constants
        {
            public static string[] FileExtensionsToIgnore = new string[]
{
            ".gitignore"
};

            public static string[] DirectoriesToIgnore = new string[]
            {
            ".git"
            };

            public static string[] FileExtensionsToHighlight = new string[]
            {
            ".cs",
            ".csproj",
            ".sln",
            ".asmx",
            ".aspx",
            ".svc",
            ".cshtml"
            };

        }

        private static Dictionary<string, FileProps1> fileStatsByExtension = new ();

        internal string GroupByType(InputParams inputParams)
        {
            fileStatsByExtension = new Dictionary<string, FileProps1>();
            CountFilesByExtension(inputParams.RootFolder);

            var sorted = fileStatsByExtension.OrderBy(x => x.Key);

            var sb = new StringBuilder();
            long kb = 0;
            int totFleCount = 0;
            var tableData = new List<string>();
            tableData.Add("Extension\tCount\tSize (KB)");

            foreach (var item in sorted)
            {
                kb += item.Value.CombinedSizeKB;
                totFleCount += item.Value.FileCount;

                var ext = item.Key.ToLower();

                if (Constants.FileExtensionsToHighlight.Contains(ext))
                    ext = $"**{ext}**";

                tableData.Add($"{ext}\t{item.Value.FileCount:n0}\t{item.Value.CombinedSizeKB:n0}");
            }

            var markdownUtil = new MarkDown2Html();
            var mdTable = markdownUtil.GetMDTableFromListOfStrings(tableData);
            sb.AppendLine(mdTable);

            sb.AppendLine($"\r\nTotal File Count: {totFleCount:n0}\r\n\r\nCombined Size: {kb:n0} KB\r\n");

            return sb.ToString();
        }

        /// <summary>
        /// populates fileStatsByExtension
        /// </summary>
        /// <param name="dirPath"></param>
        private static void CountFilesByExtension(string dirPath)
        {
            string[] fles = Directory.GetFiles(dirPath);

            foreach (var fle in fles)
            {
                var fleExtension = Path.GetExtension(fle);
                if (!Constants.FileExtensionsToIgnore.Contains(fleExtension))
                {
                    FileInfo fileInfo = new FileInfo(fle);
                    if (fileStatsByExtension.ContainsKey(fleExtension))
                    {
                        var extensionStats = fileStatsByExtension[fleExtension];
                        extensionStats.CombinedSizeKB += fileInfo.Length / 1024;
                        extensionStats.FileCount++;
                        fileStatsByExtension[fleExtension] = extensionStats;
                    }
                    else
                    {
                        fileStatsByExtension.Add(
                            fleExtension,
                            new FileProps1
                            {
                                Extensions = fleExtension,
                                CombinedSizeKB = fileInfo.Length / 1024,
                                FileCount = 1
                            });
                    }
                }
            }

            string[] dirs = Directory.GetDirectories(dirPath);
            foreach (var dir in dirs)
            {
                var dirname = Path.GetFileName(dir);
                if (!Constants.DirectoriesToIgnore.Contains(dirname))
                {
                    CountFilesByExtension(dir);
                }
            }
        }

        private struct FileProps1
        {
            public string Extensions { get; set; }
            public int FileCount { get; set; }
            public long CombinedSizeKB { get; set; }
        }

        public static string GetFileContent(string fileName)
        {
            string content = "";
            using (StreamReader sr = new StreamReader(fileName))
            {
                content = sr.ReadToEnd();
            }
            return content;
        }

    }
    #endregion
}
