﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;

namespace SDKLibV5.Functionality
{
    /// <summary>
    ///     Converts a given MarkDown file to an HTML document
    /// </summary>
    public sealed class MarkDown2Html : FunctionalityBase
    {
        #region IDescribeMyFunctionality
        private static DescribeMyFunctionality<InputParamsBase> _info;

        /// <summary>
        ///     Functionality Info
        /// </summary>
        internal static DescribeMyFunctionality<InputParamsBase> Info
        {
            get
            {
                if (_info is null)
                {
                    #region Class Functionality Definitions and sample inputs
                    var description = @"This class provides an implementation for converting MD content to HTML content";
                    var desc4Convert2Html = @"Converts a given MD content to HTML content";
                    var descTabDelim2MdTable = @"Converts the given tab delimited table to MarkDown table";
                    var descMdTbl2HtmlTbl = @"Converts the given MD table to HTML table";
                    var desc4Md2Html = @"Converts the given MD content to HTML content";

                    FunctionalityInfo<InputParamsBase> funcData2MdTable = new(nameof(Data2MdTbl), descTabDelim2MdTable,
                        new List<InputParams> {
                            new InputParams {
                                TabDelimitedData = @$"{SDKLibV5.Constants.MultiLineIndicator}TRANSACTION STATUS	DESCRIPTION
Approved	Transaction has been approved and is awaiting committal.
Closed	Transaction has been completed in the ExampleData database but has not been reconciled in downstream systems.
Committed	Transaction has been completed in all systems.
Declined	Transaction has been rejected by an underwriter.
Pending	Transaction is awaiting committal.
Referred	Transaction is awaiting approval.
Scheduled	Transaction is awaiting a batch process to complete it.
" } });
                    FunctionalityInfo<InputParamsBase> funcMdTbl2HtmlTbl = new(nameof(MdTbl2HtmlTbl), descMdTbl2HtmlTbl,
                        new List<InputParams> {
                            new InputParams {
                                MdTable = @$"{SDKLibV5.Constants.MultiLineIndicator}| TRANSACTION STATUS | DESCRIPTION                                                                                                   | 
| ------------------ | -------------------------------------------------------------------------------------------------------------  |
| Approved           | Transaction has been approved and is awaiting committal.                                                      | 
| Closed             | Transaction has been completed in the ExampleData database but has not been reconciled in downstream systems. | 
| Committed          | Transaction has been completed in all systems.                                                                | 
| Declined           | Transaction has been rejected by an underwriter.                                                              | 
| Pending            | Transaction is awaiting committal.                                                                            | 
| Referred           | Transaction is awaiting approval.                                                                             | 
| Scheduled          | Transaction is awaiting a batch process to complete it.                                                       | 

",
                            RowsToHighlight = "1, 5, 6"} });
                    FunctionalityInfo<InputParamsBase> funcConvertMd2Html = new(nameof(ConvertMd2Html), desc4Convert2Html,
                        new List<InputParams> {
                            new InputParams
                            {
                                MdFilesDirectory=@"C:\SDK\Dev\KB\t1",
                                CodeStyleTheme = $"obsidian   //##// [dark|light|tomorrow|sunburst|obsidian]",
                                BodyWidth = "1000px",
                                ParagraphColumnCount = 1
                            },

                            new InputParams
                        {
                            MdFileFullPath = @"c:\temp\file3.md",
                            HtmlOutputFile= @"c:\temp\output\file3.html"
                        }});

                    FunctionalityInfo<InputParamsBase> funcMd2Html = new(nameof(Md2Html), desc4Md2Html,
                            new List<InputParams> {
                                                    new InputParams
                                                    {
                                                        MdContent = $@"{SDKLibV5.Constants.MultiLineIndicator}# CodeGen 

This class provides code generation functionality

## SqLiteCRUDCmd
--------------------------
Generates C# code for the provided details in the input

<code>
Parameters
	TableName: Student
	TabDelimitedColumnsMetaData: <<multi-line~entry>>
StudentId	int     //##// or integer
FirstName	string //##// or text
LastName	string
GPA	real                  //##// or float, decimal
RegistrationDate	date //##// or time | datetime | string | text
</code>

| TRANSACTION STATUS | DESCRIPTION                                                                                                   | 
| ------------------ | -------------------------------------------------------------------------------------------------------------  |
| Approved           | Transaction has been approved and is awaiting committal.                                                      | 
| Closed             | Transaction has been completed in the ExampleData database but has not been reconciled in downstream systems. | 
| Committed          | Transaction has been completed in all systems.                                                                | 
| Declined           | Transaction has been rejected by an underwriter.                                                              | 
| Pending            | Transaction is awaiting committal.                                                                            | 
| Referred           | Transaction is awaiting approval.                                                                             | 
| Scheduled          | Transaction is awaiting a batch process to complete it.                                                       | 


## SqLiteCRUDWpf
--------------------------
Generates C# and XAML code for the provided details in the input
Parameters---


# DataStats

This class provides data statistics related operations

## GroupSingleColumn
--------------------------
Groups the given, single-column data
Parameters---
	ColumnIndex: 0
	TabDelimData: <<multi-line~entry>>Demo
SystemManuScripts
None
None
SystemManuScripts
Admin
Integration
SystemManuScripts
SystemManuScripts
SystemManuScripts
SystemManuScripts

## NormalizeDataByAColumn
--------------------------
Normalizes the given data by the specified column index
Parameters---
	ColumnIndex: 0
	FirstRowHasColumnNames: True
	TabDelimData: <<multi-line~entry>>Col1	Col2	Col3
A	Z1	TT
B	Z1	TX
B	Z2	TT
B	Z2	TX
C	Z2	TX
C	XX	TX
D	XY	TZ


## OrderByColumn
--------------------------
Orders the data by the specified column index
Parameters---
	ColumnIndex: 2
"
                                                    }});

                    List<FunctionalityInfo<InputParamsBase>> functionalities = new()
                    {
                        funcData2MdTable,
                        funcMdTbl2HtmlTbl,
                        funcConvertMd2Html,
                        funcMd2Html,
                    };
                    #endregion

                    _info = new DescribeMyFunctionality<InputParamsBase>(description, functionalities, new DateTime(2021, 5, 3));
                }
                return _info;
            }
        }

        internal class InputParams : InputParamsBase
        {
            public string MdFileFullPath { get; set; }
            public string HtmlOutputFile { get; set; }
            //--------------------
            public string TabDelimitedData { get; set; }
            public string RowsToHighlight { get; set; } = null;
            public string MdTable { get; set; } = null;
            //--------------------
            public string MdFilesDirectory { get; set; }
            public string HtmlOutputDirectory { get; set; }
            public string CodeStyleTheme { get; set; }
            public string BodyWidth { get; set; }
            public int? ParagraphColumnCount { get; set; }

            public string MdContent { get; set; }


            public InputParams() { }
            public InputParams(string inFile, string outFile = null)
            {
                MdFileFullPath = inFile;
                HtmlOutputFile = GetOutputFile(inFile, outFile);
            }

            private static string GetOutputFile(string inFile, string outFile)
            {
                var fileName = Path.GetFileNameWithoutExtension(inFile);
                var dirName = Path.GetDirectoryName(inFile);

                if (outFile is null || !outFile.ToLower().EndsWith("html"))
                    return Path.Combine(dirName, fileName + ".html");

                return outFile;
            }
        }
        #endregion

        #region Implementation
        public MarkDown2Html() { }

        public MarkDown2Html(string markdownContent, string targetPath = null)
        {
            _markdownContent = markdownContent;
            _path = targetPath;
        }

        internal sealed class Constants
        {
            public static char[] HRchars = { '-', '=', '_' };
            public static char[] Boldchars = { '_', '*' };
            public const string DefaultCSS = @"<link rel = ""stylesheet"" href=""resources/css/default_styles.css"">";

            internal const string DefaultMarkDownCSS = "Resources.Styles.DefaultStyleForMD.css";
            internal const string SyntaxHighlightJSSResource = "Resources.Styles.highlight.pack.js";
            internal const string SyntaxHighlightCSSResourceDark = "Resources.Styles.qtcreator_dark.css";
            internal const string SyntaxHighlightCSSResourceLight = "Resources.Styles.qtcreator_light.css";
            internal const string SyntaxHighlightCSSResourceObsidian = "Resources.Styles.obsidian.css";
            internal const string SyntaxHighlightCSSResourceSunburst = "Resources.Styles.sunburst.css";
            internal const string SyntaxHighlightCSSResourceTomorrow = "Resources.Styles.tomorrow.css";
            internal const string SyntaxHighlightVS = "Resources.Styles.vs.css";
            //            internal const string SyntaxHighlightInvoke = "\r\n<link rel=\"stylesheet\" href=\"highlight/qtcreator_dark.css\">\r\n" +
            //"<script src=\"highlight/highlight.pack.js\"></script>\r\n" +
            //"<script>hljs.initHighlightingOnLoad();</script>\t\t\r\n";
            internal const string rgxSentence = @"(\s*\w[\s,\?:'\!\.\@#\$%&\(\)\-\+=\/]?)";

            public static string EofComment => string.Empty; // "<!-- GEICO Confidential - file date: {DateTime.Now.ToString()} -->";

            public const string TableStyle1 = @".styled-table {
    border-collapse: collapse;
    margin: 25px 0;
    font-size: 0.9em;
    font-family: sans-serif;
    min-width: 400px;
    box-shadow: 0 0 20px rgba(0, 0, 0, 0.15);
}
.styled-table thead tr {
    background-color: #009879;
    color: #ffffff;
    text-align: left;
}
.styled-table th,
.styled-table td {
    padding: 12px 15px;
}
.styled-table tbody tr {
    border-bottom: 1px solid #dddddd;
}
.styled-table tbody tr:nth-of-type(even) {
    background-color: #f3f3f3;
}
.styled-table tbody tr:last-of-type {
    border-bottom: 2px solid #009879;
}
.styled-table tbody tr.active-row {
    font-weight: bold;
    color: #009879;
}
";
        }

        string _markdownContent;
        string _path;
        string prevLine = null;
        private string fileNotFoundImg = Environment.CurrentDirectory + @"\Resources\FileNotFound.png";


        internal string MdTbl2HtmlTbl(InputParams inputParams)
        {
            /*
                1st line contains headers
                2nd line is for visual
                3rd and subsequent lines are table contents
            */

            StringBuilder sb = new("<table class=\"styled-table\">");
            string[] lines = AddTableHeader(inputParams, sb);
            List<int> highlightRows = GetRowNumbers2Highlight(inputParams.RowsToHighlight);
            AddDataRows2Table(sb, lines, highlightRows);
            sb.AppendLine(@"    </tbody></table>");
            return sb.ToString().WrapInHTML(Constants.TableStyle1);
        }

        private static void AddDataRows2Table(StringBuilder sb, string[] lines, List<int> highlightRows)
        {
            for (int i = 2; i < lines.Length; i++)
            {
                if (highlightRows.Any(n => n == i - 1))
                    sb.AppendLine("<tr class=\"active-row\">");
                else
                    sb.AppendLine("<tr>");

                var colValues = lines[i].Split('|');
                foreach (var colVal in colValues)
                {
                    sb.AppendLine($"<td>{colVal.Trim()}</td>");
                }

                sb.AppendLine("</tr>");

            }
        }

        private List<int> GetRowNumbers2Highlight(string rowsToHighlight)
        {
            var rows2Highlight = rowsToHighlight.Split(',');
            List<int> highlightRows = new List<int>();
            foreach (var row in rows2Highlight)
            {
                if (int.TryParse(row, out var num))
                {
                    highlightRows.Add(num);
                }
            }

            return highlightRows;
        }

        private string[] AddTableHeader(InputParams inputParams, StringBuilder sb)
        {
            sb.AppendLine(@"    <thead>
        <tr>");

            VerifyValidMDTableContent();

            string mdContent = inputParams.MdTable.Trim();
            var lines = mdContent.ToLines();

            var columnNames = lines[0].Split('|');
            foreach (var col in columnNames)
            {
                sb.AppendLine($"<th>{col.Trim()}</th>");
            }
            sb.AppendLine(@"        </tr>
    </thead>
    <tbody>
");
            return lines;
        }

        private void VerifyValidMDTableContent()
        {
            // TODO: Throw if unexpected content
            // throw new NotImplementedException();

        }

        internal void ConvertMd2Html(InputParams pars)
        {
            // outFile = actual implementation starts here
            string path = @"C:\SDK\Dev\KB\t1";
            string theme = "obsidian";
            string bodyWidth = "1000px";
            string columnCount = "1";

            string trg = Path.Combine(path, "toHtml");

            if (!Directory.Exists(trg))
                Directory.CreateDirectory(trg);
            string[] files = Directory.GetFiles(path, "*.md*");

            foreach (string file in files)
            {
                using StreamReader sr = new(file);
                _markdownContent = sr.ReadToEnd();
                var htmlContent = ToHTML(true, theme, bodyWidth, columnCount);

                string trgFile = Path.Combine(trg, Path.GetFileNameWithoutExtension(file)) + ".html";
                File.WriteAllText(trgFile, htmlContent);
            }

            // txtOutput.Text += "Done - " + DateTime.Now.ToString() + " - " + files.Length.ToString() + " files ready\r\n";
        }

        #region ConvertMd2Html

        internal string Md2Html(InputParams inParams)
        {
            _markdownContent = inParams.MdContent;
            string theme = "obsidian";
            string bodyWidth = "1000px";
            string columnCount = "1";

            var htmlContent = ToHTML(true, theme, bodyWidth, columnCount);
            return htmlContent;
        }

        public string ToHTML(bool useEmbeddedCSS = false,
                             string syntaxHighlightingColor = "dark",
                             string bodyWidth = "800px",
                             string columnCount = "2",
                             bool export = false)
        {
            prevLine = null;
            StringBuilder sb = new StringBuilder();
            string pageTitle = GetTitle();
            string embeddedCSS = Constants.DefaultCSS;
            string embeddedCodeSyntaxHighlight = string.Empty;

            if (useEmbeddedCSS)
            {
                embeddedCSS = "\r\n<style>"
                    + GetEmbeddedResourceText(Constants.DefaultMarkDownCSS)
                      .Replace("-:#$%bodyWidth$#:-", bodyWidth)
                      .Replace("-:#$%columnCount$#:-", columnCount)
                    + "\r\n</style>\r\n";
            }

            if (_markdownContent.Contains("```"))
            {
                embeddedCodeSyntaxHighlight = AddSyntaxHighlighting(syntaxHighlightingColor);
            }

            sb.AppendLine($"<!DOCTYPE html><html><head><meta http-equiv=\"Content-Type\" content=\"text/html;charset=UTF-8\">\r\n<title>{pageTitle}</title>{embeddedCSS}"
                + embeddedCodeSyntaxHighlight
                + "</head><body>");

            sb.AppendLine("<div class=\"newspaper\">");
            string[] lines = _markdownContent.Split(new string[] { "\r\n", "\n", "\r" }, StringSplitOptions.None);
            bool listStarted = false;
            var paragraphStarted = ApplyMarkdownRules(export, sb, lines, ref listStarted);

            if (paragraphStarted)
                sb.Append("</p>");

            sb.AppendLine("</div>");
            sb.AppendLine($"</body></html>" + Constants.EofComment);

            return sb.ToString();
        }

        private string GetTitle()
        {
            var pattern = @"<title>(\w+\s*)+</title>";
            Regex rgx = new Regex(pattern, RegexOptions.IgnoreCase);

            if (rgx.IsMatch(_markdownContent))
            {
                var title = rgx.Match(_markdownContent).Value;
                _markdownContent = rgx.Replace(_markdownContent, string.Empty);
                return title;
            }

            return "<title>default title</title>";
        }

        private bool ApplyMarkdownRules(bool export, StringBuilder sb, string[] lines, ref bool listStarted)
        {
            bool paragraphStarted = false;
            for (int i = 0; i < lines.Length; i++)
            {
                string line = lines[i].Trim();

                //if (line.Length == 0)
                //    continue;

                if (i > 0)
                    prevLine = lines[i - 1].Trim();

                if (line.StartsWith("```"))
                {
                    sb.AppendLine(GetCodeBlock(lines, ref i));
                    i++; // skip the line with closing 
                }
                else
                {

                    if (line.Length == 0)
                    {
                        if (prevLine != null && prevLine.Length > 0)
                        {
                            if (listStarted)
                            {
                                sb.Append("</ul>");
                                listStarted = false;
                            }

                            if (paragraphStarted)
                            {
                                sb.Append("</p>");
                                paragraphStarted = false;
                            }
                        }
                        continue;
                    }

                    string output;

                    if (isHR(line))
                    {
                        if (listStarted)
                        {
                            sb.Append("</ul>");
                            listStarted = false;
                        }

                        if (paragraphStarted)
                        {
                            sb.Append("</p>");
                            paragraphStarted = false;
                        }

                        sb.AppendLine("<hr>");
                    }
                    else if (isH(6, line, out output)
                        || isH(5, line, out output)
                        || isH(4, line, out output)
                        || isH(3, line, out output)
                        || isH(2, line, out output)
                        || isH(1, line, out output)
                        )
                    {
                        if (listStarted)
                        {
                            sb.Append("</ul>");
                            listStarted = false;
                        }

                        if (paragraphStarted)
                        {
                            sb.Append("</p>");
                            paragraphStarted = false;
                        }

                        sb.AppendLine(output);
                    }
                    else
                    {
                        bool tableResolved;
                        line = ResolveTable(lines, ref i, out tableResolved);

                        if (!tableResolved)
                        {
                            line = ResolveH1H2Headers(lines, ref i, out tableResolved);

                            if (!tableResolved)
                            {
                                if (!ResolveList(lines, ref i, ref line, export))
                                {
                                    line = ResolveItalicAndBold(line);
                                    line = ResolveLink(line);
                                    line = ResolveImage(line, true, export);
                                }

                                if (!paragraphStarted)
                                {
                                    sb.Append("<p>");
                                    paragraphStarted = true;
                                }
                            }
                        }
                        // sb.AppendLine(TextUtil.EscapeHTMLChars(line));
                        sb.AppendLine(line);
                    }
                } // if !(line.StartsWith("```"))
            } // for(int i=0; i<lines.Length; i++)

            return paragraphStarted;
        }

        private string AddSyntaxHighlighting(string syntaxHighlightingColor)
        {
            string embeddedCodeSyntaxHighlight;
            string syntaxHighlightingCSSFile = Constants.SyntaxHighlightCSSResourceDark;

            switch (syntaxHighlightingColor)
            {
                case "light":
                    syntaxHighlightingCSSFile = Constants.SyntaxHighlightCSSResourceLight;
                    break;
                case "tomorrow":
                    syntaxHighlightingCSSFile = Constants.SyntaxHighlightCSSResourceTomorrow;
                    break;
                case "sunburst":
                    syntaxHighlightingCSSFile = Constants.SyntaxHighlightCSSResourceSunburst;
                    break;
                case "obsidian":
                    syntaxHighlightingCSSFile = Constants.SyntaxHighlightCSSResourceObsidian;
                    break;
                case "vs":
                    syntaxHighlightingCSSFile = Constants.SyntaxHighlightVS;
                    break;
            }

            embeddedCodeSyntaxHighlight = "\r\n<script type=\"text/javascript\">\r\n"
                + GetEmbeddedResourceText(Constants.SyntaxHighlightJSSResource)
                .Replace("\"</script>\"", "\"&lt;/script&gt;\"") // I don't have time to investigate why that is for now
                + "</script>"
                + "<style>"
                + GetEmbeddedResourceText(syntaxHighlightingCSSFile)
                + "</style>"
                + "\r\n<script>hljs.initHighlightingOnLoad();</script>";
            return embeddedCodeSyntaxHighlight;
        }

        private string GetEmbeddedResourceText(string manifestResourceName)
        {
            string embeddedResourceContent = "Resource Not Found";

            string assemblyName = typeof(MarkDown2Html).Assembly.GetName().Name;
            manifestResourceName = $"{assemblyName}.{manifestResourceName}";

            var assembly = Assembly.GetExecutingAssembly();

            using (Stream stream = assembly.GetManifestResourceStream(manifestResourceName))
            using (StreamReader reader = new StreamReader(stream))
            {
                embeddedResourceContent = reader.ReadToEnd();
            }

            return embeddedResourceContent;
        }

        private string GetCodeBlock(string[] lines, ref int i)
        {
            StringBuilder sb = new StringBuilder();

            string lang = lines[i].Trim().Replace("`", "");
            i++; // skip the line with ```typescrip

            if (lang == "")
                lang = "TypeScript";

            sb.AppendLine($"<pre><code class=\"{lang}\">");

            int j = i;
            for (; j < lines.Length; j++)
            {
                string line = System.Web.HttpUtility.HtmlEncode(lines[j]);

                if (line.Trim().StartsWith("```"))
                {
                    break;
                }
                else
                    sb.AppendLine(line);
            }

            i = j;

            sb.AppendLine("</code></pre>");
            return sb.ToString();
        }

        private string ResolveTable(string[] lines, ref int dX, out bool resolved)
        {
            resolved = false;

            StringBuilder output = new StringBuilder();
            Regex rgx = new Regex(@"\|.*\|$");
            Regex rgx2 = new Regex(@"\|\s*---*.*\|$");

            int i = dX;

            string line = lines[dX];

            if (i < lines.Length - 1 && rgx.IsMatch(line) && rgx2.IsMatch(lines[i + 1]))
            {
                output.AppendLine("<table>");
                output.AppendLine("<tr>");

                line = lines[i];

                string[] colHeaders = line.Split(new char[] { '|' }, StringSplitOptions.RemoveEmptyEntries);

                foreach (string hdr in colHeaders)
                    output.Append($"<th>{hdr.Trim()}</th>");
                output.AppendLine();
                output.AppendLine("</tr>");

                i++;
                line = lines[++i];
                while (i < lines.Length - 1 && rgx.IsMatch(line))
                {
                    string[] cellValues = line.Split(new char[] { '|' }, StringSplitOptions.RemoveEmptyEntries);
                    output.AppendLine("<tr>");

                    foreach (string cell in cellValues)
                        output.Append($"<td>{cell.Trim()}</td>");
                    output.AppendLine("</tr>");

                    line = lines[++i];
                }

                output.AppendLine("</table>");
            }
            else
            {
                return line;
            }

            dX = i;
            resolved = true;
            return "\r\n" + output.ToString() + "\r\n";
        }

        private string ResolveH1H2Headers(string[] lines, ref int dx, out bool resolved)
        {
            resolved = false;
            int i = dx;
            StringBuilder output = new StringBuilder();
            Regex rgxH1 = new Regex(@"^\s*\=\=\=[\=]*\s*$");
            Regex rgxH2 = new Regex(@"^\s*\-\-\-[\-]*\s*$");

            string line = lines[i];
            output.AppendLine(line);

            if (i < lines.Length - 1)
            {
                if (rgxH1.IsMatch(lines[i + 1]))
                {
                    output.Clear();
                    output.AppendLine("<h1>" + line + "</h1>");
                    resolved = true;
                }
                else if (rgxH2.IsMatch(lines[i + 1]))
                {
                    output.Clear();
                    output.AppendLine("<h2>" + line + "</h2>");
                    resolved = true;
                }

                if (resolved)
                    dx = i + 1;
            }

            return output.ToString();
        }

        // ![alt text](file:///C:/SDK/KB/temp/imgeab91e3f-9ccb-4fc4-9151-25de72cfa4bc.png "image")
        // <img src="file:///C:/SDK/KB/temp/imgeab91e3f-9ccb-4fc4-9151-25de72cfa4bc.png" alt="alt text" title="image">
        private string ResolveImage(string line, bool makeHyperLinks = false, bool export = false)
        {
            string fileNamePtrn = @"file:///(\w+:)?/(\w+/)*[A-Za-z0-9-\.%]*\.png";
            string sentence = @"(\s*\w+[ ,\?'\!\@#\$%&\(\)\-_\+=/]*)*";
            string titleText = @"""" + sentence + @"""";
            Regex rgx = new Regex(@"\!\[" + sentence + @"\]\s*\(" + fileNamePtrn + @"\s*(" + titleText + @")?\s*\)");
            string output = line;

            if (rgx.IsMatch(line))
            {
                Regex rgx1 = new Regex(@"\[" + sentence + @"\]"); // required -- alt text
                Regex rgx2 = new Regex(fileNamePtrn); // required -- uri
                Regex rgx4 = new Regex(titleText); // optional

                string altText = rgx1.Match(line).Value.Replace("[", "").Replace("]", "");
                var linkpart = rgx2.Match(line).Value;

                if (export)
                {
                    var localPath = new Uri(linkpart).LocalPath;
                    string desFile = Path.Combine(_path, "toHtml");
                    if (!Directory.Exists(desFile))
                        Directory.CreateDirectory(desFile);

                    desFile = Path.Combine(desFile, "resources");
                    if (!Directory.Exists(desFile))
                        Directory.CreateDirectory(desFile);

                    if (!File.Exists(localPath))
                        localPath = fileNotFoundImg;
                    desFile = Path.Combine(desFile, Path.GetFileName(localPath));
                    File.Copy(localPath, desFile, true);

                    linkpart = "resources/" + Path.GetFileName(localPath);
                }
                if (rgx4.IsMatch(line))
                {
                    string linkText = rgx4.Match(line).Value.Replace("[", "").Replace("]", "");
                    string linkTitle = rgx4.Match(line).Value.Replace("\"", "");
                    if (makeHyperLinks)
                    {
                        // output = $"<a href=\"{linkpart}\">\r\n";
                        output = rgx.Replace(line, $"<a href=\"{linkpart}\">" + "<img src=\"" + linkpart + "\" alt=\"" + altText + "\" title=\"" + linkTitle + "\"></a>\r\n");
                        // output += "</a>";
                    }
                    else
                        output = rgx.Replace(line, "<img src=\"" + linkpart + "\" alt=\"" + altText + "\" title=\"" + linkTitle + "\">");
                }
                else
                {
                    if (makeHyperLinks)
                    {
                        output = $"<a href=\"{linkpart}\">\r\n";
                        output = rgx.Replace(line, "<img src=\"" + linkpart + "\" alt=\"" + altText + "\">");
                        output += "</a>";
                    }
                    else
                        output = rgx.Replace(line, "<img src=\"" + linkpart + "\" alt=\"" + altText + "\">");
                }
            }

            return output;



        }

        /// <summary>
        /// a list is defined as at least two lines each starting with the same list indicator
        /// </summary>
        /// <param name="lines"></param>
        /// <param name="dX"></param>
        /// <returns></returns>
        bool ResolveList(string[] lines, ref int dX, ref string currline, bool export = false)
        {
            StringBuilder output = new StringBuilder();
            string ptrnBullet = @"^\s*[\*\-\+#]+\s+";
            string ptrnNum = @"^\s*\d+[\.\-]\s+";

            Regex rgxBulle = new Regex(ptrnBullet);
            Regex rgx2 = new Regex(ptrnBullet + @"\w+");
            Regex rgxNum = new Regex(ptrnNum + @"(\[\s*\w*\]\s*)?\w.*");
            Regex rgx = new Regex(@"\s*[\*\-\+#]+\s+");
            bool moreItemsExist = false;

            string listTAG = "ul";
            int i = dX;

            string line = lines[dX];
            string line2 = "";

            if (rgx2.IsMatch(line))
            {
                do
                {
                    line = lines[i];

                    line = ResolveItalicAndBold(line);
                    line = ResolveLink(line);
                    line = ResolveImage(line, true, export);

                    if (i < lines.Length - 1)
                    {
                        if (rgx2.IsMatch(lines[i + 1]))
                            rgx = new Regex(@"\s*[\*\-\+#]+\s+");
                        output.AppendLine(rgx.Replace(line, "<li>") + "</li>");
                        moreItemsExist = true;
                    }

                } while (i < lines.Length - 1 && rgxBulle.IsMatch(lines[++i]));

                if (moreItemsExist)
                {
                    line = lines[i];
                    rgx = new Regex(@"\s*[\*\-\+#]+\s+");
                    output.AppendLine(rgx.Replace(line, "<li>") + "</li>");
                }
            }
            else if (rgxNum.IsMatch(line))
            {
                moreItemsExist = false;
                listTAG = "ol";

                do
                {
                    line = lines[i];

                    line = ResolveItalicAndBold(line);
                    line = ResolveLink(line);
                    line = ResolveImage(line, true, export);

                    if (i < lines.Length - 1)
                    {
                        if (rgxNum.IsMatch(lines[i]))
                        {
                            rgx = new Regex(ptrnNum);
                            output.AppendLine(rgx.Replace(line, "<li>") + "</li>");
                            moreItemsExist = true;
                        }
                    }

                } while (i < lines.Length - 1 && rgxNum.IsMatch(lines[++i]));

                if (moreItemsExist)
                {
                    line = lines[i];
                    rgx = new Regex(ptrnNum);
                    output.AppendLine(rgx.Replace(line, "<li>") + "</li>");
                }
            }
            else
            {
                // return line;
                return false;
            }

            dX = i;
            currline = "\r\n<" + listTAG + ">\r\n" + output.ToString() + "</" + listTAG + ">\r\n";
            return true;
        }

        // [GitHub](http://github.com)
        // <a href="http://github.com">GitHub</a>
        private string ResolveLink(string line)
        {
            /*
            This is [an example](http://example.com/ "Title") inline link.

            [This link](http://example.net/) has no title attribute.
            Will produce:

            <p>This is <a href="http://example.com/" title="Title attribute shows a tooltip">
            an example</a> inline link with tool tip.</p>

            <p><a href="http://example.net/">This link</a> has no
            title attribute.</p>
            */

            // string linkOnlyPtrn = @"https?://(\w+\.)?[-a-zA-Z0-9@:%._\+~#=\.]+/?";
            string linkOnlyPtrn = @"((http|ftp|https):\/\/|file:\/\/\/)([\w_-]+(?:(?:\.[\w_-]+)+))([\w.,@?^=%&:\/~+#-_]*[\w@?^=%&\/~+#-])?";

            string linkSentence = @"\[" + Constants.rgxSentence + @"*\]";
            string tooltipSentence = @"""" + Constants.rgxSentence + @"*""";
            Regex rgx = new Regex(linkSentence + @"\s*\(\s*" + linkOnlyPtrn + @"\s*(" + tooltipSentence + @")?\s*\)");
            Regex rgx2 = new Regex(linkOnlyPtrn); // required
            Regex rgx3 = new Regex(linkSentence); // required
            Regex rgx4 = new Regex(tooltipSentence); // optional
            string output = line;

            if (rgx.IsMatch(line))
            {
                var linkpart = rgx2.Match(line).Value;
                string linkText = rgx3.Match(line).Value.Replace("[", "").Replace("]", "");

                if (rgx4.IsMatch(line))
                {
                    string linkTitle = rgx4.Match(line).Value.Replace("\"", "");

                    output = rgx.Replace(line, "<a href=\"" + linkpart + "\" title=\"" + linkTitle + "\">" + linkText + "</a>");
                }
                else
                    output = rgx.Replace(line, "<a href=\"" + linkpart + "\">" + linkText + "</a>");
            }

            return output;
        }

        private string ResolveItalicAndBold(string line)
        {
            Regex rgx = new Regex(@"__" + Constants.rgxSentence + "+__", RegexOptions.Singleline);

            try
            {

                if (rgx.IsMatch(line))
                {
                    var matchs = rgx.Matches(line);

                    for (int i = 0; i < matchs.Count; i++)
                    {
                        string replacr = matchs[i].Value;
                        replacr = "<strong>" + replacr.Substring(2);
                        replacr = replacr.Substring(0, replacr.Length - 2) + "</strong>";

                        line = line.Replace(matchs[i].Value, replacr);
                    }
                }
            }
            catch (Exception ex)
            {
                var x = ex;
            }

            rgx = new Regex(@"\*\*" + Constants.rgxSentence + @"+\*\*");
            if (rgx.IsMatch(line))
            {
                var matchs = rgx.Matches(line);

                for (int i = 0; i < matchs.Count; i++)
                {
                    string replacr = matchs[i].Value;
                    replacr = "<strong>" + replacr.Substring(2);
                    replacr = replacr.Substring(0, replacr.Length - 2) + "</strong>";

                    line = line.Replace(matchs[i].Value, replacr);
                }
            }

            line = ApplyItalics(line);

            rgx = new Regex(@"\*" + Constants.rgxSentence + @"+\*");
            if (rgx.IsMatch(line))
            {
                var matchs = rgx.Matches(line);

                for (int i = 0; i < matchs.Count; i++)
                {
                    string replacr = matchs[i].Value;
                    replacr = "<em>" + replacr.Substring(1);
                    replacr = replacr.Substring(0, replacr.Length - 1) + "</em>";

                    line = line.Replace(matchs[i].Value, replacr);
                }
            }

            return line;
        }

        private static string ApplyItalics(string line)
        {
            Regex rgx = new Regex(@"\b_" + Constants.rgxSentence + "+_\b");
            if (rgx.IsMatch(line))
            {
                var matchs = rgx.Matches(line);

                for (int i = 0; i < matchs.Count; i++)
                {
                    string replacr = matchs[i].Value;
                    replacr = "<em>" + replacr.Substring(1);
                    replacr = replacr.Substring(0, replacr.Length - 1) + "</em>";

                    line = line.Replace(matchs[i].Value, replacr);
                }
            }

            return line;
        }

        private string isBold(string line)
        {
            string output = "";
            Regex rgx = new Regex(@"__.*__");

            if (rgx.IsMatch(line))
            {
                rgx = new Regex(@"__\b");
                output = rgx.Replace(line, "</strong>");
                rgx = new Regex(@"\b__");
                output = rgx.Replace(output, "<strong>");
            }

            rgx = new Regex(@"\*\*\b.*\*\*");
            if (rgx.IsMatch(line))
            {
                rgx = new Regex(@"\*\*\b");
                output = rgx.Replace(line, "</strong>");
                rgx = new Regex(@"\b\*\*");
                output = rgx.Replace(output, "<strong>");
            }

            return output;
        }

        private bool isH(int headerType, string line, out string output)
        {
            Regex rgx = new Regex(@"^#\s+\b");
            string sTag = "<h1>";
            string eTag = "</h1>";

            switch (headerType)
            {
                case 6:
                    sTag = "<h6>";
                    eTag = "</h6>";
                    rgx = new Regex(@"^######\s+\b");
                    break;
                case 5:
                    sTag = "<h5>";
                    eTag = "</h5>";
                    rgx = new Regex(@"^#####\s+\b");
                    break;
                case 4:
                    sTag = "<h4>";
                    eTag = "</h4>";
                    rgx = new Regex(@"^####\s+\b");
                    break;
                case 3:
                    sTag = "<h3>";
                    eTag = "</h3>";
                    rgx = new Regex(@"^###\s+\b");
                    break;
                case 2:
                    sTag = "<h2>";
                    eTag = "</h2>";
                    rgx = new Regex(@"^##\s+\b");
                    break;
            }

            output = rgx.Replace(line, "");
            output = sTag + output + eTag;

            if (rgx.IsMatch(line))
                return true;

            return false;
        }


        private bool isHR(string line)
        {
            if (line.Length > 2)
            {
                foreach (char ch in Constants.HRchars)
                    if (ch == line[0] && ch == line[1] && ch == line[2] & (prevLine == null || prevLine.Length == 0))
                        return true;
            }

            return false;
        }

        internal string Data2MdTbl(InputParams inputParams)
        {
            string[] lines = inputParams.TabDelimitedData.Split(new string[] { "\r\n" }, StringSplitOptions.RemoveEmptyEntries);

            StringBuilder sb = new StringBuilder();
            List<int> colWidths = new List<int>();

            // get column widths
            for (int i = 0; i < lines.Length; i++)
            {
                string line = lines[i];
                string[] cols = line.Split('\t');
                if (i == 0)
                    for (int j = 0; j < cols.Length; j++)
                    {
                        colWidths.Add(cols[j].Length);
                    }

                for (int j = 0; j < cols.Length; j++)
                {
                    if (colWidths[j] < cols[j].Length)
                        colWidths[j] = cols[j].Length;
                }
            }
            /*
            |----|----|----|
            | Col1 | Col2 | Col3 | |----|----|----|

            v11 | v12 | v13 | 
            v21 | v22 | 23 | 
            31 | 32 | 33 | 
            41 | 42 | 43 | 
            51 | 52 | 53 | 

            */
            for (int i = 0; i < lines.Length; i++)
            {
                string line = lines[i];
                string[] cols = line.Split('\t');
                if (i == 0)
                {
                    sb.Append("| ");
                    for (int j = 0; j < cols.Length; j++)
                    {
                        sb.Append(cols[j].PadRight(colWidths[j]) + " | ");
                    }
                    sb.AppendLine("");
                    sb.AppendLine(GetBorders(colWidths));
                }
                else
                {
                    sb.Append("| ");
                    for (int j = 0; j < cols.Length; j++)
                    {
                        sb.Append(cols[j].PadRight(colWidths[j]) + " | ");
                    }
                    sb.AppendLine("");
                }
            }
            return sb.ToString();
        }

        private static string GetBorders(List<int> cols)
        {
            StringBuilder sb = new StringBuilder();

            for (int j = 0; j < cols.Count; j++)
            {
                sb.Append("| ");
                for (int i = 0; i < cols[j]; i++)
                    sb.Append('-');
                sb.Append(" ");
            }
            sb.Append(" |");

            return sb.ToString();
        }

        #endregion

        #region ConvertData2MDTable

        public string ToMarkdownTable(DataTable tbl)
        {
            var sbQryPrefix = new StringBuilder();
            for (int i = 0; i < tbl.Columns.Count; i++)
            {
                sbQryPrefix.Append($"{tbl.Columns[i].ColumnName}"
                    + (i < tbl.Columns.Count - 1 ? "\t" : ""));
            }

            List<string> lst = new List<string>();

            lst.Add(sbQryPrefix.ToString());

            var sb = new StringBuilder();
            for (int j = 0; j < tbl.Rows.Count; j++)
            {
                sb.Clear();
                var dr = tbl.Rows[j];

                for (int i = 0; i < dr.Table.Columns.Count; i++)
                {
                    var postFx = i < tbl.Columns.Count - 1 ? "\t" : "";
                    if (dr[i] == DBNull.Value)
                    {
                        sb.Append($"NULL" + postFx);
                        continue;
                    }

                    sb.Append($"{dr[i].ToString()}" + postFx);
                }

                lst.Add(sb.ToString());
            } // foreach

            return GetMDTableFromListOfStrings(lst);
        }

        /// <summary>
        /// Converts the given list of strings with tab delimited values to an MD table
        /// </summary>
        /// <param name="noneEmptyLines">Tab delimited values</param>
        /// <returns></returns>
        public string GetMDTableFromListOfStrings(List<string> noneEmptyLines)
        {
            StringBuilder sb = new StringBuilder();
            int[] colWidths = GetColWidths(noneEmptyLines);
            Type[] colTypes = GetDataTypes(noneEmptyLines);

            string headerSection = GetHeaderSection(noneEmptyLines[0], colWidths, colTypes);
            sb.Append(headerSection);

            for (int i = 1; i < noneEmptyLines.Count; i++)
            {
                sb.Append(GetCellData(noneEmptyLines[i], colWidths));
            }
            return sb.ToString();
        }

        private string GetCellData(string rowData, int[] colWidths)
        {
            StringBuilder sb = new StringBuilder();

            string[] colsData = rowData.Split('\t');

            for (int i = 0; i < colsData.Length; i++)
            {
                sb.Append("|" + colsData[i].Trim().Pad2Center(colWidths[i], ' '));
            }
            sb.AppendLine("|");

            return sb.ToString();
        }

        private string GetHeaderSection(string headerLine, int[] colWidths, Type[] types = null)
        {
            StringBuilder sb = new StringBuilder();

            string[] colsData = headerLine.Split('\t');

            for (int i = 0; i < colsData.Length; i++)
            {
                sb.Append("|" + colsData[i].Trim().Pad2Center(colWidths[i], ' '));
            }

            sb.AppendLine(" |");
            for (int i = 0; i < colsData.Length; i++)
            {
                if (types != null && (types[i] == typeof(double) || types[i] == typeof(long)))
                {
                    sb.Append("| " + "-".PadRight(colWidths[i], '-') + ":");
                }
                else
                    sb.Append("| " + "-".PadRight(colWidths[i], '-') + " ");
            }
            sb.AppendLine(" |");

            return sb.ToString();
        }

        int[] GetColWidths(List<string> excelDataRows)
        {
            int[] colWidths = new int[excelDataRows[0].Split('\t').Length];

            foreach (var row in excelDataRows)
            {
                string[] parts = row.Split('\t');

                for (int i = 0; i < parts.Length; i++)
                {
                    if (colWidths[i] < parts[i].Trim().Length)
                        colWidths[i] = parts[i].Trim().Length;
                }
            }
            return colWidths;
        }

        private Type[] GetDataTypes(List<string> noneEmptyLines)
        {
            var arr = ToColData(noneEmptyLines);
            Type[] types = new Type[noneEmptyLines[0].Split('\t').Length];
            for (int i = 0; i < arr.Length; i++)
            {
                types[i] = GetDataType(arr[i]);
            }

            return types;
        }

        private Type GetDataType(string[] lines)
        {
            if (AllDates(lines))
                return typeof(System.DateTime);
            if (AllLongs(lines))
                return typeof(long);
            if (AllDoubles(lines))
                return typeof(double);

            return typeof(string);
        }

        private bool AllDates(string[] lines)
        {
            DateTime dt;

            foreach (var line in lines)
            {
                if (line == "") continue;
                if (!DateTime.TryParse(line, out dt))
                    return false;
            }
            return true;
        }

        private bool AllLongs(string[] lines)
        {
            long dt;

            foreach (var line in lines)
            {
                if (line == "") continue;
                if (!long.TryParse(line, out dt))
                    return false;
            }
            return true;
        }

        private bool AllDoubles(string[] lines)
        {
            double dt;

            foreach (var line in lines)
            {
                if (line == "") continue;
                if (!double.TryParse(line, out dt))
                    return false;
            }
            return true;
        }

        string[][] ToColData(List<string> data)
        {
            int colCt = data[0].Split('\t').Length;
            string[][] arr = new string[colCt][];

            for (int i = 0; i < colCt; i++)
            {
                arr[i] = new string[data.Count - 1];
            }

            for (int j = 0; j < colCt; j++)
                for (int i = 1; i < data.Count; i++)
                {
                    var colVals = data[i].Split('\t');
                    string celVal = "";

                    if (colVals.Length > j)
                        celVal = colVals[j];

                    arr[j][i - 1] = celVal;
                }

            return arr;
        }

        #endregion
        #endregion


        #region MarkDownUtil

        string Pad2Center(string content, int width, char chr)
        {
            content = content.Trim();
            int len = content.Length;

            if (len > width)
                return content;

            StringBuilder sb = new StringBuilder();

            double left = (width - len) / 2.0;

            var ll = System.Math.Floor(left) + 1;
            var rr = System.Math.Ceiling(left) + 1;

            for (int i = 0; i < ll; i++)
            {
                sb.Append(chr);
            }

            sb.Append(content);

            for (int i = 0; i < rr; i++)
            {
                sb.Append(chr);
            }

            return sb.ToString();
        }

        #endregion

    }

}