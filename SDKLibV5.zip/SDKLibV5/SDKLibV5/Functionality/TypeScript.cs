﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SDKLibV5.Functionality
{
    internal sealed class TypeScript : FunctionalityBase
    {
        #region IDescribeMyFunctionality
        private static DescribeMyFunctionality<InputParamsBase> _info;
        /// <summary>
        ///     Functionality Info
        /// </summary>
        internal static DescribeMyFunctionality<InputParamsBase> Info
        {
            get
            {
                if (_info is null)
                {
                    #region Class Functionality Definitions and sample inputs
                    var description = @"This class provides TypeScript related code generators and other functionality. PS. Although there is a ConGen that basically does the same things, I decided to create a separate category for TypeScript functionality for convenience ";
                    var desc4ClassWGetSettters = @"Provides a TypeScript class for the listed fields";
                    FunctionalityInfo<InputParamsBase> funcClasswSettrs = new(nameof(ClassWSetters), desc4ClassWGetSettters,
                        new List<InputParams> { new("Person", Constants.MultiLineIndicator + @"age: number
firstName: string
lastName: string
") });
                    List<FunctionalityInfo<InputParamsBase>> functionalities = new()
                    {
                        funcClasswSettrs
                    };
                    #endregion
                    _info = new DescribeMyFunctionality<InputParamsBase>(description, functionalities, new DateTime(2021, 5, 31));
                }
                return _info;
            }
        }
        public class InputParams : InputParamsBase
        {
            public string ClassName { get; set; }
            public string FieldsInfo { get; set; }
            public InputParams(string className, string fieldsInfo) 
            {
                ClassName = className;
                FieldsInfo = fieldsInfo;
            }
        }
        #endregion
        #region Implementations
        internal string ClassWSetters(InputParams inputParams)
        {
            StringBuilder sb = new($"class {inputParams.ClassName} {{\r\n");

            var lines = inputParams.FieldsInfo.ToLines();

            foreach (string line in lines)
            {
                var fieldAndValue = line.Split(':');
                var field = fieldAndValue[0].Trim();
                var typeName = fieldAndValue[1].Trim().Replace(";", "");
                field = char.ToLower(field[0]) + field.Substring(1);
                sb.AppendLine($"\tprivate _{field}: {typeName};");
            }

            sb.AppendLine("");

            foreach (string line in lines)
            {
                var fieldAndValue = line.Split(':');
                var field = fieldAndValue[0].Trim();
                var typeName = fieldAndValue[1].Trim().Replace(";", "");
                field = char.ToLower(field[0]) + field.Substring(1);
                sb.AppendLine($"\tpublic get {field}() {{");
                sb.AppendLine($"\t\treturn this._{field};");
                sb.AppendLine("\t}\r\n");

                sb.AppendLine($"\tpublic set {field}({field}Input: {typeName}) {{");
                sb.AppendLine($"\t\tthis._{field} = {field}Input;");
                sb.AppendLine("\t}\r\n");
            }
            sb.AppendLine("}");


            return sb.ToString();
        }
        #endregion
    }
}
