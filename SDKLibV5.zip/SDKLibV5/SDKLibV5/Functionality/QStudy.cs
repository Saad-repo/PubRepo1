﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SDKLibV5.Functionality
{
    internal sealed class QStudy : FunctionalityBase
    {

        #region IDescribeMyFunctionality
        private static DescribeMyFunctionality<InputParamsBase> _info;

        /// <summary>
        ///     Functionality Info
        /// </summary>
        internal static DescribeMyFunctionality<InputParamsBase> Info
        {
            get
            {
                if (_info is null)
                {
                    #region Class Functionality Definitions and sample inputs
                    var description = @"This class provides Quran study related operations";
                    var desc4BarChart = @"Creates SVG for the given Quran surahs in the book-order";
                    var desc4BarChartByLength = @"Creates SVG for the given Quran surahs in the surah-lenght order";
                    var desc4BarChartByLocationAndLength = @"Creates SVG for the given Quran surahs in the location and surah-lenght order";
                    var qData = @"001	Al-Fatiha	7	Makkah
002	Al-Baqarah	286	Madinah
003	Al Imran	200	Madinah
004	An-Nisa	176	Madinah
005	Al-Ma'idah	120	Madinah
006	Al-An'am	165	Makkah
007	Al-A'raf	206	Makkah
008	Al-Anfal	75	Madinah
009	At-Tawbah	129	Madinah
010	Yunus	109	Makkah
011	Hud	123	Makkah
012	Yusuf	111	Makkah
013	Ar-Ra'd	43	Madinah
014	Ibrahim	52	Makkah
015	Al-Hijr	99	Makkah
016	An-Nahl	128	Makkah
017	Al-Isra	111	Makkah
018	Al-Kahf	110	Makkah
019	Maryam	98	Makkah
020	Ta-Ha	135	Makkah
021	Al-Anbiya	112	Makkah
022	Al-Hajj	78	Madinah
023	Al-Mu'minun	118	Makkah
024	An-Nur	64	Madinah
025	Al-Furqan	77	Makkah
026	Ash-Shu'ara	227	Makkah
027	An-Naml	93	Makkah
028	Al-Qasas	88	Makkah
029	Al-Ankabut	69	Makkah
030	Ar-Rum	60	Makkah
031	Luqmaan	34	Makkah
032	As-Sajda	30	Makkah
033	Al-Ahzaab	73	Madinah
034	Saba (surah)	54	Makkah
035	Faatir	45	Makkah
036	Yaseen	83	Makkah
037	As-Saaffaat	182	Makkah
038	Saad	88	Makkah
039	Az-Zumar	75	Makkah
040	Ghafir	85	Makkah
041	Fussilat	54	Makkah
042	Ash_Shooraa	53	Makkah
043	Az-Zukhruf	89	Makkah
044	Ad-Dukhaan	59	Makkah
045	Al-Jaathiyah	37	Makkah
046	Al-Ahqaaf	35	Makkah
047	Muhammad	38	Madinah
048	Al-Fath	29	Madinah
049	Al-Hujuraat	18	Madinah
050	Qaaf	45	Makkah
051	Adh-Dhaariyaat	60	Makkah
052	At-Toor	49	Makkah
053	An-Najm	62	Makkah
054	Al-Qamar	55	Makkah
055	Ar-Rahman	78	Madinah
056	Al-Waqi'a	96	Makkah
057	Al-Hadeed	29	Madinah
058	Al-Mujadila	22	Madinah
059	Al-Hashr	24	Madinah
060	Al-Mumtahanah	13	Madinah
061	As-Saff	14	Madinah
062	Al-Jumu'ah	11	Madinah
063	Al-Munafiqoon	11	Madinah
064	At-Taghabun	18	Madinah
065	At-Talaq	12	Madinah
066	At-Tahreem	12	Madinah
067	Al-Mulk	30	Makkah
068	Al-Qalam	52	Makkah
069	Al-Haaqqa	52	Makkah
070	Al-Ma'aarij	44	Makkah
071	Nooh	28	Makkah
072	Al-Jinn	28	Makkah
073	Al-Muzzammil	20	Makkah
074	Al-Muddaththir	56	Makkah
075	Al-Qiyamah	40	Makkah
076	Al-Insaan	31	Madinah
077	Al-Mursalaat	50	Makkah
078	An-Naba'	40	Makkah
079	An-Naazi'aat	46	Makkah
080	Abasa	42	Makkah
081	At-Takweer	29	Makkah
082	Al-Infitar	19	Makkah
083	Al-Mutaffifeen	36	Makkah
084	Al-Inshiqaaq	25	Makkah
085	Al-Burooj	22	Makkah
086	At-Taariq	17	Makkah
087	Al-A'laa	19	Makkah
088	Al-Ghaashiyah	26	Makkah
089	Al-Fajr	30	Makkah
090	Al-Balad	20	Makkah
091	Ash-Shams	15	Makkah
092	Al-Layl	21	Makkah
093	Ad-Dhuha	11	Makkah
094	Ash-Sharh (Al-Inshirah)	8	Makkah
095	At-Teen	8	Makkah
096	Al-Alaq	19	Makkah
097	Al-Qadr	5	Makkah
098	Al-Bayyinahh	8	Madinah
099	Az-Zalzalah	8	Madinah
100	Al-'Aadiyaat	11	Makkah
101	Al-Qaari'ah	11	Makkah
102	At-Takaathur	8	Makkah
103	Al-'Asr	3	Makkah
104	Al-Humazah	9	Makkah
105	Al-Feel	5	Makkah
106	Quraysh	4	Makkah
107	Al-Maa'oon	7	Makkah
108	Al-Kawthar	3	Makkah
109	Al-Kaafiroon	6	Makkah
110	An-Nasr	3	Madinah
111	Al-Masad	5	Makkah
112	Al-Ikhlaas	4	Makkah
113	Al-Falaq	5	Makkah
114	Al-Naas	6	Makkah";

                    FunctionalityInfo<InputParamsBase> funcGetBarChart = new(nameof(BarChart), desc4BarChart,
                            new List<InputParams> { new InputParams("A graph that shows surahs in the book order"
                            , @$"{SDKLibV5.Constants.MultiLineIndicator}{qData}") });

                    DataStats dataStats = new DataStats();
                    var qDataBySurahLen = dataStats.OrderByColumn(new DataStats.InputParams(qData, 2));

                    FunctionalityInfo<InputParamsBase> funcGetBarChartBySuraLength = new(nameof(BarChartBySuraLen), desc4BarChartByLength,
                            new List<InputParams> { new InputParams("A graph that shows surahs in the surah-length order"
                            , @$"{SDKLibV5.Constants.MultiLineIndicator}{qDataBySurahLen}") });

                    var qDataByLocationAndSurahLen = dataStats.OrderByColumn(new DataStats.InputParams(qDataBySurahLen, 3));

                    FunctionalityInfo<InputParamsBase> funcGetBarChartByLocationAndSuraLength = new(nameof(BarChartByLocationAndLen), desc4BarChartByLocationAndLength,
                            new List<InputParams> { new InputParams("A graph that shows surahs in the location and surah-length order"
                            , @$"{SDKLibV5.Constants.MultiLineIndicator}{qDataByLocationAndSurahLen}") });


                    List<FunctionalityInfo<InputParamsBase>> functionalities = new()
                    {
                        funcGetBarChart,
                        funcGetBarChartBySuraLength,
                        funcGetBarChartByLocationAndSuraLength
                    };
                    #endregion

                    _info = new DescribeMyFunctionality<InputParamsBase>(description, functionalities, new DateTime(2021, 5, 7));
                }
                return _info;
            }
        }

        internal class InputParams : InputParamsBase
        {
            public string FigureCaption { get; set; }
            public int BarHeight { get; set; } = 20;
            public int BarGaps { get; set; } = 5;
            public string FillColorMekki { get; set; } = "Blue";
            public string FillColorMedeni { get; set; } = "Green";
            public string HoverFillColor { get; set; } = "Cyan";
            public string TabDelimData { get; set; }

            public InputParams() { }

            public InputParams(string caption, string data)
            {
                FigureCaption = caption;
                TabDelimData = data;
            }
        }
        #endregion

        #region Implementation
        internal string BarChartByLocationAndLen(InputParams inputParams) => BarChart(inputParams);

        internal string BarChartBySuraLen(InputParams inputParams) => BarChart(inputParams);

        internal string BarChart(InputParams inputParams)
        {
            string[] lines = inputParams.TabDelimData.Split(new string[] { "\r\n" }, StringSplitOptions.RemoveEmptyEntries);
            StringBuilder sb = new();
            List<BarData> barData = new();

            // get column widths
            for (int i = 0; i < lines.Length; i++)
            {
                string line = lines[i];
                string[] cols = line.Split('\t');
                barData.Add(new BarData(cols));

                var barText = $"{int.Parse(cols[0])}. {cols[1]} ({cols[2]})";
                var width = int.Parse(cols[2]);
                var g = inputParams.BarGaps;
                var h = inputParams.BarHeight;
                var fillColor = cols[3] == "Makkah" ? inputParams.FillColorMekki : inputParams.FillColorMedeni;

                var template = @$"        <g class=""bar"">
          <rect width=""{width}"" height=""{h}"" y=""{(h + g) * i}"" fill=""{fillColor}""/>
          <text x=""{width + 5}"" y=""{(h + g) * i + 9}"" dy="".35em"">{barText}</text>
        </g>
";
                sb.AppendLine(template);
            }

            var (svgHeight, svgWidth) = GetHeightAndWidth(barData, inputParams);

            return Constants.GetSvgInHtml(inputParams.FigureCaption, sb.ToString(), svgHeight, svgWidth, inputParams.FillColorMedeni, inputParams.HoverFillColor);
        }

        private (int, int) GetHeightAndWidth(List<BarData> barData, InputParams inputParams)
        {
            int width = (int)barData.Max(b => b.Value) + 100;
            int height = barData.Count * (inputParams.BarHeight + inputParams.BarGaps) + 100;
            return (height, width);
        }

        private class BarData
        {
            public string Name { get; set; }
            public float Value { get; set; }
            public int SuraNum { get; set; }
            public string Location { get; set; }

            public BarData(string[] columns)
            {
                SuraNum = int.Parse(columns[0]);
                Name = columns[1];
                Value = float.Parse(columns[2]);
                Location = columns[3];
            }
        }

        #endregion


        private sealed class Constants
        {
            public static string GetSvgInHtml(string figureCaption, string barData, int height, int width, string fillColor, string hoverFillColor) => @$"<!DOCTYPE html>
<html lang=""en"">
<head>
    <meta charset=""UTF-8"">
    <meta http-equiv=""X-UA-Compatible"" content=""IE=edge"">
    <meta name=""viewport"" content=""width=device-width, initial-scale=1.0"">
    <title>Document</title>

</head>
<body>
    <figure>
        <figcaption>{figureCaption}</figcaption>
      <svg version=""1.1"" xmlns=""http://www.w3.org/2000/svg"" 
      xmlns:xlink=""http://www.w3.org/1999/xlink"" 
      class=""chart"" 
      width=""{width}"" height=""{height}"" aria-labelledby=""title"">
        <title id=""title"">A bart chart showing information</title>

<style>
{GetStyle(fillColor, hoverFillColor)}
</style>

{barData}        

      </svg>
      </figure>
</body>
</html>";

            private static string GetStyle(string fillColor, string hoverFillColor) => @$".bar {{
  fill: {fillColor};
  height: 21px;
  transition: fill 0.3s ease;
  cursor: pointer;
  font-family: Helvetica, sans-serif;
}}
.bar text {{
  fill: #555;
}}

.chart:hover .bar,
.chart:focus .bar {{
  fill: {fillColor};
}}

.bar:hover,
.bar:focus {{
  fill: {hoverFillColor} !important;
}}
.bar:hover text,
.bar:focus text {{
  fill: {hoverFillColor};
}}

figcaption {{
  font-weight: bold;
  color: #000;
  margin-bottom: 20px;
}}

body {{
  font-family: ""Open Sans"", sans-serif;
}}";

        }

    }


}
