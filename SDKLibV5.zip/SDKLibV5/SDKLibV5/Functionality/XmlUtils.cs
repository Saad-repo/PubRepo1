﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SDKLibV5.Functionality
{
    public sealed class XmlUtils : FunctionalityBase
    {
        #region IDescribeMyFunctionality
        private static DescribeMyFunctionality<InputParamsBase> _info;

        /// <summary>
        ///     Functionality Info
        /// </summary>
        internal static DescribeMyFunctionality<InputParamsBase> Info
        {
            get
            {
                if (_info is null)
                {
                    #region Class Functionality Definitions and sample inputs
                    var description = @"This class provides an implementation for converting MD content to HTML content";
                    var desc4Convert2Html = @"Converts a given MD content to HTML content";
                    var descTabDelim2MdTable = @"Converts the given tab delimited table to MarkDown table";
                    FunctionalityInfo<InputParamsBase> f1 = new("TabDelimited2MdTable", descTabDelim2MdTable,
                        new List<InputParams> {
                            new InputParams {
                            XmlInputText = @"TRANSACTION STATUS	DESCRIPTION
Approved	Transaction has been approved and is awaiting committal.
Closed	Transaction has been completed in the ExampleData database but has not been reconciled in downstream systems.
Committed	Transaction has been completed in all systems.
Declined	Transaction has been rejected by an underwriter.
Pending	Transaction is awaiting committal.
Referred	Transaction is awaiting approval.
Scheduled	Transaction is awaiting a batch process to complete it.
" } });
                    FunctionalityInfo<InputParamsBase> f2 = new("ConvertMd2Html", desc4Convert2Html,
                        new List<InputParams> { new(@"c:\temp\file3.md", @"c:\temp\output\file3.html") });
                    List<FunctionalityInfo<InputParamsBase>> functionalities = new()
                    {
                        f1,
                        f2
                    };
                    #endregion

                    _info = new DescribeMyFunctionality<InputParamsBase>(description, functionalities, new DateTime(2021, 5, 6));
                }
                return _info;
            }
        }

        public class InputParams : InputParamsBase
        {
            public string XmlInputText { get; set; }
            public string XslTInputText { get; set; }

            public InputParams()
            {

            }

            public InputParams(string par1, string par2)
            {
                XmlInputText = par1;
                XslTInputText = par2;
            }
        }
        #endregion

    }
}
