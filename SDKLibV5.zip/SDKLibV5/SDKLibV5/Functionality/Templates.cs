﻿using System;
using System.Collections.Generic;

namespace SDKLibV5.Functionality
{
    public sealed class Templates : FunctionalityBase
    {
        #region IDescribeMyFunctionality
        private static DescribeMyFunctionality<InputParamsBase> _info;

        /// <summary>
        ///     Functionality Info
        /// </summary>
        internal static DescribeMyFunctionality<InputParamsBase> Info
        {
            get
            {
                if (_info is null)
                {
                    #region Class Functionality Definitions and sample inputs
                    var description = @"This class provides ready-to-use templates for various purposes";
                    var desc4BasicHTML = @"Provides an HTML page with minimal content and frequently used elements";
                    var desc4BasicFuncMethod = @"Provides a ""Functionality Class"" with a basic implementation method";
                    var desc4MDTemplate = "Sample MD with same-page anchors and reference links";
                    var desc4Fibonacci = "Sample implementation for recursive Fibonacci numbers calculation -- uses caching for improved performance";
                    var desc4Commands = "Some useful commandline/terminal commands";
                    var desc4DesignPatterns = "Some of the useful design patterns I have utilized and might utilize for future development";

                    FunctionalityInfo<InputParamsBase> funcHTML1 = new(nameof(HTML1), desc4BasicHTML,
                        new List<InputParams> { new() });
                    FunctionalityInfo<InputParamsBase> funcFuncTemplate = new(nameof(BasicFunc), desc4BasicFuncMethod,
                        new List<InputParams> { new() });
                    FunctionalityInfo<InputParamsBase> funcMdAchorLinkTemplate = new(nameof(MdAchorLinks), desc4BasicFuncMethod,
                        new List<InputParams> { new() });
                    FunctionalityInfo<InputParamsBase> funcRecursiveFib = new(nameof(Fib), desc4Fibonacci, new List<InputParams> { new () });
                    FunctionalityInfo<InputParamsBase> funcCmds = new(nameof(Cmds), desc4Commands, new List<InputParams> { new() });
                    FunctionalityInfo<InputParamsBase> funcPatterns = new(nameof(Patterns), desc4DesignPatterns, new List<InputParams> { new() });


                    List<FunctionalityInfo<InputParamsBase>> functionalities = new()
                    {
                        funcHTML1,
                        funcFuncTemplate,
                        funcMdAchorLinkTemplate,
                        funcRecursiveFib,
                        funcCmds,
                        funcPatterns
                    };
                    #endregion

                    _info = new DescribeMyFunctionality<InputParamsBase>(description, functionalities, new DateTime(2021, 5, 31));
                }
                return _info;
            }
        }

        public class InputParams : InputParamsBase
        {
            public InputParams() { }
        }
        #endregion

        #region Implementations
        internal string Patterns(InputParams inputParams)
        {
            return @"
Design Patterns
===========================================================

Strategy
-----------------------------------------------------------
*Category: behavioral*

Lets you define a family of algorithms, put each of them into a separate class, and make their objects interchangeable.

--> Use the Strategy pattern when you want to use different variants of an algorithm within an object and be able to switch from one algorithm to another during runtime.


[Reference refactoring.guru](https://refactoring.guru/design-patterns/strategy)


Singleton
-----------------------------------------------------------
*Category: creational*


Lets you ensure that a class has only one instance, while providing a global access point to this instance.

Note: When you create how an object is created, you gain control over its run-time state. This might come in handy when you app needs to access global config values from anywhere

Use the Singleton pattern when:

--> a class in your program should have just a single instance available to all clients; for example, a single database object shared by different parts of the program.
--> you need stricter control over global variables.


[Reference refactoring.guru](https://refactoring.guru/design-patterns/singleton)


Factory
-----------------------------------------------------------
*Category: creational*



[Reference refactoring.guru]()

Facade
-----------------------------------------------------------
*Category: *



[Reference refactoring.guru]()



Adaptor
-----------------------------------------------------------
*Category: behavioral*

Turns a request into a stand-alone object that contains all information about the request. This transformation lets you pass requests as a method arguments, delay or queue a request’s execution, and support undo-able operations.

[Reference refactoring.guru](https://refactoring.guru/design-patterns/command)




Mediator
-----------------------------------------------------------
*Category: behavioral*

Lets you reduce complex dependencies between objects. The pattern restricts direct communications between the objects and forces them to collaborate only via a mediator object.


[Reference refactoring.guru]()


'Template Method' pattern
-----------------------------------------------------------
*Category: behavioral*

The base class (typically is abstract) has a skeleton method name the 'Template Method' that defines the call order of methods some of which can be abstract to enforce child classes to provide relevant implementation. Child classes do not override the 'Template Method', because each child utilizes the same order of executing it's methods.

--> When you turn such an algorithm into a template method, you can also pull up the steps with similar implementations into a superclass, eliminating code duplication. Code that varies between subclasses can remain in subclasses.

[Reference refactoring.guru](https://refactoring.guru/design-patterns/template-method)

".Md2Html();


        }

        internal string Cmds(InputParams inputParams)
        {
            return @"
Useful Commands for Commandline 
---------------------------------
Copy the **utils** folder to a different folder:

```Shell
XCOPY C:\utils\* D:\Backup\utils / s / i
```

Delete a folder and its contents

```Shell
Rmdir /S <FolderToDelete>
```

".Md2Html();
        }

        internal string Fib(InputParams inputParams)
        {
            string methodContent = @"        private Dictionary<int, ulong> cache; // caller instantiates
        private ulong Fib(int upTo)
        {
            if (upTo <= 0)
                return 0;

            if (upTo == 1)
                return 1;

            if (cache.ContainsKey(upTo))
                return cache[upTo];

            cache.Add(upTo, Fib(upTo - 1) + Fib(upTo - 2));
            return cache[upTo];
        }
";

            MarkDown2Html markDown2Html = new ();
            string mdMethod = "```C#\r\n"
                        + methodContent
                        + "\r\n```";

            string mdCallerMethodContent = @"

Here is a sample caller method for listing Fibonacci numbers from 1 to upTo

```C#
    // The caller method
    internal string FibNums(int upTo)
    {
        cache = new();
        StringBuilder sb = new();
        for (int i = 0; i < inputParams.UpTo.Value; i++)
        {
            ulong fib = Fib(i);
            ulong prev = Fib(i - 1);
            decimal ratio = 0;
            if (prev > 0)
                ratio = fib / (decimal)prev;

            sb.AppendLine($""{i + 1}\t{Fib(i)}\t{ratio}"");
        }

        return sb.ToString();
    }
```
";

            var html = markDown2Html.Md2Html(new MarkDown2Html.InputParams() { MdContent = mdMethod + mdCallerMethodContent });
            return html;
        }


        internal string HTML1(InputParams inputParams)
        {
            string simpleHtmlContentWithInternalCSS = @"<!DOCTYPE html><html><head><meta http-equiv=""Content-Type"" content=""text/html;charset=UTF-8"">
<title>Code</title>
<style>.styled-table {
    border-collapse: collapse;
    margin: 25px 0;
    font-size: 0.9em;
    font-family: sans-serif;
    min-width: 400px;
    box-shadow: 0 0 20px rgba(0, 0, 0, 0.15);
}
.styled-table thead tr {
    background-color: #009879;
    color: #ffffff;
    text-align: left;
}
.styled-table th,
.styled-table td {
    padding: 12px 15px;
}
.styled-table tbody tr {
    border-bottom: 1px solid #dddddd;
}
.styled-table tbody tr:nth-of-type(even) {
    background-color: #f3f3f3;
}
.styled-table tbody tr:last-of-type {
    border-bottom: 2px solid #009879;
}
.styled-table tbody tr.active-row {
    font-weight: bold;
    color: #009879;
}
</style>
</head>

<body>

<h1>Sample table with random data</h1>

<p>This is simple table with random data in it. Some Embedded CSS has been provided in the header for nice rendering of the table. Notice how two of the rows use bold text. These two rows have <strong>.active-row</strong> as their style class</p>

<table class=""styled-table"">
<thead><tr>
	<th>Data Type</th>
	<th>Property Name</th>
</tr></thead>
<tbody>
</tr>
<tr>
	<td>string</td>
	<td>applicationName</td>
</tr>
<tr>
	<td>string</td>
	<td>applicationVersion</td>
</tr>
<tr>
	<td>string</td>
	<td>appVersionSignature</td>
</tr>
<tr>
	<td>string</td>
	<td>callingApplication</td>
</tr>
<tr class=""active-row"">
	<td>string</td>
	<td>accessToken</td>
</tr>
<tr class=""active-row"">
	<td>object</td>
	<td>accessTokenExpirationDate</td>
</tr>
<tr>
	<td>Location</td>
	<td>from</td>
</tr>
<tr>
	<td>Location</td>
	<td>to</td>
</tr>
</tbody>
</table>

<script></script>

</body>
</html>
";

            return simpleHtmlContentWithInternalCSS;
        }

        internal string BasicFunc(InputParams inputParams)
        {
            string basicTemplateForFunctionalityMethod = @"using System;
using System.Collections.Generic;
namespace SDKLibV5.Functionality
{
    public sealed class Templates : FunctionalityBase
    {
        #region IDescribeMyFunctionality
        private static DescribeMyFunctionality<InputParamsBase> _info;
        /// <summary>
        ///     Functionality Info
        /// </summary>
        internal static DescribeMyFunctionality<InputParamsBase> Info
        {
            get
            {
                if (_info is null)
                {
                    #region Class Functionality Definitions and sample inputs
                    var description = @""This class provides ready-to-use templates for various purposes"";
                    var desc4BasicHTML = @""Provides an HTML page with minimal content and frequently used elements"";
                    FunctionalityInfo<InputParamsBase> funcHTML1 = new(nameof(HTML1), desc4BasicHTML,
                        new List<InputParams> { new() });
                    List<FunctionalityInfo<InputParamsBase>> functionalities = new()
                    {
                        funcHTML1
                    };
                    #endregion
                    _info = new DescribeMyFunctionality<InputParamsBase>(description, functionalities, new DateTime(2021, 5, 31));
                }
                return _info;
            }
        }
        public class InputParams : InputParamsBase
        {
            public InputParams() { }
        }
        #endregion
        #region Implementations
        internal string HTML1(InputParams inputParams)
        {
            return ""pending -- TODO: Add your implementation here"";
        }
        #endregion
    }
}
";
            return basicTemplateForFunctionalityMethod;
        }

        internal string MdAchorLinks(InputParams inputParams)
        {
            string mdContentWithSamePageAnchorLinks = @"This is a long MD file with multiple headers for demonstrating how same-page anchor links work. [Go here for the list of samples anchors](#sample-anchors)

What is Lorem Ipsum?
==========================
Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.

Here is a sample for using [reference style links in MarkDown.](#sample-for-reference-type-links-in-md)

Why do we use it?
==========================
It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).


Where does it come from?
==========================
Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of ""de Finibus Bonorum et Malorum"" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, ""Lorem ipsum dolor sit amet.."", comes from a line in section 1.10.32.

The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from ""de Finibus Bonorum et Malorum"" by Cicero are also reproduced in their exact original form, accompanied by English versions from the 1914 translation by H. Rackham.

Where can I get some?
==========================
There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.





To create anchor links that jump down to different sections of a README (as in an interactive table of contents), first create a heading:
#Real Cool Heading

The anchor link for that heading is the lowercase heading name with dashes where there are spaces. You can always get the anchor name by visiting the README on Github.com and clicking on the anchor that appears when you hover to the left of the heading. Copy everything starting at the #:
The anchor link for that heading is the lowercase heading name with dashes where there are spaces. You can always get the anchor name by visiting the README on Github.com and clicking on the anchor that appears when you hover to the left of the heading. Copy everything starting at the #:


Here are 4 same-page links. The links are simply headers in lowercase with quotation marks removed and spaces replaced with dashes.

#### Sample Anchors

go to [What is Lorem Ipsum?](#what-is-lorem-ipsum)
go to [Why do we use it?](#why-do-we-use-it)
go to [Where does it come from?](#where-does-it-come-from)
go to [Where can I get some?](#where-can-i-get-some)

Notice how it doesn't matter whether the header type is h1, h2, h3, ....

Sample for reference type links in MD
-----------------------------------------
I get 10 times more traffic from [Google][1] than from
[Yahoo][2] or [MSN][3].

[1]: http://google.com/        ""Google""
[2]: http://search.yahoo.com/  ""Yahoo Search""
[3]: http://search.msn.com/    ""MSN Search""
";

            return mdContentWithSamePageAnchorLinks;
        }

        #endregion
    }
}
