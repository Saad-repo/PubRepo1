﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SDKLibV5.Functionality
{
    /// <summary>
    ///     Provides text/string manipulation functionalities
    /// </summary>
    public sealed class TextOps : FunctionalityBase
    {
        #region IDescribeMyFunctionality
        private static DescribeMyFunctionality<InputParamsBase> _info;

        /// <summary>
        ///     Functionality Info
        /// </summary>
        internal static DescribeMyFunctionality<InputParamsBase> Info
        {
            get
            {
                if (_info is null)
                {
                    #region Class Functionality Definitions and sample inputs
                    var desc4Class = @"This class provides various functions for text manipulation";
                    var desc4Hierarchical2View = @"Converts a tab-offset hierarchical list to various visual views";


                    FunctionalityInfo<InputParamsBase> funcHierarchy2View = new(nameof(Hierarchy2View), desc4Hierarchical2View,
                        new List<InputParams> {
                            new InputParams {
                                OutputType = "Text  //##// [Text | Html]",
                                HierarchicalData = $"{SDKLibV5.Constants.MultiLineIndicator}Root" + Environment.NewLine
+ @"{0}R1C1
{0}R1C2
{0}{0}R1C2C1
{0}{0}R1C2C2
{0}{0}R1C2C3
{0}R1C3
{0}R1C4
" },
new InputParams
{
    OutputType = "Text  //##// [Text | Html]",
    HierarchicalData = SDKLibV5.Constants.MultiLineIndicator + @"Root1
{0}A1
{0}A2
{0}{0}B1
{0}{0}{0}C1
{0}{0}{0}{0}D1
{0}{0}{0}{0}{0}E1
{0}{0}{0}{0}{0}{0}F1
{0}{0}{0}{0}{0}{0}{0}G1
{0}{0}{0}{0}{0}{0}{0}{0}H1
{0}{0}{0}{0}{0}{0}{0}{0}{0}I1
{0}{0}{0}{0}{0}{0}{0}{0}{0}{0}J1
{0}{0}{0}{0}D2
{0}{0}{0}{0}D3
{0}{0}{0}{0}D4
{0}{0}B2
{0}{0}B3
{0}A3
{0}A4
Root2
{0}A1
{0}A2
{0}{0}B1
{0}{0}{0}C1
{0}{0}{0}{0}D1
{0}{0}{0}{0}{0}E1
{0}{0}{0}{0}{0}{0}F1
{0}{0}{0}{0}{0}{0}{0}G1
{0}{0}{0}{0}{0}{0}{0}{0}H1
{0}{0}{0}{0}{0}{0}{0}{0}{0}I1
{0}{0}{0}{0}{0}{0}{0}{0}{0}{0}J1
{0}{0}B2
{0}{0}B3
{0}A3
{0}A4
"
}
                        }); ;


                    List<FunctionalityInfo<InputParamsBase>> functionalities = new()
                    {
                        funcHierarchy2View
                    };
                    #endregion

                    _info = new DescribeMyFunctionality<InputParamsBase>(desc4Class, functionalities, new DateTime(2021, 5, 5));
                }
                return _info;
            }
        }

        internal class InputParams : InputParamsBase
        {
            string _hierarchicalData;
            public string OutputType { get; set; } = null; // Text | Html

            public string HierarchicalData
            {
                get => string.Format(_hierarchicalData, "\t");
                set => _hierarchicalData = value;
            }

            public InputParams() { }
            public InputParams(string cSharpCode)
            {
                HierarchicalData = cSharpCode;
            }
        }
        #endregion

        private class Constants
        {
            internal const string CSS = @"/* Remove default bullets */
ul, #myUL {
  list-style-type: none;
}
/* Remove margins and padding from the parent ul */
#myUL {
  margin: 0;
  padding: 0;
}
/* Style the caret/arrow */
.caret {
  cursor: pointer;
  user-select: none; /* Prevent text selection */
}
/* Create the caret/arrow with a unicode, and style it */
.caret::before {
  content: ""\25B6"";
  color: black;
  display: inline-block;
  margin-right: 6px;
}
/* Rotate the caret/arrow icon when clicked on (using JavaScript) */
.caret-down::before {
  transform: rotate(90deg);
}
/* Hide the nested list */
.nested {
  display: none;
}
/* Show the nested list when the user clicks on the caret/arrow (with JavaScript) */
.active {
  display: block;
}
";
            internal const string JavaScript = @"var toggler = document.getElementsByClassName(""caret"");
var i;
for (i = 0; i < toggler.length; i++) {
  toggler[i].addEventListener(""click"", function() {
    this.parentElement.querySelector("".nested"").classList.toggle(""active"");
    this.classList.toggle(""caret-down"");
  });
}
";
        }



        internal string Hierarchy2View(InputParams inputParams)
        {
            var lines = inputParams.HierarchicalData.ToLines();

            /*
            Zero tab prefix means a root node
            */

            IEnumerable<Node> nodes = GetNodes(lines);

            var outputType = inputParams.OutputType.Trim().ToLower();

            if (outputType == "html")
            {
                return $@"<ul id=""myUL"">
                    {NodesToHtml(nodes)}
                </ul>".WrapInHTML(Constants.CSS, Constants.JavaScript);
            }

            return NodesToString(nodes);
        }

        #region Implementation for Hierarchy2View
        private string NodesToString(IEnumerable<Node> nodes, string prefix = "")
        {
            StringBuilder sb = new();
            foreach (Node node in nodes)
            {
                string bullet = GetBullet4Node(node, nodes);
                sb.AppendLine(prefix + bullet + node.Name);
                if (node.Children.Any())
                {
                    string pipe = GetPipe(node, nodes);
                    string nextPrefix = prefix + pipe + GetSpace(node);
                    sb.Append(NodesToString(node.Children, nextPrefix));
                }
                //else
                //    bullet = "";
            }

            return sb.ToString();
        }

        private string NodesToHtml(IEnumerable<Node> nodes)
        {
            StringBuilder sb = new();
            foreach (Node node in nodes)
            {
                if (node.Children.Any())
                {
                    sb.AppendLine($"<li><span class=\"caret\">{node.Name}</span>");
                    sb.AppendLine(@"<ul class=""nested"">");
                    sb.Append(NodesToHtml(node.Children));
                    sb.AppendLine("</ul>");
                    sb.AppendLine("</li>");
                }
                else
                    sb.AppendLine($"<li>{node.Name}</li>");

                //else
                //    bullet = "";
            }

            return sb.ToString();
        }


        private string GetSpace(Node node)
        {
            if (node.Parent is null)
                return "";

            return new String(' ', 4);
            //string spaces = new String(' ', node.Level * 4);

            //if (node.Level < 3)
            //    return spaces;

            // return spaces.Substring(0, spaces.Length - node.Level * 2 - node.Level - 2);
        }

        private string GetPipe(Node node, IEnumerable<Node> nodes)
        {
            if (node.Parent is null)
                return " ";

            string pipe = " ";
            if (node.Parent is not null && node != node.Parent.Children.Last()
                 || node.Parent is null && node != nodes.Last()) // node.Level > 0 && 
            {
                pipe = "│";
            }

            return pipe;
        }

        private string GetBullet4Node(Node node, IEnumerable<Node> nodes)
        {
            string initBullet = "├─── ";
            string alternativeBullet = "└─── ";

            if (node.Parent is null)
                return "";

            string bullet = initBullet;
            if (node.Parent is not null && node == node.Parent.Children.Last()
                 || node.Parent is null && node == nodes.Last())
            {
                bullet = alternativeBullet;
            }

            return bullet;
        }

        Node lastParentNode = null;
        private IEnumerable<Node> GetNodes(string[] lines)
        {
            List<Node> nodes = new();
            for (int i = 0; i < lines.Length; i++)
            {
                int tabCount = GetTabPrefixCount(lines[i]);

                if (tabCount == 0)
                {
                    nodes.Add(new Node(lines[i].Trim()));
                    lastParentNode = nodes.Last();
                }
                else
                {
                    PopulateTree(lastParentNode, lines, ref i, tabCount);
                }
            }

            return nodes;
        }

        private void PopulateTree(Node node, string[] lines, ref int i, int tabCount)
        {
            if (tabCount == node.Level + 1)
            {
                node.Children = node.Children.Concat(new[] { new Node(lines[i], tabCount, node) });
            }
            else
            {
                // CheckForFaultyEntries(tabCount);

                // get to the right parent
                int j = tabCount;
                int currParentLevel = lastParentNode.Level;
                if (lastParentNode.Level >= j)
                {
                    while (lastParentNode.Level >= j)
                        lastParentNode = lastParentNode.Parent;
                }
                else
                {
                    while (j-- > lastParentNode.Level)
                        lastParentNode = lastParentNode.Children.Last();
                }

                PopulateTree(lastParentNode, lines, ref i, tabCount);
            }
        }

        private void CheckForFaultyEntries(int tabCount)
        {
            if (tabCount < lastParentNode.Level - 2)
                throw new ArgumentOutOfRangeException("One or more nodes in your tree appears out of order");

            if (tabCount > lastParentNode.Level + 2)
                throw new ArgumentOutOfRangeException("One or more nodes in your tree appears out of order - child before parent?");
        }

        private int GetTabPrefixCount(string line)
        {
            int count = 0;

            int i = 0;
            while (line[i++] == '\t')
            {
                count++;
                if (line[i] != '\t')
                {
                    break;
                }
            }

            return count;
        }

        private class Node
        {
            public Node(string name, int level = 0, Node parent = null)
            {
                Name = name.Trim();
                Level = level;
                Parent = parent;

                Children = new List<Node>();
            }

            public string Name { get; set; }
            public IEnumerable<Node> Children { get; set; }
            public int Level { get; set; }
            public Node Parent { get; set; }
        }
        #endregion    


    }
}
