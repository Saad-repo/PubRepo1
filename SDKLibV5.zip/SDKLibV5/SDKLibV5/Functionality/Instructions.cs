﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SDKLibV5.Functionality
{
    public sealed class Instructions : FunctionalityBase
    {
        #region IDescribeMyFunctionality
        private static DescribeMyFunctionality<InputParamsBase> _info;
        /// <summary>
        ///     Functionality Info
        /// </summary>
        internal static DescribeMyFunctionality<InputParamsBase> Info
        {
            get
            {
                if (_info is null)
                {
                    #region Class Functionality Definitions and sample inputs
                    var description = @"This class provides a list of instructions for accomplishing a variety of tasks";
                    var desc4CreateWebApi = @"Provides instructions for creating Web API in .NET";
                    FunctionalityInfo<InputParamsBase> funcCreateWebApi = new(nameof(CreateWebAPI), desc4CreateWebApi,
                        new List<InputParams> { new(Constants.MultiLineIndicator + @"
How to create a Web API in .NET
=====================================

Here are the instructions for creating a Web API in .NET in VS...


##### PS: 
The eventual goal with a Web API is to provide some functionality implemented in separate class libraries or services to the clients



Steps
-------------------------------------
1. use dotnet CLI: ```dotnet new webapi --no-https```
2. Create Controllers and Services as needed
3. Follow instructions at (MS Docs - Create a web API with ASP.NET Core)[https://docs.microsoft.com/en-us/learn/modules/build-web-api-aspnet-core/3-exercise-create-web-api]



") });

                    FunctionalityInfo<InputParamsBase> funcAngularCli = new(nameof(AngularCLI), desc4CreateWebApi,
                    new List<InputParams> { new("") });

                    List<FunctionalityInfo<InputParamsBase>> functionalities = new()
                    {
                        funcCreateWebApi,
                        funcAngularCli
                    };
                    #endregion
                    _info = new DescribeMyFunctionality<InputParamsBase>(description, functionalities, new DateTime(2021, 5, 31));
                }
                return _info;
            }
        }
        public class InputParams : InputParamsBase
        {
            public InputParams(string content)
            {
                Content = content; // should be in MD format
            }

            public string Content { get; set; }
        }
        #endregion
        #region Implementations
        internal string AngularCLI(InputParams inputParams)
        {
            MarkDown2Html markDown2Html = new();
            MarkDown2Html.InputParams mdParams = new()
            {
                MdContent = @"Create New Project
========================================================================
```shell
ng new my-first-project
```

Create a Component
========================================================================
Creating components is one of the first and frequent things you would typically do

```shell
ng generate component xyz
```



Run your app
========================================================================
1. cd into your apps' root folder first

```shell
ng serve
```
If no errors show on the console, typically the app should be available at http://localhost:4200/



Build for Prod
========================================================================
1. cd into your apps' root folder first

```shell
ng build --prod --base-href /ePortal/
```
After this command executes successfully, you should see the deployment files in the **dist** folder of your project.

"
            };

            return markDown2Html.Md2Html(mdParams);
        }

        internal string CreateWebAPI(InputParams inputParams)
        {
            MarkDown2Html markDown2Html = new();
            MarkDown2Html.InputParams mdParams = new()
            {
                MdContent = inputParams.Content
            };

            return markDown2Html.Md2Html(mdParams);
        }
        #endregion
    }
}
