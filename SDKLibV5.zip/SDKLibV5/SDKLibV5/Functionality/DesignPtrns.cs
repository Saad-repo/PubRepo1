﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SDKLibV5.Functionality
{
    internal sealed class DesignPtrns : FunctionalityBase
    {
        #region IDescribeMyFunctionality
        private static DescribeMyFunctionality<InputParamsBase> _info;
        /// <summary>
        ///     Functionality Info
        /// </summary>
        internal static DescribeMyFunctionality<InputParamsBase> Info
        {
            get
            {
                if (_info is null)
                {
                    #region Class Functionality Definitions and sample inputs
                    var description = @"This class provides relate-able sample implementations for a various software design patters";
                    var desc4FactoryMethod1 = @"Provides an implementation that uses Factory Method Pattern for an easy to understand scenario";
                    var desc4AbstractFactory = @"Provides an implementation that uses Abstract Factory Pattern for an easy to understand scenario";
                    var desc4Singleton = @"Provides a singleton implementation";
                    var desc4Builder = @"Provides a sample Builder Pattern implementation";
                    var desc4Strategy = @"Provides a sample Strategy Pattern implementation";
                    var desc4Facade = @"Provides a sample Facade Pattern implementation";
                    var desc4Adapter = @"Provides a sample Adapter Pattern implementation";
                    var desc4Mediator = @"Provides a sample Mediator Pattern implementation";
                    FunctionalityInfo<InputParamsBase> funcFactoryMethod = new(nameof(FactoryMethod), desc4FactoryMethod1,
                        new List<InputParams> { new() });
                    FunctionalityInfo<InputParamsBase> funcAbstractFactory = new(nameof(AbstractFactory), desc4AbstractFactory,
                        new List<InputParams> { new() });
                    FunctionalityInfo<InputParamsBase> funcSingleton = new(nameof(Singleton), desc4Singleton,
                        new List<InputParams> { new() });
                    FunctionalityInfo<InputParamsBase> funcBuilder = new(nameof(Builder), desc4Builder,
                        new List<InputParams> { new() });
                    FunctionalityInfo<InputParamsBase> funcStrategy = new(nameof(Strategy), desc4Strategy,
                        new List<InputParams> { new() });
                    FunctionalityInfo<InputParamsBase> funcFacade = new(nameof(Facade), desc4Facade,
                        new List<InputParams> { new() });
                    FunctionalityInfo<InputParamsBase> funcAdapter = new(nameof(Adapter), desc4Adapter,
                        new List<InputParams> { new() });
                    FunctionalityInfo<InputParamsBase> funcMediator = new(nameof(Mediator), desc4Mediator,
                        new List<InputParams> { new() });

                    List<FunctionalityInfo<InputParamsBase>> functionalities = new()
                    {
                        funcFactoryMethod,
                        funcAbstractFactory,
                        funcSingleton,
                        funcBuilder,
                        funcStrategy,
                        funcFacade,
                        funcAdapter,
                        funcMediator
                    };
                    #endregion
                    _info = new DescribeMyFunctionality<InputParamsBase>(description, functionalities, new DateTime(2021, 6, 14));
                }
                return _info;
            }
        }
        public class InputParams : InputParamsBase
        {
            public InputParams() { }
        }
        #endregion

        #region Implementations
        internal string Mediator(InputParams inputParams)
        {
            string strValue = @"
Mediator Design Pattern
===================================


Mediator is a behavioral design pattern that lets you reduce chaotic dependencies between objects. The pattern restricts direct communications between the objects and forces them to collaborate only via a mediator object.


The Mediator makes it easy to modify, extend and reuse individual components because they’re no longer dependent on the dozens of other classes.


[Reference: Refactoring.Guru](https://refactoring.guru/design-patterns/mediator)


### Sample Code
```C#

// The Mediator interface declares a method used by components to notify the
// mediator about various events. The Mediator may react to these events and
// pass the execution to other components.
public interface IMediator
{
    void Notify(object sender, string ev);
}

// Concrete Mediators implement cooperative behavior by coordinating several
// components.
class ConcreteMediator : IMediator
{
    private Component1 _component1;

    private Component2 _component2;

    public ConcreteMediator(Component1 component1, Component2 component2)
    {
        this._component1 = component1;
        this._component1.SetMediator(this);
        this._component2 = component2;
        this._component2.SetMediator(this);
    } 

    public void Notify(object sender, string ev)
    {
        if (ev == ""A"")
        {
            Console.WriteLine(""Mediator reacts on A and triggers folowing operations:"");
            this._component2.DoC();
        }
        if (ev == ""D"")
        {
            Console.WriteLine(""Mediator reacts on D and triggers following operations:"");
            this._component1.DoB();
            this._component2.DoC();
        }
    }
}

// The Base Component provides the basic functionality of storing a
// mediator's instance inside component objects.
class BaseComponent
{
    protected IMediator _mediator;

    public BaseComponent(IMediator mediator = null)
    {
        this._mediator = mediator;
    }

    public void SetMediator(IMediator mediator)
    {
        this._mediator = mediator;
    }
}

// Concrete Components implement various functionality. They don't depend on
// other components. They also don't depend on any concrete mediator
// classes.
class Component1 : BaseComponent
{
    public void DoA()
    {
        Console.WriteLine(""Component 1 does A."");

        this._mediator.Notify(this, ""A"");
    }

    public void DoB()
    {
        Console.WriteLine(""Component 1 does B."");

        this._mediator.Notify(this, ""B"");
    }
}

class Component2 : BaseComponent
{
    public void DoC()
    {
        Console.WriteLine(""Component 2 does C."");

        this._mediator.Notify(this, ""C"");
    }

    public void DoD()
    {
        Console.WriteLine(""Component 2 does D."");

        this._mediator.Notify(this, ""D"");
    }
}
    
class Program
{
    static void Main(string[] args)
    {
        // The client code.
        Component1 component1 = new Component1();
        Component2 component2 = new Component2();
        new ConcreteMediator(component1, component2);

        Console.WriteLine(""Client triggets operation A."");
        component1.DoA();

        Console.WriteLine();

        Console.WriteLine(""Client triggers operation D."");
        component2.DoD();
    }
}
```

### Output:
```Text
Client triggers operation A.
Component 1 does A.
Mediator reacts on A and triggers following operations:
Component 2 does C.

Client triggers operation D.
Component 2 does D.
Mediator reacts on D and triggers following operations:
Component 1 does B.
Component 2 does C.
```



";

            return strValue.Md2Html();
        }

        internal string Adapter(InputParams inputParams)
        {
            string adapterPatternSampleCode = @"
Adapter Pattern
==============================

Adapter is a structural design pattern, which allows incompatible objects to collaborate.

The Adapter acts as a wrapper between two objects. It catches calls for one object and transforms them to format and interface recognizable by the second object.

[Reference: Refactoring.Guru](https://refactoring.guru/design-patterns/adapter)

### Sample Code:

```C#
    // The Target defines the domain-specific interface used by the client code.
    public interface ITarget
    {
        string GetRequest();
    }

    // The Adaptee contains some useful behavior, but its interface is
    // incompatible with the existing client code. The Adaptee needs some
    // adaptation before the client code can use it.
    class Adaptee
    {
        public string GetSpecificRequest()
        {
            return ""Specific request."";
        }
    }

    // The Adapter makes the Adaptee's interface compatible with the Target's
    // interface.
    class Adapter : ITarget
    {
        private readonly Adaptee _adaptee;

        public Adapter(Adaptee adaptee)
        {
            this._adaptee = adaptee;
        }

        public string GetRequest()
        {
            return $""This is '{this._adaptee.GetSpecificRequest()}'"";
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Adaptee adaptee = new Adaptee();
            ITarget target = new Adapter(adaptee);

            Console.WriteLine(""Adaptee interface is incompatible with the client."");
            Console.WriteLine(""But with adapter client can call it's method."");

            Console.WriteLine(target.GetRequest());
        }
    }

```

### Output:

```Text
Adaptee interface is incompatible with the client.
But with adapter client can call it's method.
This is 'Specific request.'
```

";
            return adapterPatternSampleCode.Md2Html();
        }

        internal string Facade(InputParams inputParams)
        {
            string facadePatternCodeSample = @"
Facade Pattern
==========================

A facade is a class that provides a simple interface to a complex subsystem which contains lots of moving parts. A facade might provide limited functionality in comparison to working with the subsystem directly. However, it includes only those features that clients really care about.

[Reference: Refactoring.Guru](https://refactoring.guru/design-patterns/facade)

### Sample Code
```C#
    // The Facade class provides a simple interface to the complex logic of one
    // or several subsystems. The Facade delegates the client requests to the
    // appropriate objects within the subsystem. The Facade is also responsible
    // for managing their lifecycle. All of this shields the client from the
    // undesired complexity of the subsystem.
    public class Facade
    {
        protected Subsystem1 _subsystem1;
        
        protected Subsystem2 _subsystem2;

        public Facade(Subsystem1 subsystem1, Subsystem2 subsystem2)
        {
            this._subsystem1 = subsystem1;
            this._subsystem2 = subsystem2;
        }
        
        // The Facade's methods are convenient shortcuts to the sophisticated
        // functionality of the subsystems. However, clients get only to a
        // fraction of a subsystem's capabilities.
        public string Operation()
        {
            string result = ""Facade initializes subsystems:\n"";
            result += this._subsystem1.operation1();
            result += this._subsystem2.operation1();
            result += ""Facade orders subsystems to perform the action:\n"";
            result += this._subsystem1.operationN();
            result += this._subsystem2.operationZ();
            return result;
        }
    }
    
    // The Subsystem can accept requests either from the facade or client
    // directly. In any case, to the Subsystem, the Facade is yet another
    // client, and it's not a part of the Subsystem.
    public class Subsystem1
    {
        public string operation1()
        {
            return ""Subsystem1: Ready!\n"";
        }

        public string operationN()
        {
            return ""Subsystem1: Go!\n"";
        }
    }
    
    // Some facades can work with multiple subsystems at the same time.
    public class Subsystem2
    {
        public string operation1()
        {
            return ""Subsystem2: Get ready!\n"";
        }

        public string operationZ()
        {
            return ""Subsystem2: Fire!\n"";
        }
    }


    class Client
    {
        // The client code works with complex subsystems through a simple
        // interface provided by the Facade. When a facade manages the lifecycle
        // of the subsystem, the client might not even know about the existence
        // of the subsystem. This approach lets you keep the complexity under
        // control.
        public static void ClientCode(Facade facade)
        {
            Console.Write(facade.Operation());
        }
    }
    
    class Program
    {
        static void Main(string[] args)
        {
            // The client code may have some of the subsystem's objects already
            // created. In this case, it might be worthwhile to initialize the
            // Facade with these objects instead of letting the Facade create
            // new instances.
            Subsystem1 subsystem1 = new Subsystem1();
            Subsystem2 subsystem2 = new Subsystem2();
            Facade facade = new Facade(subsystem1, subsystem2);
            Client.ClientCode(facade);
        }
    }
```

### Output:

```Text
Facade initializes subsystems:
Subsystem1: Ready!
Subsystem2: Get ready!
Facade orders subsystems to perform the action:
Subsystem1: Go!
Subsystem2: Fire!
```

";

            return facadePatternCodeSample.Md2Html();
        }
        internal string Strategy(InputParams inputParams)
        {
            string strategyPatternCodeString = @"
Strategy Pattern
===============================================
Strategy is a behavioral design pattern that turns a set of behaviors into objects and makes them interchangeable inside original context object.

[Reference: Refactoring.Guru](https://refactoring.guru/design-patterns/strategy)

The original object, called context, holds a reference to a strategy object and delegates it executing the behavior. In order to change the way the context performs its work, other objects may replace the currently linked strategy object with another one.




### Sample Code

```C#
    // The Context defines the interface of interest to clients.
    class Context
    {
        // The Context maintains a reference to one of the Strategy objects. The
        // Context does not know the concrete class of a strategy. It should
        // work with all strategies via the Strategy interface.
        private IStrategy _strategy;

        public Context()
        { }

        // Usually, the Context accepts a strategy through the constructor, but
        // also provides a setter to change it at runtime.
        public Context(IStrategy strategy)
        {
            this._strategy = strategy;
        }

        // Usually, the Context allows replacing a Strategy object at runtime.
        public void SetStrategy(IStrategy strategy)
        {
            this._strategy = strategy;
        }

        // The Context delegates some work to the Strategy object instead of
        // implementing multiple versions of the algorithm on its own.
        public void DoSomeBusinessLogic()
        {
            Console.WriteLine(""Context: Sorting data using the strategy (not sure how it'll do it)"");
            var result = this._strategy.DoAlgorithm(new List<string> { ""a"", ""b"", ""c"", ""d"", ""e"" });

            string resultStr = string.Empty;
            foreach (var element in result as List<string>)
            {
                resultStr += element + "","";
            }

            Console.WriteLine(resultStr);
        }
    }

    public interface IStrategy
    {
        object DoAlgorithm(object data);
    }

    class ConcreteStrategyA : IStrategy
    {
        public object DoAlgorithm(object data)
        {
            var list = data as List<string>;
            list.Sort();

            return list;
        }
    }

    class ConcreteStrategyB : IStrategy
    {
        public object DoAlgorithm(object data)
        {
            var list = data as List<string>;
            list.Sort();
            list.Reverse();

            return list;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            // The client code picks a concrete strategy and passes it to the
            // context. The client should be aware of the differences between
            // strategies in order to make the right choice.
            var context = new Context();

            Console.WriteLine(""Client: Strategy is set to normal sorting."");
            context.SetStrategy(new ConcreteStrategyA());
            context.DoSomeBusinessLogic();
            
            Console.WriteLine();
            
            Console.WriteLine(""Client: Strategy is set to reverse sorting."");
            context.SetStrategy(new ConcreteStrategyB());
            context.DoSomeBusinessLogic();
        }
    }
```

### Output:

```Text
Client: Strategy is set to normal sorting.
Context: Sorting data using the strategy (not sure how it'll do it)
a,b,c,d,e

Client: Strategy is set to reverse sorting.
Context: Sorting data using the strategy (not sure how it'll do it)
e,d,c,b,a
```

";

            return strategyPatternCodeString.Md2Html();
        }

        internal string Builder(InputParams inputParams)
        {
            string builderPatternCodeString = @"
Builder Pattern
============================

[Reference: Refactoring Guru](https://refactoring.guru/design-patterns/builder)

Builder is a creational design pattern that lets you construct complex objects step by step. The pattern allows you to produce different types and representations of an object using the same construction code.





### Director

You can go further and extract a series of calls to the builder steps you use to construct a product into a separate class called director. The director class defines the order in which to execute the building steps, while the builder provides the implementation for those steps.

Having a director class in your program isn’t strictly necessary. You can always call the building steps in a specific order directly from the client code. However, the director class might be a good place to put various construction routines so you can reuse them across your program.

In addition, the director class completely hides the details of product construction from the client code. The client only needs to associate a builder with a director, launch the construction with the director, and get the result from the builder.





### Sample Code

*Here is a very nice and minimal code sample to help you understand the builder pattern*

```C#
// The Builder interface specifies methods for creating the different parts
// of the Product objects.
public interface IBuilder
{
    void BuildPartA();
    void BuildPartB();
    void BuildPartC();
}
    
public class ConcreteBuilder : IBuilder
{
    private Product _product = new Product();
        
    // A fresh builder instance should contain a blank product object, which
    // is used in further assembly.
    public ConcreteBuilder()
    {
        this.Reset();
    }
        
    public void Reset()
    {
        this._product = new Product();
    }
        
    public void BuildPartA()
    {
        this._product.Add(""PartA1"");
    }
        
    public void BuildPartB()
    {
        this._product.Add(""PartB1"");
    }
        
    public void BuildPartC()
    {
        this._product.Add(""PartC1"");
    }
        
    // Concrete Builders are supposed to provide their own methods for
    // retrieving results. That's because various types of builders may
    // create entirely different products that don't follow the same
    // interface. Therefore, such methods cannot be declared in the base
    // Builder interface (at least in a statically typed programming
    // language).
    //
    // Usually, after returning the end result to the client, a builder
    // instance is expected to be ready to start producing another product.
    // That's why it's a usual practice to call the reset method at the end
    // of the `GetProduct` method body. However, this behavior is not
    // mandatory, and you can make your builders wait for an explicit reset
    // call from the client code before disposing of the previous result.
    public Product GetProduct()
    {
        Product result = this._product;

        this.Reset();

        return result;
    }
}
    
// It makes sense to use the Builder pattern only when your products are
// quite complex and require extensive configuration.
public class Product
{
    private List<object> _parts = new List<object>();
        
    public void Add(string part)
    {
        this._parts.Add(part);
    }
        
    public string ListParts()
    {
        return ""Product parts: "" + string.Join("", "", _parts) + ""\n"";
    }
}
    
// The Director is only responsible for executing the building steps in a
// particular sequence. It is helpful when producing products according to a
// specific order or configuration. Strictly speaking, the Director class is
// optional, since the client can control builders directly.
public class Director
{
    private IBuilder _builder;
        
    public IBuilder Builder
    {
        set { _builder = value; } 
    }
        
    // The Director can construct several product variations using the same
    // building steps.
    public void BuildMinimalViableProduct()
    {
        this._builder.BuildPartA();
    }
        
    public void BuildFullFeaturedProduct()
    {
        this._builder.BuildPartA();
        this._builder.BuildPartB();
        this._builder.BuildPartC();
    }
}

class Program
{
    static void Main(string[] args)
    {
        // The client code creates a builder object, passes it to the
        // director and then initiates the construction process. The end
        // result is retrieved from the builder object.
        var director = new Director();
        var builder = new ConcreteBuilder();
        director.Builder = builder;
            
        Console.WriteLine(""Standard basic product:"");
        director.BuildMinimalViableProduct();
        Console.WriteLine(builder.GetProduct().ListParts());

        Console.WriteLine(""Standard full featured product:"");
        director.BuildFullFeaturedProduct();
        Console.WriteLine(builder.GetProduct().ListParts());

        // Remember, the Builder pattern can be used without a Director
        // class.
        Console.WriteLine(""Custom product:"");
        builder.BuildPartA();
        builder.BuildPartC();
        Console.Write(builder.GetProduct().ListParts());
    }
}
```

### Output

```Text
Standard basic product:
Product parts: PartA1

Standard full featured product:
Product parts: PartA1, PartB1, PartC1

Custom product:
Product parts: PartA1, PartC1
```

";
            return builderPatternCodeString.Md2Html();
        }

        internal string FactoryMethod(InputParams inputParams)
        {
            string factoryMethodCode = @"

Factory Method Pattern Sample
=================================

Factory Method is a creational design pattern that provides an interface for creating objects in a superclass, but allows subclasses to alter the type of objects that will be created.


[Reference: Refactoring.Guru](https://refactoring.guru/design-patterns/factory-method)

```C#
/*

-- Creators
Beverage
 ├─── ColdBeverage
 └─── HotBeverage

-- Products
IDrink
 ├─── Code
 ├─── Sprite
 ├─── Coffee
 └─── Tea

*/


// The base Creator class -- declares Factory Method
abstract class Beverage
{
    public abstract Drink GetADrink(); // <--- Factory Method
                                        // Decision of which product to get is deferred to subclasses

    public void Serve()
    {
        Drink drink = GetADrink();  // <--- calling Factory Method to get a Product
        drink.Prepare();
        Console.WriteLine($""\tA {this.GetType().Name} has been served."");
    }
}

// A Concrete Creator
class HotBeverage : Beverage
{
    public override Drink GetADrink()
    {
        return new Tea();
    }
}

// A Concrete Creator
class ColdBeverage : Beverage
{
    public override Drink GetADrink()
    {
        return new Coke();
    }
}

// Product interface
interface Drink
{
    void Prepare();
}

// Product: Coke
class Coke : Drink
{
    public void Prepare()
    {
        Console.WriteLine(""Adding ice to Coke... and it's ready now."");
    }
}

// Product: Sprite
class Sprite : Drink
{
    public void Prepare()
    {
        Console.WriteLine(""Adding ice to Sprite... and it's ready now."");
    }
}

// Product: Tea
class Tea : Drink
{
    public void Prepare()
    {
        Console.WriteLine(""Adding tea bag to hot water and mixing... and it's ready now."");
    }
}

// Product: Coffee
class Coffee : Drink
{
    public void Prepare()
    {
        Console.WriteLine(""Adding Coffee to hot water... and it's ready now."");
    }
}

```

Here is the code that serves a hot and a cold beverage

```C#
    Beverage beverage = new HotBeverage();
    beverage.Serve();
    beverage = new ColdBeverage();
    beverage.Serve();
```

Output:

```Shell
Adding tea bag to hot water and mixing... and it's ready now.
        A HotBeverage has been served.
Adding ice to Coke... and it's ready now.
        A ColdBeverage has been served.
```

";

            return factoryMethodCode.Md2Html();
        }

        internal string AbstractFactory(InputParams inputParams)
        {
            string factoryMethodCode = @"
Abstract Factory Design Pattern
========================================

Abstract Factory is a creational design pattern that lets you produce families of related objects without specifying their concrete classes.


[Reference: Refactoring.Guru](https://refactoring.guru/design-patterns/abstract-factory)


*Here is a relatable scenario from the real word:*

Domain Fact: **In the animal world the food chain amongst Carnivors and Herbivors works like this: Carnivors eat Herbivours.**

*PS. Different continents might have more of a certain species of carnivor and herbivor animals.*

```Text
ContinentFactory        -- Abstract Factory
 ├─── AfricaFactory     -- Concrete Factory --> Lion, Wildebeast
 └─── AmericaFactory    -- Concrete Factory --> Wolf, Bison

Herbivore          -- Abstract Product
 ├─── Wildebeast   -- Concreate Prod
 └─── Bison        -- Concreate Prod

Carnivore          -- Abstract Product
 ├─── Lion         -- Concreate Prod
 └─── Wolf         -- Concreate Prod

AnimalWorld        -- The Client Class uses (works with) abstract products only
 ├---> Herbivore
 └---> Carnivore
```

Abstract Factory Pattern Sample
=================================


```C#
  class AnimalWorld
  {
    private Herbivore _herbivore;
    private Carnivore _carnivore;
 
    // ctor
    public AnimalWorld(ContinentFactory factory)
    {
      _carnivore = factory.CreateCarnivore();
      _herbivore = factory.CreateHerbivore();
    }
 
    public void RunFoodChain()
    {
      _carnivore.Eat(_herbivore);
    }
  }

  // AbstractFactory
  abstract class ContinentFactory
  {
    public abstract Herbivore CreateHerbivore();
    public abstract Carnivore CreateCarnivore();
  }
 
  // ConcreteFactory1
  class AfricaFactory : ContinentFactory
  {
    public override Herbivore CreateHerbivore()
    {
      return new Wildebeest();
    }
    public override Carnivore CreateCarnivore()
    {
      return new Lion();
    }
  }
 
  // ConcreteFactory2
  class AmericaFactory : ContinentFactory
  {
    public override Herbivore CreateHerbivore()
    {
      return new Bison();
    }
    public override Carnivore CreateCarnivore()
    {
      return new Wolf();
    }
  }
 
  // AbstractProductA
  abstract class Herbivore
  {
  }
 
  // AbstractProductB
  abstract class Carnivore
  {
    public abstract void Eat(Herbivore h);
  }
 
  // ProductA1
  class Wildebeest : Herbivore
  {
  }

  // ProductB1
  class Lion : Carnivore
  {
    public override void Eat(Herbivore h)
    {
      // Eat Wildebeest
      Console.WriteLine(this.GetType().Name +
        "" eats "" + h.GetType().Name);
    }
  }
 
  // ProductA2
  class Bison : Herbivore
  {
  }
 
  // ProductB2
  class Wolf : Carnivore
  {
    public override void Eat(Herbivore h)
    {
      // Eat Bison
      Console.WriteLine(this.GetType().Name +
        "" eats "" + h.GetType().Name);
    }
  }

// ----------------- usage ---------------------------

      // Create and run the African animal world
      ContinentFactory africa = new AfricaFactory();
      AnimalWorld world = new AnimalWorld(africa);
      world.RunFoodChain();
 
      // Create and run the American animal world
      ContinentFactory america = new AmericaFactory();
      world = new AnimalWorld(america);
      world.RunFoodChain();

```


Output
-------------


```Text
Lion eats Wildebeest
Wolf eats Bison

```


";

            return factoryMethodCode.Md2Html();
        }

        internal string Singleton(InputParams inputParams)
        {
            string factoryMethodCode = @"
Singleton Design Pattern
=================================

Singleton is a creational design pattern that lets you ensure that a class has only one instance, while providing a global access point to this instance.

[Reference: Refactoring.Guru](https://refactoring.guru/design-patterns/singleton)



```C#


// ----------------- usage ---------------------------

internal class MySingletonDB
{
    private MySingletonDB() { }

    // Making it thread-safe but not lazy loaded
    public static MySingletonDB Instance { get; } = new MySingletonDB();

    public void SomeDbOperation()
    {
        // do some operation
    }
}

```

Output
-------------


```Text
N/A
```


";

            return factoryMethodCode.Md2Html();
        }

        #endregion
    }
}
