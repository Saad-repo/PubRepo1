﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace SDKLibV5.Functionality
{
    internal sealed class Web : FunctionalityBase
    {
        #region IDescribeMyFunctionality
        private static DescribeMyFunctionality<InputParamsBase> _info;
        /// <summary>
        ///     Functionality Info
        /// </summary>
        internal static DescribeMyFunctionality<InputParamsBase> Info
        {
            get
            {
                if (_info is null)
                {
                    #region Class Functionality Definitions and sample inputs
                    var description = @"This class provides HHTP request/response related operations";
                    var desc4GetPage = @"Fetches the content from the given URL and shows in the output";
                    var desc4FetchRecursive = @"Downloads the given urls domain pages";

                    FunctionalityInfo<InputParamsBase> funcGetPage = new(nameof(GetPage), desc4GetPage,
                        new List<InputParams> { new() { Url = Constants.MultiLineIndicator + "https://refactoring.guru/design-patterns/factory-method",
                        Action = "ShowContent     " + Constants.CommentIndicator + "   [ShowContent|ShowHeadLinks|ShowHyperLinks|Download]"} });

                    FunctionalityInfo<InputParamsBase> funcFetchRecursive = new(nameof(FetchRecursive), desc4FetchRecursive,
                        new List<InputParamsFetchRecursive> { new(){Url="https://refactoring.guru",
                        IgnoreUrlPatternList = Constants.MultiLineIndicator + @"https://refactoring.guru/es
https://refactoring.guru/fr
https://refactoring.guru/pl
https://refactoring.guru/pt-br
https://refactoring.guru/ru
https://refactoring.guru/uk
"} });
                    List<FunctionalityInfo<InputParamsBase>> functionalities = new()
                    {
                        funcGetPage,
                        funcFetchRecursive,
                    };
                    #endregion
                    _info = new DescribeMyFunctionality<InputParamsBase>(description, functionalities, new DateTime(2021, 6, 14));
                }
                return _info;
            }
        }
        public class InputParams : InputParamsBase
        {
            public string Action { get; set; } = "ShowContent"; // ShowContent | ShowHead | ShowHeadLinks | ShowHyperLinks | Download
            public string Url { get; set; }
            public InputParams() { }
        }
        public class InputParamsFetchRecursive : InputParamsBase
        {
            public string Url { get; set; }
            public string IgnoreUrlPatternList { get; set; }
            public InputParamsFetchRecursive() { }
        }
        #endregion
        #region Implementations

        private sealed class Consts
        {
            internal const string HyperlinkPattern = @"<a\s+(?:[^>]*?\s+)?href=([""'])(.*?)\1";
            internal const string CssLinkPattern = @"<link\s+(?:[^>]*?\s+)?href=""[^""]+\.css";
            internal const string ImgLinkPattern = @"<img\s+(?:[^>]*?\s+)?src=""[^""]+\.(png|jpg|svg)";
        }

        internal string GetPage(InputParams inputParams)
        {
            var isValidUrl = Uri.TryCreate(inputParams.Url, UriKind.Absolute, out _);
            if (!isValidUrl)
            {
                return $"Given url is not valid: {inputParams.Url}";
            }

            var httpClient = HttpClientFactory.Create();
            //var response = await httpClient.GetAsync(url);
            var response = httpClient.GetAsync(inputParams.Url).Result;
            try
            {

                response.EnsureSuccessStatusCode();
                // var data = await response.Content.ReadAsStringAsync();
                var htmlContent = response.Content.ReadAsStringAsync().Result;


                //string pattern = @"https?:\/\/{1}(\/?[0-9A-Za-z-\\.@:%_\+~#=]+)+\." + fileTypes;
                //string pattern = @"https?:\/\/(\w+\.?)+(\/\w+(-\w+)*)+\." + fileTypes;

                //var urls = GetMatches(pattern, htmlContent);

                //foreach (var u in urls)
                //{
                //    var fName = u.Substring(u.LastIndexOf('/') + 1);
                //    var ba = httpClient.GetByteArrayAsync(u);

                //    var response2 = httpClient.GetByteArrayAsync(u).Result;

                //    var trgFle = System.IO.Path.Combine(targetFolder, fName);
                //    File.WriteAllBytes(trgFle, response2);
                //    txtOutput.Text += trgFle + Environment.NewLine;
                //}

                var action = inputParams.Action.Trim().ToLower();
                switch (action)
                {
                    case "showhead":
                        return GetHead(htmlContent);
                    case "showheadlinks":
                        return GetHeadLinks(htmlContent);
                    case "showhyperlinks":
                        return GetHyperLinks(htmlContent);
                    case "download":
                        return DownloadContent(htmlContent, inputParams.Url);
                }
                // if (inputParams.Action is null || inputParams.Action.Trim().ToLower() == "showcontent")
                return htmlContent;
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        private HashSet<string> fetchedUrls;
        private HashSet<string> savedFiles;
        private List<string> ignoreUrls = new List<string>();
        private string domainRoot;
        private string domainRootFolder;
        private string FetchRecursive(InputParamsFetchRecursive inputParams)
        {
            domainRoot = inputParams.Url;
            CreateFolderForDomainRoot();
            if (!domainRoot.EndsWith('/'))
                domainRoot += "/";
            ignoreUrls.AddRange(inputParams.IgnoreUrlPatternList.ToLines());

            fetchedUrls = new HashSet<string>();
            savedFiles = new HashSet<string>();
            GetPage(inputParams.Url);
            return string.Join("\r\n", fetchedUrls.OrderBy(u => u));
        }

        private void CreateFolderForDomainRoot()
        {
            var folder = domainRoot.Replace("https://", "").Replace("/", "");
            var userProfilePath = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
            var dirname = System.IO.Path.Combine(userProfilePath + "\\Downloads\\", folder);
            domainRootFolder = dirname;
            System.IO.Directory.CreateDirectory(dirname);
        }

        private void GetPage(string url)
        {
            if (ignoreUrls.Any(u => url.ToLower().Contains(u.ToLower())))
                return;

            if (url.EndsWith(".svg") || url.EndsWith(".png") || url.EndsWith(".jpg") || url.EndsWith(".pdf"))
            {
                GetBinaryContent(url);
                return;
            }

            string content = GetContent(url);
            if (content.StartsWith("==========ERROR====> "))
                return;
            string targetFolder = GetTargetFolder(url);
            SaveContent(content, targetFolder);

            var linksInContent = GetLinks(content, Consts.HyperlinkPattern).ToList();
            var styleLinks = GetLinks(content, Consts.CssLinkPattern).ToList();
            var imageLinks = GetLinks(content, Consts.ImgLinkPattern, "src=").ToList();

            var newLinks = linksInContent.Where(l => !fetchedUrls.Contains(l));
            var newStlyeLinks = styleLinks.Where(l => !fetchedUrls.Contains(l));
            var newImageLinks = imageLinks.Where(l => !fetchedUrls.Contains(l));

            RecurseToGetPage(newLinks);
            RecurseToGetPage(newStlyeLinks);
            RecurseToGetPage(newImageLinks);
        }

        private void RecurseToGetPage(IEnumerable<string> newUrls)
        {
            foreach (var link in newUrls)
            {
                GetPage(link);
                fetchedUrls.Add(link);
            }
        }


        private void GetBinaryContent(string url)
        {
            string targetImageFile = GetTargetFolder(url);
            using (WebClient client = new WebClient())
            {
                try
                {
                    client.DownloadFile(new Uri(url), targetImageFile);
                }
                catch (Exception ex)
                {
                    var exx = ex;
                }
            }
        }

        private void SaveContent(string content, string targetFolder)
        {
            if (savedFiles.Contains(targetFolder))
                return;

            savedFiles.Add(targetFolder);

            try
            {
                System.IO.File.WriteAllText(targetFolder, content);
            }
            catch (Exception ex)
            {
                var debug = ex;
                // throw;
            }
        }

        private string GetTargetFolder(string url)
        {
            var subDirParts = url.Replace(domainRoot, "").Split('/');
            var tempDirName = domainRootFolder;
            for (int i = 0; i < subDirParts.Length - 1; i++)
            {
                tempDirName = System.IO.Path.Combine(tempDirName, subDirParts[i].Replace(":", "_").Replace("?", ""));
                System.IO.Directory.CreateDirectory(tempDirName);
            }

            var filename = url.Substring(url.LastIndexOf('/') + 1);

            if (!filename.ToLower().EndsWith(".css")
                && !filename.ToLower().EndsWith(".js")
                && !filename.ToLower().EndsWith(".pdf")
                && !filename.ToLower().EndsWith(".png")
                && !filename.ToLower().EndsWith(".svg")
                && !filename.ToLower().EndsWith(".jpg")
                && !filename.ToLower().EndsWith(".html"))
                filename += ".html";

            if (filename.Contains('?'))
                filename = filename.Substring(0, filename.IndexOf('?'));

            filename = System.IO.Path.Combine(tempDirName, filename);
            // System.IO.File.WriteAllText(filename, htmlContent);

            return filename;
        }

        private IEnumerable<string> GetLinks(string content, string regexPattern, string pathKeyword = "href=")
        {
            Regex regex = new Regex(regexPattern, RegexOptions.IgnoreCase | RegexOptions.Multiline | RegexOptions.Singleline);
            if (regex.IsMatch(content))
            {
                foreach (Match match in regex.Matches(content))
                {
                    if (ignoreUrls.Any(u => match.Value.ToLower().Contains(u.ToLower())))
                        continue;

                    Regex regex2 = new Regex(pathKeyword + @"([""']/)", RegexOptions.IgnoreCase);

                    if (regex2.IsMatch(match.Value))
                    {
                        int dx = match.Value.IndexOf(pathKeyword + "\"/");
                        string acceptedUrl = match.Value.Substring(dx + pathKeyword.Length + 2);
                        if (acceptedUrl.Contains("\""))
                            acceptedUrl = acceptedUrl.Substring(0, acceptedUrl.IndexOf("\""));

                        if (!string.IsNullOrWhiteSpace(acceptedUrl))
                            yield return domainRoot + acceptedUrl;
                    }
                    else if (match.Value.Contains(domainRoot, StringComparison.OrdinalIgnoreCase))
                    {
                        int dx = match.Value.IndexOf(domainRoot);
                        string acceptedUrl = match.Value.Substring(dx);
                        acceptedUrl = acceptedUrl.Substring(0, acceptedUrl.IndexOf("\""));
                        if (!string.IsNullOrWhiteSpace(acceptedUrl))
                            yield return acceptedUrl;
                    }
                }
            }
        }


        private string GetContent(string url)
        {
            var isValidUrl = Uri.TryCreate(url, UriKind.Absolute, out _);
            if (!isValidUrl)
            {
                return $"Given url is not valid: {url}";
            }
            if (fetchedUrls.Contains(url))
                return "";
            else
                fetchedUrls.Add(url);

            var httpClient = HttpClientFactory.Create();
            //var response = await httpClient.GetAsync(url);
            var response = httpClient.GetAsync(url).Result;
            try
            {
                response.EnsureSuccessStatusCode();
                // var data = await response.Content.ReadAsStringAsync();
                var htmlContent = response.Content.ReadAsStringAsync().Result;
                return htmlContent;
            }
            catch (Exception ex)
            {
                return "==========ERROR====> " + ex.Message;
            }
        }

        private string DownloadContent(string htmlContent, string url)
        {
            var filename = url.Substring(url.LastIndexOf('/') + 1);
            if (!filename.Contains('.'))
                filename += ".html";

            if (filename.Contains('?'))
                filename = filename.Substring(0, filename.IndexOf('?'));


            var userProfilePath = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);

            filename = System.IO.Path.Combine(userProfilePath + "\\Downloads\\", filename);

            System.IO.File.WriteAllText(filename, htmlContent);

            return "Content saved to " + filename;
        }

        private string GetHead(string htmlContent)
        {
            var regex = new Regex("<head.*</head>", RegexOptions.IgnoreCase | RegexOptions.Multiline | RegexOptions.Singleline);

            if (regex.IsMatch(htmlContent))
            {
                return regex.Match(htmlContent).Value;
            }

            return "GetHeadLinks";
        }
        private string GetHeadLinks(string htmlContent)
        {
            var regex = new Regex("<head.*</head>", RegexOptions.IgnoreCase | RegexOptions.Multiline | RegexOptions.Singleline);

            if (regex.IsMatch(htmlContent))
            {
                return regex.Match(htmlContent).Value;
            }

            return "GetHeadLinks -- no match found";
        }

        private string GetHyperLinks(string htmlContent)
        {
            var regex = new Regex(@"\b(?:https?://|www\.)\S+\b", RegexOptions.IgnoreCase | RegexOptions.Multiline | RegexOptions.Singleline);
            if (regex.IsMatch(htmlContent))
            {
                StringBuilder sb = new();
                foreach (Match m in regex.Matches(htmlContent))
                {
                    sb.AppendLine(m.Value);
                }

                return sb.ToString();
            }

            return "GetHyperLinks -- no match found";
        }

        #endregion
    }
}
