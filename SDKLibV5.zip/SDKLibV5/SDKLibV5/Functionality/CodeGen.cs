﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SDKLibV5.Functionality
{
    public sealed class CodeGen : FunctionalityBase
    {

        #region IDescribeMyFunctionality
        private static DescribeMyFunctionality<InputParamsBase> _info;

        /// <summary>
        ///     Functionality Info
        /// </summary>
        internal static DescribeMyFunctionality<InputParamsBase> Info
        {
            get
            {
                if (_info is null)
                {
                    #region Class Functionality Definitions and sample inputs
                    var description = @"This class provides code generation functionality";
                    var desc4SqLiteCrudWpf = @"Generates C# and XAML code for the provided details in the input";
                    var desc4SqLiteCrudCmd = @"Generates C# code that does CRUD on SQLite DB for the provided details in the input. Note: This implementation assumes that Table and column names are in lower case in the DB; First column is assumed to be the PK";
                    var desc4Db2Angular = @"Generates Angular components and Web API side of the code for given tables. The purpose of this generate is to speed up creating of a CRUD app";
                    var desc4Db2AccessLayer = @"Generates DAL code for a given set of tables";

                    FunctionalityInfo<InputParamsBase> funcGenSqliteCrudWpf = new(nameof(SqLiteCRUDWpf), desc4SqLiteCrudWpf,
                            new List<InputParams> { new InputParams() });
                    FunctionalityInfo<InputParamsBase> funcGenSqliteCrudCmd = new(nameof(SqLiteCRUDCmd), desc4SqLiteCrudCmd,
                            new List<InputParams> { new InputParams { TableName = "Student", TabDelimitedColumnsMetaData = @$"{SDKLibV5.Constants.MultiLineIndicator}
student_id	int     //##// or integer
first_name	string //##// or text
last_name	string
GPA	real                  //##// or float, decimal
registration_date	date //##// or time | datetime | string | text
" } });
                    var inputParamsDb2Angular = new InputParamsDb2Angular
                    {
                        ConnStr = @"Data Source=""C:\SDK\MyData\SDKs_DB.db3"";      " + $"{SDKLibV5.Constants.CommentIndicator}   SqLite & Ms SQL will be supported",
                        Tables = @"sdk.my_events, sdk.my_events_tags             " + $"{SDKLibV5.Constants.CommentIndicator}   comma delimited table names",
                        ExportPathFolder = @"c:\temp\MyCRUDapp                 " + $"{SDKLibV5.Constants.CommentIndicator}   optional. if NULL or emptyspace output windows is used instead",
                        ORM = $"Dapper                                          {SDKLibV5.Constants.CommentIndicator}   [Dapper|EntityFM]"
                    };

                    FunctionalityInfo<InputParamsBase> funcDb2Angular = new(nameof(Db2Angular), desc4Db2Angular,
                            new List<InputParamsDb2Angular> {
                                inputParamsDb2Angular
                            });

                    FunctionalityInfo<InputParamsBase> funcDb2DAL = new(nameof(Db2DAL), desc4Db2Angular,
                            new List<InputParamsDb2Angular> {
                                inputParamsDb2Angular
                            });

                    List<FunctionalityInfo<InputParamsBase>> functionalities = new()
                    {
                        funcGenSqliteCrudWpf,
                        funcGenSqliteCrudCmd,
                        funcDb2Angular,
                        funcDb2DAL
                    };
                    #endregion

                    _info = new DescribeMyFunctionality<InputParamsBase>(description, functionalities, new DateTime(2021, 5, 1));
                }
                return _info;
            }
        }

        internal class InputParams : InputParamsBase
        {
            public string TableName { get; set; }
            public string UseDapper { get; set; } = "true";  // false is not implemented this point
            public string OutputAsHTML { get; set; } = "true";  // false 
            public string TabDelimitedColumnsMetaData { get; set; }

            public InputParams() { }
        }

        internal class InputParamsDb2Angular : InputParamsBase
        {
            public string ConnStr { get; set; }
            public string Tables { get; set; } // if empty, generate DAL for all tables
            public string ORM { get; set; } // Dapper only for now
            public string ExportPathFolder { get; set; } // gets created if DNE

            public InputParamsDb2Angular() { }
        }


        #endregion

        #region Implementation
        private sealed class Constants
        {
            internal const string TemplateDapperSelectMethod = @"        internal IEnumerable<{{{recordType}}}> Get{{{tableName}}}s(InputParams inputParams)
        {
            var sqlSelect = @""{{{sqlSelect}}}"";

            using IDbConnection conn = GetDbConnection(inputParams.DatabaseFileFullPath);
            conn.Open();
            var queryResult = conn.Query<{{{recordType}}}>(sqlSelect);
            return queryResult;
        }

";
        }
        #region Data Access Layer implementation

        /// <summary>
        /// Generates DAL code for the given DB
        /// </summary>
        /// <param name="inputParams"></param>
        /// <returns></returns>
        internal string Db2DAL(InputParamsDb2Angular inputParams)
        {
            if (GetConnStrType(inputParams.ConnStr) == ConnStrType.SqLite)
            {
                DalGen dalGen = new DalGen4Dapper(inputParams);
                var ttt = dalGen.GenerateCode();
                return ttt;
            }

            return "implementation pending...";
        }

        interface DalGen
        {
            string GenerateCode();
        }

        internal class DalGen4Dapper : DalGen
        {
            InputParamsDb2Angular _inputParams;
            public DalGen4Dapper(InputParamsDb2Angular inputParams)
            {
                _inputParams = inputParams;
            }

            public string GenerateCode()
            {

                SqLiteOps sqLiteOps = new SqLiteOps();
                var tableInfo = sqLiteOps.GetRecords<SqlLiteMasterDto>(new SqLiteOps.InputParams
                {
                    ConnStr = _inputParams.ConnStr,
                    SelectQuery = "SELECT * FROM sqlite_master WHERE type = 'table';"
                });

                var selectedTables = _inputParams.Tables.Split(',');

                var tables = tableInfo.Where(t => selectedTables.Any(s => s.Trim().Equals(t.Name)));

                StringBuilder sbMethods = new();
                StringBuilder sbDtos = new();
                var dapperTemplate = SDKLibV5.Constants.GetEmbeddedResource("SDKLibV5.Resources.StringTemplates.Template4DrapperDAL.cs");

                foreach (var tbl in tables)
                {
                    string tableDtoType = tbl.Tbl_name;
                    if (tableDtoType.Contains("."))
                    {
                        tableDtoType = tableDtoType.Substring(tableDtoType.LastIndexOf(".") + 1);
                    }

                    tableDtoType = FirstCharUpper(tableDtoType);

                    StringBuilder sbTbl = new($"\tinternal class {tableDtoType}" + Environment.NewLine);
                    StringBuilder sbSelect = new($"SELECT ");
                    sbTbl.AppendLine("\t{");

                    string firstColName = GetDtoProperties(tbl.Name, sqLiteOps, sbTbl, sbSelect);
                    sbSelect.AppendLine($"\t\t\t\t\tFROM [{tbl.Name}]");
                    sbSelect.Append($"\t\t\t\t\tORDER BY {firstColName} DESC");

                    sbTbl.AppendLine("\t}\r\n");

                    sbDtos.AppendLine(sbTbl.ToString());
                    // --------------------------------

                    TextTemplate textTemplate = new(Constants.TemplateDapperSelectMethod);
                    textTemplate.Fill(new Dictionary<string, string>() {
                            { "sqlSelect", sbSelect.ToString() },
                            { "recordType", tableDtoType},
                            { "tableName", tableDtoType},
                    });
                    sbMethods.AppendLine(textTemplate.GetText());
                }

                TextTemplate classTemplate = new(dapperTemplate);
                classTemplate.Fill(new Dictionary<string, string>() {
                            { "dtos", sbDtos.ToString().TrimEnd() },
                            { "selectAllMethods", sbMethods.ToString().TrimEnd()}
                    });

                return ("```C#\r\n" + classTemplate.GetText() + "\r\n```").Md2Html();
            }

            private string GetDtoProperties(string tableName, SqLiteOps sqLiteOps, StringBuilder sbTbl, StringBuilder sbSelect)
            {
                var columnInfo = sqLiteOps.GetRecords<SqlLiteMasterDto>(new SqLiteOps.InputParams
                {
                    ConnStr = _inputParams.ConnStr,
                    SelectQuery = $"pragma table_info('{tableName}');"
                });

                foreach (var colInfo in columnInfo)
                {
                    string csType = "string";

                    switch (colInfo.Type)
                    {
                        case "INTEGER":
                            csType = "int"; // or long -- 64bit
                            break;
                        case "BLOB":
                            csType = "Byte[]";
                            break;
                        case "REAL":
                            csType = "double";
                            break;
                    }

                    sbTbl.AppendLine($"\t\tinternal {csType} {FirstCharUpper(colInfo.Name)} {{ get; set; }}");
                }

                sbSelect.AppendLine(string.Join(",\r\n\t\t\t\t\t\t", columnInfo.Select(c => c.Name)));
                return columnInfo.First().Name;
            }

            private string FirstCharUpper(string word)
            {
                return char.ToUpper(word[0]) + word.Substring(1);
            }


        }

        public class SqlLiteMasterDto
        {
            public string Type { get; set; }
            public string Name { get; set; }
            public string Tbl_name { get; set; }
            public int Rootpage { get; set; }
            public string Sql { get; set; }
        }


        public class SqlLiteTblInfoDto
        {
            public int Cid { get; set; }
            public string Name { get; set; }
            public int Type { get; set; }
            public int Notnull { get; set; }
            public string Dflt_value { get; set; }
            public int Pk { get; set; }
        }


        private ConnStrType GetConnStrType(string connStr)
        {
            if (connStr.Contains(".db3") || connStr.Contains("sqlite"))
                return ConnStrType.SqLite;

            return ConnStrType.SqlServer;
        }
        public enum ConnStrType
        {
            SqlServer,
            SqLite
        }

        #endregion



        internal string Db2Angular(InputParamsDb2Angular inputParams)
        {
            return "implementation pending...";
        }



        internal string SqLiteCRUDWpf(InputParams inputParams)
        {
            return "SqLiteCRUDWpf - Pending implementation";
        }

        internal string SqLiteCRUDCmd(InputParams inputParams)
        {
            Dictionary<string, string> columns = GetColumnNamesInPascalCase(inputParams.TabDelimitedColumnsMetaData);

            return GenerateCrud4SqLite(inputParams, columns);
        }

        private Dictionary<string, string> GetColumnNamesInPascalCase(string tabDelimitedColumnsMetaData)
        {
            Dictionary<string, string> cols = new();
            var lines = tabDelimitedColumnsMetaData.ToLines();
            for (int i = 0; i < lines.Length; i++)
            {
                var columns = lines[i].ToColumns();
                cols.Add(columns[0].PascalCase(), columns[1]);
            }

            return cols;
        }

        private string GenerateCrud4SqLite(InputParams inputParams, Dictionary<string, string> columns)
        {
            StringBuilder sb = new();
            string typeName = inputParams.TableName.PascalCase();
            string typeNameVar = char.ToLower(typeName[0]) + typeName[1..];
            string pkField = columns.First().Key;

            // Generate Type
            sb.Append(GenerateType(typeName, columns));

            sb.AppendLine(@$"
// TODO#1: NuGet Install-Package Microsoft.Data.Sqlite
// TODO#2: NuGet Install-Package Dapper
// Note: This implementation assumes a certain plurization when naming tables. You may have to make minor changes. 

using System.Collections.Generic;
using System.Linq;
using System.Data;
using Microsoft.Data.Sqlite; // after TODO#1
using Dapper;               // after TODO#2


internal sealed class DataAccess
{{
    private string _connStr;
    public DataAccess(string connStr)
    {{
        this._connStr = connStr;
    }}

    internal IEnumerable<{typeName}> Get{typeName}s()
    {{
        var query = @""{GenerateGetMethod(inputParams, columns)}"";

        using IDbConnection conn = GetDbConnection(_connStr);
        conn.Open();

        return conn.Query<{typeName}>(query);
    }}


    private IDbConnection GetDbConnection(string connStr)
    {{
        return new SqliteConnection(_connStr);
    }}

    private IDbCommand GetDbCommand(IDbConnection conn, string sqlText)
    {{
        return new SqliteCommand(sqlText, (SqliteConnection)conn);
    }}

    private IDbDataParameter GetDataParameter(string name, object value)
    {{
        if (value is null)
            return new SqliteParameter(name, DBNull.Value);

        return new SqliteParameter(name, value);
    }}


    internal int Save{typeName}s(IEnumerable<{typeName}> {typeNameVar}s)
    {{
        var updateQry = @""{GenerateSaveMethod(inputParams, columns)}"";

        int count = 0;
        using IDbConnection conn = GetDbConnection(_connStr);
        conn.Open();

        foreach (var {typeNameVar} in {typeNameVar}s)
        {{
            var updateCmd = GetDbCommand(conn, updateQry);
{GetAddParamsCode(columns, "updateCmd", typeNameVar)}
            count += updateCmd.ExecuteNonQuery();

            if (!{typeNameVar}.{pkField}.HasValue)
            {{
                var rowId = conn.Query<string>(""select last_insert_rowid();"");
                {typeNameVar}.{pkField} = int.Parse(rowId.First());
            }}
        }}

        return count;
    }}

}}
");

            if (bool.TryParse(inputParams.OutputAsHTML, out var result) && result)
            {
                MarkUpHTML.InputParams mdParams = new MarkUpHTML.InputParams
                {
                    Code = sb.ToString()
                    // CssInclusionType = "Inline",
                };
                MarkUpHTML markUpHTML = new();

                return markUpHTML.SyntaxHighlight(mdParams);
            }

            return sb.ToString();
        }

        private string GetAddParamsCode(Dictionary<string, string> columns, string sqlCmdVar, string typeNameVar)
        {
            StringBuilder sb = new();
            foreach (var col in columns)
            {
                sb.AppendLine($"\t\t{sqlCmdVar}.Parameters.Add(GetDataParameter(\"@{col.Key.ToLowerWithUnderscore()}\", {typeNameVar}.{col.Key}));");
            }
            return sb.ToString();
        }

        private string GenerateGetMethod(InputParams inputParams, Dictionary<string, string> columns)
        {
            StringBuilder sb = new();
            sb.AppendLine("SELECT ");
            var mxLen = columns.Max(x => x.Key.Length) + 5;
            foreach (var col in columns)
            {
                var colName = $"[{col.Key.ToLowerWithUnderscore()}]";
                if (columns.First().Key == col.Key)
                {
                    sb.AppendLine($"\t {colName.PadRight(mxLen)} {col.Key}");
                }
                else
                    sb.AppendLine($"\t,{colName.PadRight(mxLen)} {col.Key}");
            }

            sb.AppendLine($"FROM [{inputParams.TableName.ToLowerWithUnderscore()}s]");
            return sb.ToString();
        }

        private string GenerateSaveMethod(InputParams inputParams, Dictionary<string, string> columns)
        {
            StringBuilder sb = new();
            sb.AppendLine($"INSERT or REPLACE INTO [{inputParams.TableName.ToLowerWithUnderscore()}s] (");
            sb.Append(GetColumnsList(columns));
            sb.AppendLine($") VALUES (");
            sb.Append(GetColumnsList(columns, true));
            sb.AppendLine(")");
            return sb.ToString();
        }

        private string GetColumnsList(Dictionary<string, string> columns, bool isParam = false)
        {
            StringBuilder sb = new();
            foreach (var col in columns)
            {
                var colName = $"[{col.Key.ToLowerWithUnderscore()}]";
                if (isParam)
                    colName = $"@{col.Key.ToLowerWithUnderscore()}";

                if (columns.First().Key == col.Key)
                    sb.AppendLine($"\t {colName}");
                else
                    sb.AppendLine($"\t,{colName}");
            }

            return sb.ToString();
        }

        private string GenerateType(string tableName, Dictionary<string, string> columns)
        {
            StringBuilder sb = new();
            sb.AppendLine("internal sealed class " + tableName);
            sb.AppendLine("{");
            foreach (var col in columns)
            {
                var fieldName = $"_{char.ToLower(col.Key[0])}{col.Key.Substring(1)}";
                var typeName = Map2CSharpType(col.Value);
                if (col.Key == columns.First().Key)
                    typeName += "?";

                sb.AppendLine($"\tprivate {typeName} {fieldName};");
            }
            sb.AppendLine("");

            // properties
            foreach (var col in columns)
            {
                var fieldName = $"_{char.ToLower(col.Key[0])}{col.Key.Substring(1)}";
                var typeName = Map2CSharpType(col.Value);
                if (col.Key == columns.First().Key)
                    typeName += "?";

                sb.AppendLine($"\tpublic {typeName} {col.Key}");
                sb.AppendLine("\t{");
                sb.AppendLine($"\t\tget {{ return {fieldName}; }}");
                sb.AppendLine($"\t\tset {{ {fieldName} = value; }}");
                sb.AppendLine("\t}");
            }

            sb.AppendLine("}");
            sb.AppendLine("");
            return sb.ToString();
        }

        private object Map2CSharpType(string value)
        {
            var typeName = value.ToLower();

            switch (typeName)
            {
                case "integer":
                    return "int";
                case "text":
                    return "string";
                case "date":
                case "time":
                case "datetime":
                    return "DateTime";
                case "real":
                    return "decimal";
            }

            return value;
        }

        #endregion

    }
}
