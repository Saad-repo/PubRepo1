﻿using Dapper;
using Microsoft.Data.Sqlite;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace SDKLibV5.Functionality
{
    public sealed class SqLiteOps : FunctionalityBase
    {

        #region IDescribeMyFunctionality
        private static DescribeMyFunctionality<InputParamsBase> _info;

        /// <summary>
        ///     Functionality Info
        /// </summary>
        internal static DescribeMyFunctionality<InputParamsBase> Info
        {
            get
            {
                if (_info is null)
                {
                    #region Class Functionality Definitions and sample inputs
                    var description = @"This class provides SqLite related operations";
                    var desc4CreateDatabase = @"Creates a new SqLite database at the given path";
                    var desc4GetRecords = @"Executes the given select query on the given DB";

                    FunctionalityInfo<InputParamsBase> funcGenSqliteCrudWpf = new(nameof(CreateDatabase), desc4CreateDatabase,
                            new List<InputParams> { new InputParams(@"c:\temp\my_sqlite_db.db3") });

                    FunctionalityInfo<InputParamsBase> funcGetRecords = new(nameof(GetRecords), desc4GetRecords,
                            new List<InputParams> { new InputParams(@"C:\SDK\MyData\SDKs_DB.db3") { SelectQuery = "SELECT * FROM [sdk.my_events] order by event_dt desc",
                            Format = "txt     " + Constants.CommentIndicator + "    [txt|md|html]"} });

                    List<FunctionalityInfo<InputParamsBase>> functionalities = new()
                    {
                        funcGenSqliteCrudWpf,
                        funcGetRecords,
                    };
                    #endregion

                    _info = new DescribeMyFunctionality<InputParamsBase>(description, functionalities, new DateTime(2021, 5, 7));
                }
                return _info;
            }
        }

        internal class InputParams : InputParamsBase
        {
            public string ConnStr { get; set; }

            public string SelectQuery { get; set; }
            public string Format { get; set; }
            public InputParams() { }

            public InputParams(string fullpath)
            {
                ConnStr = fullpath;
            }
        }
        #endregion

        #region Implementation

        internal string CreateDatabase(InputParams inputParams)
        {
            return "CreateDatabase - Implementation pending... Note: You can use the DBNavigator to create new DB files. Simply change the file name in your connection string and issue a CREATE TABLE command. A new DB file gets created after that.";
        }

        internal string GetRecords(InputParams inputParams)
        {
            StringBuilder sb = new();
            var sqlSelect = inputParams.SelectQuery;
            using IDbConnection conn = GetDbConnection(inputParams.ConnStr);
            conn.Open();
            var queryResult = conn.Query(sqlSelect);
            var firstRow = queryResult.FirstOrDefault();
            var heading = ((IDictionary<string, object>)firstRow).Keys.ToArray();
            sb.AppendLine(string.Join('\t', heading));

            foreach (IDictionary<string, object> dapperRow in queryResult)
            {
                sb.AppendLine(string.Join('\t', dapperRow.Values));
            }

            switch (inputParams.Format.Trim().ToLower())
            {
                case "md":
                    MarkDown2Html markDown = new MarkDown2Html();
                    var md = markDown.Data2MdTbl(new MarkDown2Html.InputParams() { TabDelimitedData = sb.ToString() });
                    return md;
                case "html":
                    HTML hTML = new HTML();
                    var htmlTbl = hTML.Data2HtmlTbl(new HTML.InputParams() { Data = sb.ToString() });
                    return htmlTbl;
                default: //  "txt":
                    return sb.ToString();
            }
        }

        internal IEnumerable<T> GetRecords<T>(InputParams inputParams)
        {
            var sqlSelect = inputParams.SelectQuery;
            using IDbConnection conn = new SqliteConnection(inputParams.ConnStr);
            conn.Open();
            var queryResult = conn.Query<T>(sqlSelect);
            return queryResult;
        }


        internal IEnumerable<SdkEvent> GetEvents(InputParams inputParams)
        {
            var sqlSelect = @"SELECT event_id EventId, 
                                     event_dt EventDt, 
                                     notes Notes FROM [sdk.my_events] ORDER BY event_dt DESC";

            using IDbConnection conn = GetDbConnection(inputParams.ConnStr);
            conn.Open();
            var queryResult = conn.Query<SdkEvent>(sqlSelect);
            return queryResult;
        }

        internal int SaveEvent(string dbFilePath, SdkEvent sdkEvent)
        {
            StringBuilder sb = new();
            var sqlPersist = @"INSERT or REPLACE INTO [sdk.my_events]
                                                        ([event_id], [event_dt], [notes]) 
                                                            VALUES 
                                                        (@event_id, @event_dt, @notes)";

            using System.Data.IDbConnection conn = GetDbConnection(dbFilePath);
            conn.Open();
            var updateCmd = GetDbCommand(conn, sqlPersist);
            updateCmd.Parameters.Add(GetDataParameter("@event_id", sdkEvent.EventId));
            updateCmd.Parameters.Add(GetDataParameter("@event_dt", sdkEvent.EventDt));
            updateCmd.Parameters.Add(GetDataParameter("@notes", sdkEvent.Notes));

            return updateCmd.ExecuteNonQuery();
        }

        internal int DeleteEvent(string dbFilePath, int eventId)
        {
            StringBuilder sb = new();
            var sqlDelete = $"DELETE FROM [sdk.my_events] WHERE [event_id] = {eventId}";

            using System.Data.IDbConnection conn = GetDbConnection(dbFilePath);
            conn.Open();
            var deleteCmd = GetDbCommand(conn, sqlDelete);
            return deleteCmd.ExecuteNonQuery();
        }



        internal class SdkEvent
        {
            public int? EventId { get; set; }

            public DateTime EventDt { get; set; }

            public string Notes { get; set; }
        }


        private System.Data.IDbConnection GetDbConnection(string fullPath)
        {
            return new SqliteConnection($"Data Source=\"{fullPath}\";");
        }

        private IDbCommand GetDbCommand(IDbConnection conn, string sqlText)
        {
            return new SqliteCommand(sqlText, (SqliteConnection)conn);
        }

        private IDbDataParameter GetDataParameter(string name, object value)
        {
            if (value is null)
                return new SqliteParameter(name, DBNull.Value);

            return new SqliteParameter(name, value);
        }



        #endregion

    }
}
