﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SDKLibV5.Functionality
{
    internal sealed class DataStats : FunctionalityBase
    {

        #region IDescribeMyFunctionality
        private static DescribeMyFunctionality<InputParamsBase> _info;

        /// <summary>
        ///     Functionality Info
        /// </summary>
        internal static DescribeMyFunctionality<InputParamsBase> Info
        {
            get
            {
                if (_info is null)
                {
                    #region Class Functionality Definitions and sample inputs
                    var description = @"This class provides data statistics related operations";
                    var desc4OrderByColumnIndex = @"Orders the data by the specified column index";
                    var desc4GroupDataByFirstColumn = @"Groups the given, single-column data";
                    var desc4GroupDataByEachColumn = @"Groups the given data by each of its columns";
                    var desc4NormalizeDataByAColumn = @"Normalizes the given data by the specified column index";

                    FunctionalityInfo<InputParamsBase> funcOrderByColumnIndex = new(nameof(OrderByColumn), desc4OrderByColumnIndex,
                            new List<InputParams> { new InputParams(@$"{SDKLibV5.Constants.MultiLineIndicator}001	Al-Fatiha	7	Makkah
002	Al-Baqarah	286	Madinah
003	Al Imran	200	Madinah
004	An-Nisa	176	Madinah
005	Al-Ma'idah	120	Madinah
006	Al-An'am	165	Makkah
007	Al-A'raf	206	Makkah
008	Al-Anfal	75	Madinah
009	At-Tawbah	129	Madinah
010	Yunus	109	Makkah
011	Hud	123	Makkah
012	Yusuf	111	Makkah
013	Ar-Ra'd	43	Madinah
014	Ibrahim	52	Makkah
015	Al-Hijr	99	Makkah
016	An-Nahl	128	Makkah
017	Al-Isra	111	Makkah
018	Al-Kahf	110	Makkah
019	Maryam	98	Makkah
020	Ta-Ha	135	Makkah
021	Al-Anbiya	112	Makkah
022	Al-Hajj	78	Madinah
023	Al-Mu'minun	118	Makkah
024	An-Nur	64	Madinah
025	Al-Furqan	77	Makkah
026	Ash-Shu'ara	227	Makkah
027	An-Naml	93	Makkah
028	Al-Qasas	88	Makkah
029	Al-Ankabut	69	Makkah
030	Ar-Rum	60	Makkah
031	Luqmaan	34	Makkah
032	As-Sajda	30	Makkah
033	Al-Ahzaab	73	Madinah
034	Saba (surah)	54	Makkah
035	Faatir	45	Makkah
036	Yaseen	83	Makkah
037	As-Saaffaat	182	Makkah
038	Saad	88	Makkah
039	Az-Zumar	75	Makkah
040	Ghafir	85	Makkah
041	Fussilat	54	Makkah
042	Ash_Shooraa	53	Makkah
043	Az-Zukhruf	89	Makkah
044	Ad-Dukhaan	59	Makkah
045	Al-Jaathiyah	37	Makkah
046	Al-Ahqaaf	35	Makkah
047	Muhammad	38	Madinah
048	Al-Fath	29	Madinah
049	Al-Hujuraat	18	Madinah
050	Qaaf	45	Makkah
051	Adh-Dhaariyaat	60	Makkah
052	At-Toor	49	Makkah
053	An-Najm	62	Makkah
054	Al-Qamar	55	Makkah
055	Ar-Rahman	78	Madinah
056	Al-Waqi'a	96	Makkah
057	Al-Hadeed	29	Madinah
058	Al-Mujadila	22	Madinah
059	Al-Hashr	24	Madinah
060	Al-Mumtahanah	13	Madinah
061	As-Saff	14	Madinah
062	Al-Jumu'ah	11	Madinah
063	Al-Munafiqoon	11	Madinah
064	At-Taghabun	18	Madinah
065	At-Talaq	12	Madinah
066	At-Tahreem	12	Madinah
067	Al-Mulk	30	Makkah
068	Al-Qalam	52	Makkah
069	Al-Haaqqa	52	Makkah
070	Al-Ma'aarij	44	Makkah
071	Nooh	28	Makkah
072	Al-Jinn	28	Makkah
073	Al-Muzzammil	20	Makkah
074	Al-Muddaththir	56	Makkah
075	Al-Qiyamah	40	Makkah
076	Al-Insaan	31	Madinah
077	Al-Mursalaat	50	Makkah
078	An-Naba'	40	Makkah
079	An-Naazi'aat	46	Makkah
080	Abasa	42	Makkah
081	At-Takweer	29	Makkah
082	Al-Infitar	19	Makkah
083	Al-Mutaffifeen	36	Makkah
084	Al-Inshiqaaq	25	Makkah
085	Al-Burooj	22	Makkah
086	At-Taariq	17	Makkah
087	Al-A'laa	19	Makkah
088	Al-Ghaashiyah	26	Makkah
089	Al-Fajr	30	Makkah
090	Al-Balad	20	Makkah
091	Ash-Shams	15	Makkah
092	Al-Layl	21	Makkah
093	Ad-Dhuha	11	Makkah
094	Ash-Sharh (Al-Inshirah)	8	Makkah
095	At-Teen	8	Makkah
096	Al-Alaq	19	Makkah
097	Al-Qadr	5	Makkah
098	Al-Bayyinahh	8	Madinah
099	Az-Zalzalah	8	Madinah
100	Al-'Aadiyaat	11	Makkah
101	Al-Qaari'ah	11	Makkah
102	At-Takaathur	8	Makkah
103	Al-'Asr	3	Makkah
104	Al-Humazah	9	Makkah
105	Al-Feel	5	Makkah
106	Quraysh	4	Makkah
107	Al-Maa'oon	7	Makkah
108	Al-Kawthar	3	Makkah
109	Al-Kaafiroon	6	Makkah
110	An-Nasr	3	Madinah
111	Al-Masad	5	Makkah
112	Al-Ikhlaas	4	Makkah
113	Al-Falaq	5	Makkah
114	Al-Naas	6	Makkah", 2) });

                    FunctionalityInfo<InputParamsBase> funcGroupSingleColumn = new(nameof(GroupSingleColumn), desc4GroupDataByFirstColumn,
                            new List<InputParams> { new InputParams(@$"{SDKLibV5.Constants.MultiLineIndicator}Demo
SystemManuScripts
None
None
SystemManuScripts
Admin
Integration
SystemManuScripts
SystemManuScripts
SystemManuScripts
SystemManuScripts
Admin
SystemManuScripts
Admin
SystemManuScripts
SystemManuScripts
Admin
Admin
Admin
Admin
Admin
Admin
Admin
Admin
Admin
SystemManuScripts
SystemManuScripts
SystemManuScripts
SystemManuScripts
SystemManuScripts
SystemManuScripts
Admin
DCTBaseProducts
SystemManuScripts
None
None
SystemManuScripts
Integration
SystemManuScripts
SystemManuScripts
SystemManuScripts
SystemManuScripts
CarrierAdmin
SystemManuScripts
SystemManuScripts
CarrierAdmin
CarrierAdmin
CarrierAdmin
CarrierAdmin
CarrierAdmin
CarrierAdmin
CarrierAdmin
SystemManuScripts
SystemManuScripts
SystemManuScripts
SystemManuScripts
SystemManuScripts
SystemManuScripts
CarrierAdmin
DCTBaseProducts
Admin
Billing
Billing
Billing
Billing
CarrierAdmin
Base
DCTSampleProducts
Base
Base
Line1
Base
DCTSampleProducts
DCTSampleProducts
DCTSampleProducts
ExtractMap
ExtractMap
ExtractMap
MM
DCTBaseProducts
Base
PersonalAuto
Base
Base
Base
VehicleBase
VehicleBase
PersonalAuto
PersonalLines
Base
Base
PersonalAuto
None
None
Yodil
Policy
Policy
Policy
Policy
DCTBaseIntegration
DCTBaseIntegration
DCTBaseIntegration
DCTBaseIntegration
TransACT
CarrierAdmin
CarrierAdmin
TransACT
TransACT
CarrierAdmin
TransACT
CarrierAdmin
TransACT
CarrierAdmin
CarrierAdmin
TransACT
CarrierAdmin
TransACT
CarrierAdmin
TransACT
CarrierAdmin
CarrierAdmin
CarrierAdmin
CarrierAdmin
TransACT
CarrierAdmin
TransACT
CarrierAdmin
TransACT
CarrierAdmin
TransACT
CarrierAdmin
TransACT
CarrierAdmin
TransACT
CarrierAdmin
TransACT
CarrierAdmin
TransACT
CarrierAdmin
TransACT
CarrierAdmin
TransACT
CarrierAdmin
TransACT
CarrierAdmin
TransACT
CarrierAdmin
TransACT
CarrierAdmin
TransACT
CarrierAdmin
TransACT
CarrierAdmin
TransACT
CarrierAdmin
TransACT
CarrierAdmin
TransACT
CarrierAdmin
TransACT
CarrierAdmin
TransACT
CarrierAdmin
TransACT
CarrierAdmin
TransACT
CarrierAdmin
TransACT
CarrierAdmin
TransACT
CarrierAdmin
TransACT
CarrierAdmin
TransACT
Admin
Admin
Admin
TransACT
Admin
TransACT
Admin
TransACT
Admin
TransACT
TransACT
Admin
TransACT
Admin
TransACT
Admin
TransACT
Admin
Admin
Admin
Admin
TransACT
Admin
TransACT
Admin
TransACT
Admin
TransACT
Admin
TransACT
Admin
TransACT
Admin
TransACT
Admin
TransACT
Admin
TransACT
Admin
TransACT
Admin
TransACT
Admin
TransACT
Admin
TransACT
Admin
TransACT
Admin
TransACT
Admin
TransACT
Admin
TransACT
Admin
TransACT
Admin
TransACT
Admin
TransACT
Admin
TransACT
Admin
TransACT
Admin
TransACT
Admin
TransACT
Admin
TransACT
Admin
CarrierAdmin
CarrierAdmin
CarrierAdmin
CarrierAdmin
Admin
Admin
Admin
Admin
Admin
CarrierAdmin
Line1
Admin
Admin
Admin
Admin
CarrierAdmin
CarrierAdmin
CarrierAdmin
CarrierAdmin
CarrierAdmin
CarrierAdmin
Base
PersonalAuto
Base
Base
PersonalAuto
PersonalAuto
PersonalLines
PersonalLines
Cycle
Cycle
PersonalUmbrella
PersonalUmbrella
PersonalAuto
Cycle
PersonalUmbrella
CarrierAdmin
CarrierAdmin
PersonalUmbrella
VehicleBase
PersonalLines
CopyPolicy
VehicleBase
CarrierAdmin
PersonalAuto
CarrierAdmin
CarrierAdmin
CarrierAdmin
TransACT
Admin
TransACT
CarrierAdmin
AutomatedProcess
VehicleBase") });

                    FunctionalityInfo<InputParamsBase> funcOrderByEachColumn = new(nameof(OrderByEachColumn), desc4GroupDataByEachColumn,
                        new List<InputParams> { new InputParams { FirstRowHasColumnNames=true, TabDelimData=@$"{Constants.MultiLineIndicator}Col1	Col2	Col3
A	Z1	TT
B	Z1	TX
B	Z2	TT
B	Z2	TX
C	Z2	TX
C	XX	TX
D	XY	TZ
", ColumnIndex=null } });

                    FunctionalityInfo<InputParamsBase> funcNormalizeDataByAColumn = new(nameof(NormalizeDataByAColumn), desc4NormalizeDataByAColumn,
                        new List<InputParams> { new InputParams { FirstRowHasColumnNames=true, TabDelimData=@$"{Constants.MultiLineIndicator}Col1	Col2	Col3
A	Z1	TT
B	Z1	TX
B	Z2	TT
B	Z2	TX
C	Z2	TX
C	XX	TX
D	XY	TZ
", ColumnIndex=0 } });
                    List <FunctionalityInfo<InputParamsBase>> functionalities = new()
                    {
                        funcOrderByColumnIndex,
                        funcGroupSingleColumn,
                        funcOrderByEachColumn,
                        funcNormalizeDataByAColumn,
                    };
                    #endregion

                    _info = new DescribeMyFunctionality<InputParamsBase>(description, functionalities, new DateTime(2021, 5, 7));
                }
                return _info;
            }
        }

        internal class InputParams : InputParamsBase
        {
            public int? ColumnIndex { get; set; } = 0;
            public bool? FirstRowHasColumnNames { get; set; } = null;
            public string TabDelimData { get; set; }

            public InputParams() { }
            public InputParams(string data)
            {
                TabDelimData = data;
            }

            public InputParams(string data, int columnDx)
            {
                TabDelimData = data;
                ColumnIndex = columnDx;
            }
        }
        #endregion

        #region Implementation

        internal string NormalizeDataByAColumn(InputParams inputParams)
        {
            List<string[]> entries = new List<string[]>();
            List<string> colNames = new List<string>();
            int colDx = inputParams.ColumnIndex.Value;
            var colNamesOnFirstRow = inputParams.FirstRowHasColumnNames.Value;

            var dtTbl = DataStats.ConvertString2DataTable(inputParams.TabDelimData, colNamesOnFirstRow);
            var colNam = dtTbl.Columns[colDx].ColumnName;

            var distinctVals = dtTbl.AsEnumerable().Select(x => x.Field<string>(colNam)).Distinct();
            var includedCols = dtTbl.Columns.Cast<DataColumn>().Where(c => c.ColumnName != colNam).ToList();

            StringBuilder sb = new StringBuilder();
            foreach (var distinctVal in distinctVals)
            {
                sb.AppendLine($"\r\n------===[ {colNam}: {distinctVal} ]===-------");
                sb.AppendLine(string.Join("\t", dtTbl.Columns.Cast<DataColumn>().Select(c => c.ColumnName)));
                var matchingRecords = dtTbl.AsEnumerable().Where(r => r.Field<string>(colNam) == distinctVal).Where(r => includedCols.Select(c => r[c]).Any());
                var tblWithoutCol = dtTbl.Rows.Cast<DataRow>().Where(r => includedCols.Select(c => r[c]).Any());

                foreach (DataRow record in matchingRecords)
                {
                    // sb.AppendLine(string.Join("\t", record.ItemArray.Select(arg => arg.ToString())));
                    sb.AppendLine(string.Join("\t", record.ItemArray.Select(arg => arg.ToString())));

                }
            }

            return sb.ToString();
        }

        internal string OrderByEachColumn(InputParams inputParams) => GroupByEachColumn(inputParams.TabDelimData, inputParams.FirstRowHasColumnNames.Value);

        internal string OrderByColumn(InputParams inputParams)
        {
            string[] lines = inputParams.TabDelimData.Split(new string[] { "\r\n" }, StringSplitOptions.RemoveEmptyEntries);
            int colDx = inputParams.ColumnIndex.Value;
            // numeric sort
            var numericSort = GetNumericSorted(lines, colDx);
            if (numericSort != null)
                return numericSort;

            // datetime sort
            var dateTimeSort = GetDateTimeSorted(lines, colDx);
            if (dateTimeSort != null)
                return dateTimeSort;

            // string sort
            var strSorter = new StringSorter[lines.Length];
            for (int i = 0; i < lines.Length; i++)
            {
                string line = lines[i];
                string[] cols = line.Split('\t');
                strSorter[i] = new StringSorter { StrValue = cols[colDx], Record = line };
            }

            return string.Join("\r\n", strSorter.OrderBy(x => x.StrValue).Select(d => d.Record));
        }

        internal string GroupSingleColumn(InputParams inputParams)
        {
            List<string> entries = new List<string>();
            string[] lines = inputParams.TabDelimData.Split(new string[] { "\r\n", "\n", "\r" }, StringSplitOptions.None);

            for (int i = 0; i < lines.Length; i++)
            {
                string line = lines[i].Trim();
                if (line.Length > 0)
                    entries.Add(line);
            }

            var distincts = entries.Distinct().OrderByDescending(x => entries.Count(y => y == x));

            StringBuilder sb = new StringBuilder();
            foreach (var dist in distincts)
            {
                // counts.Add(dist, entries.Count(x => x == dist));
                sb.AppendLine($"{dist}\t{entries.Count(x => x == dist)}");
            }

            return sb.ToString();
        }

        private string GroupByEachColumn(string text, bool colNamesOnFirstRow)
        {
            string[] lines = text.Split(new string[] { "\r\n", "\n", "\r" }, StringSplitOptions.None);

            List<string[]> entries = new();
            List<string> colNames = new();


            int maxColCount = -1;
            bool firstColFetched = false;
            for (int i = 0; i < lines.Length; i++)
            {
                string line = lines[i].Trim();
                if (line.Length > 0 && !line.StartsWith(">"))
                {

                    string[] lineParts = line.Split('\t');
                    if (colNamesOnFirstRow && !firstColFetched)
                    {
                        for (int k = 0; k < lineParts.Length; k++)
                        {
                            colNames.Add(lineParts[k].ToUpper().Trim());
                        }
                        firstColFetched = true;
                    }
                    else
                        entries.Add(lineParts);

                    if (maxColCount < lineParts.Length)
                        maxColCount = lineParts.Length;
                }
            }

            int rCount = entries.Count;
            int cCount = maxColCount;

            Dictionary<string, int>[] grouped = new Dictionary<string, int>[maxColCount];

            foreach (var entry in entries)
            {
                for (int i = 0; i < maxColCount; i++)
                {
                    if (grouped[i] == null)
                    {
                        grouped[i] = new Dictionary<string, int>();
                        grouped[i].Add(entry[i], 1);
                    }
                    else
                    {
                        if (grouped[i].ContainsKey(entry[i]))
                            grouped[i][entry[i]] = grouped[i][entry[i]] + 1;
                        else
                            grouped[i].Add(entry[i], 1);
                    }
                }

            }

            var distincts = entries.Distinct().OrderBy(x => x);

            Dictionary<string, int> counts = new();

            int z = 0;
            StringBuilder sb = new StringBuilder();
            foreach (var grp in grouped)
            {
                // counts.Add(dist, entries.Count(x => x == dist));

                if (colNamesOnFirstRow)
                    sb.AppendLine($"\r\n================= {colNames[z++]} ======================");
                else
                    sb.AppendLine($"\r\n================= col{z++} ======================");
                foreach (var kVal in grp)
                {
                    sb.AppendLine($"{kVal.Value}\t{kVal.Key}");
                }
            }

            return sb.ToString();
        }


        public static DataTable ConvertString2DataTable(string tabDelimitedTableContent, bool firstRowIsColumnNames = true)
        {
            DataTable tbl = new DataTable();

            string[] rows = tabDelimitedTableContent.Split(new string[] { "\r\n", "\n", "\r" }, StringSplitOptions.RemoveEmptyEntries);
            var firstRowCols = rows.First().Split('\t');
            int dataStartDx = 0;
            if (firstRowIsColumnNames)
            {
                dataStartDx = 1;
                foreach (var col in firstRowCols)
                {
                    tbl.Columns.Add(col, typeof(string));
                }
            }
            else
            {
                dataStartDx = 0;
                for (int i = 0; i < firstRowCols.Length; i++)
                {
                    tbl.Columns.Add($"col{i}", typeof(string));
                }
            }

            for (int i = dataStartDx; i < rows.Length; i++)
            {
                tbl.Rows.Add(rows[i].Split('\t'));
            }

            return tbl;
        }


        private string GetDateTimeSorted(string[] lines, int sortColumnIndex)
        {
            var numericCol = new DateTimeSorter[lines.Length];
            var isNumeric = true;
            for (int i = 0; i < lines.Length; i++)
            {
                string line = lines[i];
                string[] cols = line.Split('\t');
                if (!DateTime.TryParse(cols[sortColumnIndex], out var dateTimeVal))
                {
                    isNumeric = false;
                    break;
                }
                numericCol[i] = new DateTimeSorter { DateTimeVal = dateTimeVal, Record = line };
            }

            if (isNumeric)
            {
                return string.Join("\r\n", numericCol.OrderBy(x => x.DateTimeVal).Select(d => d.Record));
            }

            return null;
        }

        private string GetNumericSorted(string[] lines, int sortColumnDx)
        {
            var numericCol = new NumericSorter[lines.Length];
            var isNumeric = true;
            for (int i = 0; i < lines.Length; i++)
            {
                string line = lines[i];
                string[] cols = line.Split('\t');
                if (!decimal.TryParse(cols[sortColumnDx], out var number))
                {
                    isNumeric = false;
                    break;
                }
                numericCol[i] = new NumericSorter { NumValue = number, Record = line };
            }

            if (isNumeric)
            {
                return string.Join("\r\n", numericCol.OrderBy(x => x.NumValue).Select(d => d.Record));
            }

            return null;
        }

        private class NumericSorter
        {
            public decimal NumValue { get; set; }
            public string Record { get; set; }
        }
        private class DateTimeSorter
        {
            public DateTime DateTimeVal { get; set; }
            public string Record { get; set; }
        }
        private class StringSorter
        {
            public string StrValue { get; set; }
            public string Record { get; set; }
        }

        #endregion


    }


}
