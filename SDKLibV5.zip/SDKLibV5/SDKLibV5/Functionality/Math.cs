﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SDKLibV5.Functionality
{
    internal sealed class Math : FunctionalityBase
    {
        #region IDescribeMyFunctionality
        private static DescribeMyFunctionality<InputParamsBase> _info;
        /// <summary>
        ///     Functionality Info
        /// </summary>
        internal static DescribeMyFunctionality<InputParamsBase> Info
        {
            get
            {
                if (_info is null)
                {
                    #region Class Functionality Definitions and sample inputs
                    var description = @"This class provides math related functionalities";
                    var desc4Fibonacci = @"Each number is the sum of the two preceding ones, starting from 0 and 1. Fibonacci numbers are named after the Italian mathematician Leonardo of Pisa, later known as Fibonacci. In his 1202 book Liber Abaci, Fibonacci introduced the sequence to Western European mathematicians, although the sequence had been described earlier in Indian mathematics, as early as 200 BC";
                    var descPI = @"Calculates PI recursively using Newton / Euler Convergence Transformation";
                    var descPrimes = @"Calculates prime numbers for the given range";

                    FunctionalityInfo<InputParamsBase> funcFibonacci = new(nameof(FibNums), desc4Fibonacci,
                        new List<InputParams> { new() { Format = "txt    " + Constants.CommentIndicator + "   [txt|md|html]", UpTo = 50 } });
                    FunctionalityInfo<InputParamsBase> funcPi = new(nameof(PI), descPI,
                        new List<InputParamsPi> { new() { Format = "txt    " + Constants.CommentIndicator + "   [txt|md|html]", IterationTimes = 95 } });
                    FunctionalityInfo<InputParamsBase> funcPrimes = new(nameof(Primes), descPrimes,
                        new List<InputParamsPrimes> { new() { Format = "txt    " + Constants.CommentIndicator + "   [txt|md|html]", From = 2, To = 1000 } });

                    List<FunctionalityInfo<InputParamsBase>> functionalities = new()
                    {
                        funcFibonacci,
                        funcPi,
                        funcPrimes
                    };
                    #endregion
                    _info = new DescribeMyFunctionality<InputParamsBase>(description, functionalities, new DateTime(2021, 5, 31));
                }
                return _info;
            }
        }
        public class InputParams : InputParamsBase
        {
            public string Format { get; set; } // [txt | html]
            public int? UpTo { get; set; }
            public InputParams() { }
        }
        public class InputParamsPi : InputParamsBase
        {
            public string Format { get; set; } // [txt | html]
            public int IterationTimes { get; set; }
        }
        public class InputParamsPrimes : InputParamsBase
        {
            public string Format { get; set; } // [txt | html]
            public int From { get; set; }
            public int To { get; set; }
        }
        #endregion
        #region Implementations
        private Dictionary<int, ulong> cache;
        internal string FibNums(InputParams inputParams)
        {
            cache = new();

            StringBuilder sb = new("#\tFibonacci\tGoldenRatio\r\n");

            for (int i = 0; i < inputParams.UpTo.Value; i++)
            {
                ulong fib = Fib(i);
                ulong prev = Fib(i - 1);
                decimal ratio = 0;
                if (prev > 0)
                    ratio = fib / (decimal)prev;

                sb.AppendLine($"{i}\t{Fib(i)}\t{ratio}");
            }

            switch (inputParams.Format.Trim().ToLower())
            {
                case "md":
                    MarkDown2Html markDown = new MarkDown2Html();
                    var md = markDown.Data2MdTbl(new MarkDown2Html.InputParams() { TabDelimitedData = sb.ToString() });
                    return md;
                case "html":
                    HTML hTML = new HTML();
                    var htmlTbl = hTML.Data2HtmlTbl(new HTML.InputParams() { Data = sb.ToString() });
                    return htmlTbl;
                default: //  "txt":
                    return sb.ToString();
            }

        }

        internal IEnumerable<ulong> FibonacciNums(InputParams inputParams)
        {
            List<ulong> fibs = new();
            cache = new();
            for (int i = 0; i < inputParams.UpTo.Value; i++)
            {
                fibs.Add(Fib(i));
            }

            return fibs.AsEnumerable<ulong>();
        }


        internal string PI(InputParamsPi inputParams)
        {
            StringBuilder sb = new("iter#\tPi\r\n");

            for (int i = 1; i < inputParams.IterationTimes; i++)
            {
                decimal pi = 2 * Pi(1, i);
                sb.AppendLine($"{i}\t{pi}");
            }

            switch (inputParams.Format.Trim().ToLower())
            {
                case "md":
                    MarkDown2Html markDown = new MarkDown2Html();
                    var md = markDown.Data2MdTbl(new MarkDown2Html.InputParams() { TabDelimitedData = sb.ToString() });
                    return md;
                case "html":
                    HTML hTML = new HTML();
                    var htmlTbl = hTML.Data2HtmlTbl(new HTML.InputParams() { Data = sb.ToString() });
                    return htmlTbl;
                default: // "txt":
                    return sb.ToString();
            }

        }

        // PI = 2 * (1 + 1/3 * (1 + 2/5 * (1 + 3/7 * (...))))
        // Newton / Euler Convergence Transformation
        private decimal Pi(decimal max, int piMaxPrecision)
        {
            if (max >= piMaxPrecision)
                return 1;

            // return 1 + max / ((decimal)2.0 * max + 1) * Pi(max + 1);
            return 1 + max / (2m * max + 1) * Pi(max + 1, piMaxPrecision);
        }


        private ulong Fib(int upTo)
        {
            if (upTo <= 0)
                return 0;

            if (upTo == 1)
                return 1;

            if (cache.ContainsKey(upTo))
                return cache[upTo];

            cache.Add(upTo, Fib(upTo - 1) + Fib(upTo - 2));
            return cache[upTo];
        }


        internal string Primes(InputParamsPrimes inputParams)
        {
            StringBuilder sb = new($"Prime Numbers between {inputParams.From} and {inputParams.To}\r\n");

            var stopwatch = new System.Diagnostics.Stopwatch();
            stopwatch.Start();
            var numbers = Enumerable.Range(inputParams.From, inputParams.To - inputParams.From)
                                    .Where(IsPrime)
                                    .Select(number => number).ToList();
            stopwatch.Stop();

            sb.AppendLine(string.Join("\r\n", numbers));

            sb.AppendLine($"\r\n{numbers.Count()} prime numbers found in {stopwatch.Elapsed.TotalSeconds} seconds\r\n");

            switch (inputParams.Format.Trim().ToLower())
            {
                case "md":
                    MarkDown2Html markDown = new MarkDown2Html();
                    var md = markDown.Data2MdTbl(new MarkDown2Html.InputParams() { TabDelimitedData = sb.ToString() });
                    return md;
                case "html":
                    HTML hTML = new HTML();
                    var htmlTbl = hTML.Data2HtmlTbl(new HTML.InputParams() { Data = sb.ToString() });
                    return htmlTbl;
                default: // "txt":
                    return sb.ToString();
            }
        }

        bool IsPrime(int number)
        {
            if (number < 2)
                return false;

            // A simple but slow method of checking
            // the primality of a given number
            // n, called trial division, tests whether n is a multiple
            // of any integer between 2 and sqrt(n)
            var possibleFactors = System.Math.Sqrt(number);
            // we start with low factors (2,3,4,5,etc...)
            // this makes sure we short circuit as early
            // as possible during calculations
            for (var factor = 2; factor <= possibleFactors; factor++)
            {
                if (number % factor == 0)
                {
                    return false;
                }
            }

            // we've exhausted all factors
            // so we know this number is prime
            return true;
        }



        #endregion
    }
}
