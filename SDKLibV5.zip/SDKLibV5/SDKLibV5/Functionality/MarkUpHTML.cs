﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Web;

namespace SDKLibV5.Functionality
{
    /// <summary>
    ///     Provides HTML related functionalities
    /// </summary>
    public sealed class MarkUpHTML : FunctionalityBase
    {
        #region IDescribeMyFunctionality
        private static DescribeMyFunctionality<InputParamsBase> _info;

        /// <summary>
        ///     Functionality Info
        /// </summary>
        internal static DescribeMyFunctionality<InputParamsBase> Info
        {
            get
            {
                if (_info is null)
                {
                    #region Class Functionality Definitions and sample inputs
                    var desc4Class = @"This class provides an implementation for converting textual content to HTML";
                    var desc4HighlightCSharpCode = @"Applies language specific syntax highlighting to the given code -- C# only at this point. "
                                                    + "\r\nCssInclusionType: [Inline|Internal|External]";

                    FunctionalityInfo<InputParamsBase> funcSyntaxHighlight = new(nameof(SyntaxHighlight), desc4HighlightCSharpCode,
                        new List<InputParams> {
                            new InputParams{ Code=SDKLibV5.Constants.MultiLineIndicator + @"    /// <summary>
    /// Converts the given tab delimited data to HTML table
    /// </summary>
    /// <param name=""text"">Tab delimited data</param>
    /// <returns>HTML table</returns>
    public static string Data2Html(string text)
    {
        StringBuilder sbHTMLTbl = new StringBuilder();
        string[] lines = text.Split(new string[] { ""\r\n"", ""\n"", ""\r"" }, StringSplitOptions.RemoveEmptyEntries);
        string commandKey1 = "">First Column is column titles:"";
        bool firstLineIsTitles = false;
        for (int i = 0; i < lines.Length; i++)
        {
            string line = lines[i].Trim();
            if (!line.StartsWith(Constants.CommentChar))
            {
                if (line.StartsWith(commandKey1))
                {
                    var inputVal = ExtractStringValue(commandKey1, line);
                    bool.TryParse(inputVal, out firstLineIsTitles);
                    break;
                }
            } // if not a comment
        }

        sbHTMLTbl.Append(@""<table><caption></caption><tr>"");
        bool firstLineRead = false;
        for (int i = 0; i < lines.Length; i++)
        {
            string line = lines[i].Trim();
            if (!(line.StartsWith(Constants.CommentChar) || line.StartsWith(Constants.CommandChar)))
            {
                if (line.Trim().Length > 0)
                {
                    var colVals = line.Split('\t');
                    if (!firstLineRead)
                    {
                        firstLineRead = true;
                        if (firstLineIsTitles)
                        {
                            foreach (var val in colVals)
                                sbHTMLTbl.Append($""\t<th>{val}</th>"");
                            sbHTMLTbl.AppendLine(""</tr>"");
                        }
                    }
                    else
                    {
                        sbHTMLTbl.Append(""\t<tr>""); // adding row terminator
                        foreach (var val in colVals)  // iterate over columns
                            sbHTMLTbl.Append($""<td>{val}</td>"");
                        sbHTMLTbl.AppendLine(""</tr>"");
                    }
                }
            } // if not a comment
        }

        sbHTMLTbl.AppendLine(""</table>"");
        return sbHTMLTbl.ToString();
    }"
                }  });


                    List<FunctionalityInfo<InputParamsBase>> functionalities = new()
                    {
                        funcSyntaxHighlight
                    };
                    #endregion

                    _info = new DescribeMyFunctionality<InputParamsBase>(desc4Class, functionalities, new DateTime(2021, 5, 4));
                }
                return _info;
            }
        }

        internal class InputParams : InputParamsBase
        {
            public string CSharpCodeWithClasses { get; private set; }
            public string TargetLanguage { get; set; } = null;
            public string Code { get; set; } = null;
            public string Data { get; set; } = null;
            // public string CssInclusionType { get; set; } = null; // Inline | Internal | External(Not supported yet)

            public InputParams() { }
            public InputParams(string cSharpCode)
            {
                CSharpCodeWithClasses = cSharpCode;
            }
        }
        #endregion



        #region Implementation
        private sealed class Constants
        {
            internal const string CommentChar = "//";
            internal const string CommandChar = ">";


            internal static string[] langKeywords = {
                "abstract",
                "as",
                "base",
                "bool",
                "byte",
                "case",
                "catch",
                "char",
                "checked",
                "class",
                "const",
                "decimal",
                "default",
                "delegate",
                "do",
                "double",
                "enum",
                "event",
                "explicit",
                "extern",
                "false",
                "finally",
                "fixed",
                "float",
                "goto",
                "implicit",
                "int",
                "interface",
                "internal",
                "lock",
                "long",
                "namespace",
                "new",
                "null",
                "object",
                "operator",
                "out",
                "override",
                "params",
                "private",
                "protected",
                "public",
                "readonly",
                "ref",
                "sbyte",
                "sealed",
                "short",
                "sizeof",
                "stackalloc",
                "static",
                "string",
                "struct",
                "switch",
                "this",
                "throw",
                "true",
                "try",
                "typeof",
                "uint",
                "ulong",
                "unchecked",
                "unsafe",
                "ushort",
                "using",
                "value",
                "var",
                "virtual",
                "void",
                "volatile",
                "while",
            };

            internal static string[] langKeywords5 =
            {
                "if",
                "for",
                "foreach",
                "else",
                "in",
                "is",
                "return",
                "continue",
                "break",
            };

            internal static string[] langKeywords2 = {
                "ArgumentException",
                "StringBuilder",
                "Regex",
                "DateTime",
            };

            internal static string[] langKeywords3 = {
                "StringSplitOptions",
                "get",
                "set",
                "IEnumerable",
            };

            internal static string[] langKeywords4 = {
                ".StartsWith", ".TryParse", ".Append", ".AppendLine", ".Trim", ".Split", ".ToString", ".Substring", ".Replace", ".Matches", ".IsMatch", ".Match"
            };

            #region Inline Styles Variables
            internal static string style4ClassBlobNum = @"            width: 1%;
            min-width: 50px;
            padding-right: 10px;
            padding-left: 10px;
            font-family: SFMono-Regular,Consolas,Liberation Mono,Menlo,monospace;
            font-size: 14px;
            line-height: 20px;
            color: #6882b3;
            text-align: right;
            white-space: nowrap;
            vertical-align: top;
            cursor: pointer;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
";
            internal static string style4Table = @"            border-spacing: 0;
            border-collapse: collapse;
            table-layout: auto;
            width: 10px;";
            internal static string style4TdTh = @"padding: 0;";
            internal static string style4TrOdd = @"background-color: #152014;";
            internal static string style4TrEven = @"background-color: #07160b;";

            internal static string style4ClassBlobCodeInner = @"            overflow: visible;
            font-family: SFMono-Regular,Consolas,Liberation Mono,Menlo,monospace;
            font-size: 14px;
            color: #e0dada;
            word-wrap: normal;
            white-space: pre;";
            internal static string style4ClassBlobCode = @"            position: relative;
            padding-right: 10px;
            padding-left: 10px;
            line-height: 20px;
            vertical-align: top;";
            internal static string styleTxtColor_Comment = @"color: #237442;";
            internal static string styleTxtColor_Keyword = @"color: #1e90ff;";
            internal static string styleTxtColor_Keyword2 = @"color: #1ABC9C;";
            internal static string styleTxtColor_Keyword3 = @"color: #acbc1a;";
            internal static string styleTxtColor_Keyword4 = @"color: #dddc96;";
            internal static string styleTxtColor_Keyword5 = @"color: #a52d9f;";
            internal static string styleTxtColor_Literal = @"color: #FFA47C;";
            #endregion

            internal static string SyntaxHighlightStyleCSharp = @$"
        table {{
            {style4Table}
        }}
        td, th {{
            {style4TdTh}
        }}
        table tr:nth-child(odd) td {{
            {style4TrOdd}
        }}
        table tr:nth-child(even) td {{
            {style4TrEven}
        }}
        .blob-code-inner {{
            {style4ClassBlobCodeInner}
        }}
        .blob-code {{
            {style4ClassBlobCode}
        }}
        .blob-num {{
            {style4ClassBlobNum}
        }}
        .color-text-comment {{
            {styleTxtColor_Comment}
        }}
        .color-text-keyword {{
            {styleTxtColor_Keyword}
        }}
        .color-text-keyword2 {{
            {styleTxtColor_Keyword2}
        }}
        .color-text-keyword3 {{
            {styleTxtColor_Keyword3}
        }}
        .color-text-keyword4 {{
            {styleTxtColor_Keyword4}
        }}
        .color-text-keyword5 {{
            {styleTxtColor_Keyword5}
        }}
        .color-text-literal {{
            {styleTxtColor_Literal}
        }}";
        }

        internal string SyntaxHighlight(InputParams inParams)
        {
            StringBuilder sb = new();
            sb.AppendLine($"<!DOCTYPE html><html><head><meta http-equiv=\"Content-Type\" content=\"text/html;charset=UTF-8\">\r\n<title>Code</title>");
            sb.AppendLine($"<style>{Constants.SyntaxHighlightStyleCSharp}</style>");
            sb.AppendLine("</head><body style=\"background-color:#000b00;\">");

            sb.AppendLine(@"    <table><tbody>");
            sb.AppendLine(GetCodeInTable(inParams));
            sb.AppendLine(@"</tbody></table>");
            sb.AppendLine($"</body></html>");
            return sb.ToString();
        }

        private string GetCodeInTable(InputParams inParams)
        {
            var lines = inParams.Code.Split(new string[] { "\r\n" }, StringSplitOptions.None);
            StringBuilder sb = new();
            for (int i = 0; i < lines.Length; i++)
            {
                var line = HttpUtility.HtmlEncode(lines[i]);
                if (lines[i].Trim().StartsWith("//"))
                {
                    // internal style
                    string commentLine = HighlightComment(line, inParams, i);
                    sb.AppendLine(commentLine);
                }
                else if (line.Contains("@&quot;"))
                {
                    line = HighlightStringLiteralsMultiLine(lines, ref i, "@\"");
                    string highlightedCodeInTR = GetHighlightedCodeLine(line, i);
                    sb.AppendLine(highlightedCodeInTR);
                }
                else if (line.Contains("@$&quot;"))
                {
                    line = HighlightStringLiteralsMultiLine(lines, ref i, "@$\"");
                    string highlightedCodeInTR = GetHighlightedCodeLine(line, i);
                    sb.AppendLine(highlightedCodeInTR);
                }
                else
                {
                    line = HighlightStringLiterals(line);
                    line = HighlightKeyword(Constants.langKeywords, line, "color-text-keyword");
                    line = HighlightKeyword(Constants.langKeywords2, line, "color-text-keyword2");
                    line = HighlightKeyword(Constants.langKeywords3, line, "color-text-keyword3");
                    line = HighlightKeyword(Constants.langKeywords4, line, "color-text-keyword4");
                    line = HighlightKeyword(Constants.langKeywords5, line, "color-text-keyword5");
                    line = line.Replace("ZcZlZaZsZs", "class");
                    line = HighlightInlineComment(line);
                    string highlightedCodeInTR = GetHighlightedCodeLine(line, i);
                    sb.AppendLine(highlightedCodeInTR);
                }
            }

            return sb.ToString();
        }

        private string HighlightStringLiteralsMultiLine(string[] lines, ref int i, string strMark1)
        {
            StringBuilder sb = new();
            string line = lines[i];
            bool quoteCloseFound = false;

            int dx = line.IndexOf(strMark1);
            sb.Append(line.Substring(0, dx));
            sb.Append($"<span style=\"{Constants.styleTxtColor_Literal}\">");
            sb.Append(strMark1);
            StringBuilder sbContent = new();
            for (int j = dx + strMark1.Length; j < line.Length; j++)
            {
                sbContent.Append(line[j]);
                if (line[j] == '"')
                {
                    quoteCloseFound = true;
                    break;
                }
            }

            while (!quoteCloseFound)
            {
                line = lines[++i];
                sbContent.AppendLine("");
                for (int j = 0; j < line.Length; j++)
                {
                    sbContent.Append(line[j]);
                    if (line[j] == '"')
                    {
                        quoteCloseFound = true;
                        break;
                    }
                }
            }

            sb.Append(HttpUtility.HtmlEncode(sbContent.ToString()));
            sb.Append("</span>;");

            return sb.ToString(); // HttpUtility.HtmlEncode(sb.ToString());
        }

        private string GetHighlightedCodeLine(string line, int i)
        {
            var trCode = @$"             <tr>
                <td class=""blob-num"">{i + 1}</td>
                <td class=""blob-code blob-code-inner"">{line}</td>
            </tr>";

            //if (cssInclusionType == "Inline")
            //    trCode = @$"             <tr>
            //    <td style=""{Constants.style4ClassBlobNum}"">{i + 1}</td>
            //    <td style=""{Constants.style4ClassBlobCode}{Constants.style4ClassBlobCodeInner}"">{line}</td>
            //</tr>";

            return trCode;
        }

        private static string HighlightInlineComment(string line)
        {
            Regex regex3 = new Regex("//.*$");
            if (regex3.IsMatch(line))
            {
                var match = regex3.Match(line);
                line = regex3.Replace(line, $"<span class=\"color-text-comment\">{match.Value}</span>");
                //if (inParams.CssInclusionType == "Inline")
                //    line = regex3.Replace(line, $"<span style=\"{Constants.styleTxtColor_Comment}\">{match.Value}</span>");
            }

            return line;
        }

        private static string HighlightStringLiterals(string line)
        {
            Regex regex2 = new Regex("&quot;.+&quot;");
            if (regex2.IsMatch(line))
            {
                foreach (Match match in regex2.Matches(line))
                {
                    // if (cssInclusionType == "Internal")
                        line = regex2.Replace(line, $"<span ZcZlZaZsZs=\"color-text-literal\">{match.Value}</span>");
                    // else if (cssInclusionType == "Inline")
                       //  line = regex2.Replace(line, $"<span style=\"{Constants.styleTxtColor_Literal}\">{match.Value}</span>");
                }
            }

            return line;
        }

        private string HighlightComment(string line, InputParams inParams, int i)
        {
            var commentLine = @$"            <tr>
                <td class=""blob-num"">{i + 1}</td>
                <td class=""blob-code blob-code-inner""><span class=""color-text-comment"">{line}</span></td>
            </tr>";

            //if (inParams.CssInclusionType == "Inline")
            //    commentLine = @$"            <tr>
            //    <td style=""blob-num{Constants.style4ClassBlobNum.NoCRLF()}"">{i + 1}</td>
            //    <td style=""{Constants.style4ClassBlobCode.NoCRLF()}{Constants.style4ClassBlobCodeInner.NoCRLF()}""><span style=""{Constants.styleTxtColor_Comment.NoCRLF()}"">{line}</span></td>
            //</tr>";

            return commentLine;
        }

        private string HighlightKeyword(string[] langKeywords, string line, string styleClassName)
        {
            var inlineComment = line.Split(new string[] { "//" }, StringSplitOptions.None);

            var comment = "";
            if (inlineComment.Length > 1)
            {
                comment = line.Substring(line.IndexOf("//"));
                line = inlineComment[0];
            }

            foreach (var keywd in langKeywords)
            {
                Regex regex = new Regex($"\\b{keywd}\\b");
                if (regex.IsMatch(line))
                {
                    var match = regex.Match(line);
                    if (!IsMatchInStringLiteral(match, line))
                    {
                        if (keywd == "class" && line.Substring(match.Index + match.Length, 1) == "=")
                            continue;
                        //if (cssInclusionType == "Inline")
                        //    line = regex.Replace(line, $"<span style=\"{MapStyleClassToCss(styleClassName)}\">{keywd}</span>");
                        else
                            line = regex.Replace(line, $"<span class=\"{styleClassName}\">{keywd}</span>");
                    }
                }
            }

            return line + comment;
        }

        private string MapStyleClassToCss(string styleClassName)
        {
            return styleClassName switch
            {
                "color-text-keyword" => Constants.styleTxtColor_Keyword,
                "color-text-keyword2" => Constants.styleTxtColor_Keyword2,
                "color-text-keyword3" => Constants.styleTxtColor_Keyword3,
                "color-text-keyword4" => Constants.styleTxtColor_Keyword4,
                "color-text-keyword5" => Constants.styleTxtColor_Keyword5,
                _ => styleClassName,
            };
        }

        private bool IsMatchInStringLiteral(Match match, string line)
        {
            // &apos;  --- TODO: to be done when needed
            Regex regex = new Regex(@"(&quot;)(?:(?=(\\?))\2.)*?\1");

            foreach (Match quoteMatch in regex.Matches(line))
            {
                if (match.Index >= quoteMatch.Index && match.Index < quoteMatch.Index + quoteMatch.Length)
                    return true;
            }

            return false;
        }



        /// <summary>
        /// Converts the given tab delimited data to HTML table
        /// </summary>
        /// <param name="text">Tab delimited data</param>
        /// <returns>HTML table</returns>
        public static string Data2Html(string text)
        {
            StringBuilder sbHTMLTbl = new StringBuilder();
            string[] lines = text.Split(new string[] { "\r\n", "\n", "\r" }, StringSplitOptions.RemoveEmptyEntries);
            string commandKey1 = ">First Column is column titles:";
            bool firstLineIsTitles = false;

            for (int i = 0; i < lines.Length; i++)
            {
                string line = lines[i].Trim();
                if (!line.StartsWith(Constants.CommentChar))
                {
                    if (line.StartsWith(commandKey1))
                    {
                        var inputVal = ExtractStringValue(commandKey1, line);
                        bool.TryParse(inputVal, out firstLineIsTitles);
                        break;
                    }
                } // if not a comment
            }

            sbHTMLTbl.Append(@"<table>
<caption></caption>
    <tr>");

            bool firstLineRead = false;
            for (int i = 0; i < lines.Length; i++)
            {
                string line = lines[i].Trim();
                if (!(line.StartsWith(Constants.CommentChar) || line.StartsWith(Constants.CommandChar)))
                {
                    if (line.Trim().Length > 0)
                    {
                        var colVals = line.Split('\t');
                        if (!firstLineRead)
                        {
                            firstLineRead = true;
                            if (firstLineIsTitles)
                            {

                                foreach (var val in colVals)
                                    sbHTMLTbl.Append($"\t<th>{val}</th>");
                                sbHTMLTbl.AppendLine("</tr>");
                            }
                        }
                        else
                        {
                            sbHTMLTbl.Append("\t<tr>");
                            foreach (var val in colVals)
                                sbHTMLTbl.Append($"<td>{val}</td>");
                            sbHTMLTbl.AppendLine("</tr>");
                        }
                    }
                } // if not a comment
            }

            sbHTMLTbl.AppendLine("</table>");
            return sbHTMLTbl.ToString();
        }

        /// <summary>
        /// TODO mode into a more relevant class?
        /// </summary>
        /// <param name="keyWord"></param>
        /// <param name="inputString"></param>
        /// <returns></returns>
        public static string ExtractStringValue(string keyWord, string inputString)
        {
            var extractedValue = inputString.Substring(inputString.IndexOf(keyWord) + keyWord.Length);
            if (extractedValue.Contains(Constants.CommentChar))
            {
                extractedValue = extractedValue.Substring(0, extractedValue.IndexOf(Constants.CommentChar));
            }

            return extractedValue.Trim();
        }


        public static string Class2HtmlTables(string text)
        {
            StringBuilder sbInputCode = new StringBuilder();
            string[] origLines = text.Split(new string[] { "\r\n", "\n", "\r" }, StringSplitOptions.RemoveEmptyEntries);

            string commandKey1 = ">First Column is column titles:";
            bool firstLineIsTitles = false;

            for (int i = 0; i < origLines.Length; i++)
            {
                string line = origLines[i].Trim();

                if (!line.StartsWith("#") && !line.StartsWith(Constants.CommentChar) && !line.StartsWith(Constants.CommandChar) && line.Length > 0)
                {
                    sbInputCode.AppendLine(line);
                } // if not a comment
            }

            // TODO: implement comment removal logic
            string inCode = sbInputCode.ToString();
            inCode = Regex.Replace(inCode, @"/\*.*[\r\n]*\$*/", "//---------------------", RegexOptions.Multiline);

            List<ClassDef> classes = new List<ClassDef>();

            string[] lines = inCode.Split(new string[] { "\r", "\n" }, StringSplitOptions.RemoveEmptyEntries);

            for (int i = 0; i < lines.Length; i++)
            {
                string line = lines[i];
                bool flagClsStart = false;
                string currClassName;
                ClassDef clsDef = null;

                if (line.Trim().StartsWith("//"))
                    continue;

                if (Regex.IsMatch(line, @"class\s+", RegexOptions.Singleline))
                {
                    flagClsStart = true;
                    currClassName = line.Split(new string[] { "class" }, StringSplitOptions.RemoveEmptyEntries)[1].Trim();

                    clsDef = new ClassDef()
                    {
                        Name = currClassName
                    };
                }

                while (lines[++i] != "}")
                {
                    line = lines[i];
                    if (line == "{" || line.Trim().StartsWith("//"))
                        continue;

                    line = line.Split(new string[] { "{", "=>" }, StringSplitOptions.RemoveEmptyEntries)[0].Trim();
                    string[] propertyInfo = line.Split(new char[] { ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries);

                    if (propertyInfo.Length == 3)
                    {
                        clsDef.Properties.Add(new PropertyDef(propertyInfo[0], propertyInfo[1], propertyInfo[2]));
                    }
                    else if (propertyInfo.Length == 2)
                    {
                        clsDef.Properties.Add(new PropertyDef(propertyInfo[0], propertyInfo[1]));
                    }
                }

                if (clsDef != null)
                    classes.Add(clsDef);
            }

            string topTemplate = "";
            StringBuilder sbOut = new StringBuilder();

            topTemplate = FileSys.GetFileContent("Resources\\HTMLDocHeadTemplate.txt");

            sbOut.AppendLine(topTemplate + $"<body>\r\n<!-- Generated on {DateTime.Now} -->");

            foreach (var cls in classes)
                sbOut.AppendLine(cls.ToHTMLTable(true));

            sbOut.AppendLine("</body>\r\n</html>\r\n");

            // txtOutput.Text = sbOut.ToString();


            return topTemplate + $"<body>\r\n<!-- Generated on {DateTime.Now} -->" +

                ToLinkedHTMLTables(classes)
                +
            "</body>\r\n</html>\r\n";
        }


        private static string ToHTMLTable(ClassDef clsDef, Dictionary<string, ClassDef> allClasses, bool includeTableCaption = false)
        {
            if (!clsDef.HasComplexTypes)
                return clsDef.ToHTMLTable();

            StringBuilder sb = new StringBuilder();

            string tableCaption = string.Empty;

            if (includeTableCaption)
                tableCaption = clsDef.Name;

            sb.AppendLine(@"    <table>
        <caption>" + tableCaption + @"</caption>
        <tr>	<th>Property Name</th><th>Type</th></tr>");

            //foreach (var prop in Properties)
            //    sb.AppendLine("\t<tr><td>" + prop.AccessModifier + "</td><td>" + prop.DataType + "</td><td>" + prop.Name + "</td></tr>");


            foreach (var prop in clsDef.Properties)
            {
                sb.Append("\t<tr><td>" + prop.Name + "</td><td>" + prop.DataType);

                if (!Primitives.Any(x => x == prop.DataType.ToLower().Replace("[]", "")))
                {

                    var typeName = prop.DataType.Replace("[]", "")
                        .Replace("List<", "")
                        .Replace(">", "")
                        .Replace("Dictionary<", "");

                    sb.AppendLine(ToHTMLTable(allClasses[typeName], allClasses));
                }

                sb.AppendLine("\t</td></tr>");
            }


            sb.AppendLine("</table>");

            return Environment.NewLine + sb.ToString();
        }

        private static string ToLinkedHTMLTables(List<ClassDef> classes)
        {
            Dictionary<string, ClassDef> clss = new Dictionary<string, ClassDef>();

            foreach (var cls in classes)
            {
                string clsName = cls.Name;
                if (clsName.Contains(":"))
                    clsName = clsName.Split(':')[0].Trim();
                clss.Add(clsName, cls);
            }

            StringBuilder sb = new StringBuilder();

            // foreach (var cls in classes)
            return Environment.NewLine +
                ToHTMLTable(classes[0], clss, true)
                + Environment.NewLine;

            // return sb.ToString();
        }



        private static string[] Primitives = { "byte","sbyte","int","uint","short","ushort","long","ulong","float","double","char","bool","object","string","decimal","datetime",
                                                "Byte","SByte","Int32","UInt32","Int16","UInt16","Int64","UInt64","Single","Double","Char","Boolean","Object","String","Decimal","DateTime"};

        private class ClassDef
        {
            public ClassDef()
            {
                Properties = new List<PropertyDef>();
            }

            public string Name { get; set; }
            public string AccessModifier { get; set; } // public, protected, internal, private, protected internal, private protected
            public List<PropertyDef> Properties { get; set; }

            public bool HasComplexTypes
            {
                get
                {
                    foreach (var prop in Properties)
                        if (Primitives.Any(x => x != prop.DataType))
                            return true;

                    return false;
                }
            }

            public override string ToString()
            {
                StringBuilder sb = new StringBuilder();

                foreach (var prop in Properties)
                    sb.AppendLine("\t" + prop.AccessModifier + " " + prop.DataType + " " + prop.Name);

                return Name + Environment.NewLine + sb.ToString();
            }

            public string ToHTMLTable(bool includeTableCaption = false)
            {
                StringBuilder sb = new StringBuilder();

                string tableCaption = string.Empty;

                if (includeTableCaption)
                    tableCaption = Name;

                sb.AppendLine(@"    <table>
        <caption>" + tableCaption + @"</caption>
        <tr>	<th>Property Name</th><th>Type</th></tr>");

                //foreach (var prop in Properties)
                //    sb.AppendLine("\t<tr><td>" + prop.AccessModifier + "</td><td>" + prop.DataType + "</td><td>" + prop.Name + "</td></tr>");

                foreach (var prop in Properties)
                    sb.AppendLine("\t<tr><td>" + prop.Name + "</td><td>" + prop.DataType + "</td></tr>");

                sb.AppendLine("</table>");

                return Environment.NewLine + sb.ToString();
            }
        }

        private class PropertyDef
        {
            public string Name { get; set; }
            public string DataType { get; set; } // public, internal, private 
            public string AccessModifier { get; set; }

            public PropertyDef(string accessmodifier, string datatype, string name)
            {
                Name = name.Trim();
                DataType = datatype.Trim();
                AccessModifier = accessmodifier.Trim();
            }

            public PropertyDef(string datatype, string name)
            {
                Name = name;
                DataType = datatype;
            }
        }

        #endregion
    }
}
