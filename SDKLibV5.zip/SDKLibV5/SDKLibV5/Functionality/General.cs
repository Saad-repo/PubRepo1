﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace SDKLibV5.Functionality
{
    public sealed class General : FunctionalityBase
    {
        #region IDescribeMyFunctionality
        private static DescribeMyFunctionality<InputParamsBase> _info;

        /// <summary>
        ///     Functionality Info
        /// </summary>
        internal static DescribeMyFunctionality<InputParamsBase> Info
        {
            get
            {
                if (_info is null)
                {
                    #region Class Functionality Definitions and sample inputs
                    var description = @"This class provides generic functionality";
                    var desc4Convert2Html = @"Displays documentation for all the functionality provided across implementation classes; gallery";
                    var desc4SearchFunctionality = @"Searches functionality documentation for the given keyword and returns matching Tabs and Button names";

                    FunctionalityInfo<InputParamsBase> funcCatalog = new(nameof(ShowFunctionalityCatalog), desc4Convert2Html,
                            new List<InputParams> { new InputParams() });
                    FunctionalityInfo<InputParamsBase> funcSearch = new(nameof(SearchCatalog), desc4SearchFunctionality,
                            new List<InputParams> { new InputParams { SearchKeyword = "Convert" } });

                    List<FunctionalityInfo<InputParamsBase>> functionalities = new()
                    {
                        funcCatalog,
                        funcSearch,
                    };
                    #endregion

                    _info = new DescribeMyFunctionality<InputParamsBase>(description, functionalities, new DateTime(2021, 5, 2));
                }
                return _info;
            }
        }

        internal class InputParams : InputParamsBase
        {
            public string OwnerClassName { get; set; }
            public string SearchKeyword { get; set; }

            public InputParams() { }
        }
        #endregion

        #region Implementation
        public General() { }

        private sealed class Constants
        {
        }


        internal string ShowFunctionalityCatalog(InputParams inputParams)
        {
            StringBuilder sb = new();
            var functionlityTypes = DescribeMyFunctionality<InputParamsBase>.GetAllFunctionalityTypes();

            foreach (var funcType in functionlityTypes)
            {
                var infoPropInfo = funcType.GetRuntimeProperties().Where(p => p.Name == "Info").First();

                var staticInfoObj = infoPropInfo.GetValue(null); // type: DescribeMyFunctionality<InputParams>
                var inputParamsParamsType = infoPropInfo.PropertyType.GenericTypeArguments[0]; // InputParams
                var genericBase = typeof(DescribeMyFunctionality<>);
                Type funcInputParamsType = genericBase.MakeGenericType(inputParamsParamsType);
                var funcInputParamsInstance = Activator.CreateInstance(funcInputParamsType); // type: DescribeMyFunctionality<InputParams>


                var describeAllMethod = funcInputParamsInstance.GetType().GetRuntimeMethods().First(p => p.Name == "DescribeAll");
                var describeAll = describeAllMethod.Invoke(staticInfoObj, new object[] { funcType.Name }).ToString();
                sb.AppendLine(describeAll);
            }

            return sb.ToString();
        }

        internal string SearchCatalog(InputParams inputParams)
        {
            StringBuilder sb = new();
            var assemblySDKLib = Assembly.Load(SDKLibV5.Constants.AssemblyName);
            var functionlityTypes = assemblySDKLib.GetTypes()
                                                  .Where(t => t.FullName.StartsWith("SDKLibV5.Functionality")
                                                           && t.BaseType == typeof(FunctionalityBase))
                                                  .ToList();

            foreach (var funcType in functionlityTypes)
            {
                var infoPropInfo = funcType.GetRuntimeProperties().Where(p => p.Name == "Info").First();

                var staticInfoObj = infoPropInfo.GetValue(null); // type: DescribeMyFunctionality<InputParams>
                var inputParamsParamsType = infoPropInfo.PropertyType.GenericTypeArguments[0]; // InputParams
                var genericBase = typeof(DescribeMyFunctionality<>);
                Type funcInputParamsType = genericBase.MakeGenericType(inputParamsParamsType);
                var funcInputParamsInstance = Activator.CreateInstance(funcInputParamsType); // type: DescribeMyFunctionality<InputParams>

                var describeAllMethod = funcInputParamsInstance.GetType().GetRuntimeMethods().First(p => p.Name == "DescribeAll");
                var describeAll = describeAllMethod.Invoke(staticInfoObj, new object[] { funcType.Name }).ToString();

                var functionalitiesProp = funcInputParamsInstance.GetType().GetRuntimeProperties().First(p => p.Name == "Functionalities");
                var functionalitiesPropValue = (List<FunctionalityInfo<InputParamsBase>>)functionalitiesProp.GetValue(staticInfoObj);

                foreach (var functionalityObj in functionalitiesPropValue)
                {
                    var func = (FunctionalityInfo<InputParamsBase>)functionalityObj;
                    var lowerDesc = func.Description.ToLower();
                    var lowerName = func.Name.ToLower();
                    var lowerKeywd = inputParams.SearchKeyword.ToLower();

                    if (lowerDesc.Contains(lowerKeywd)
                        || lowerName.Contains(lowerKeywd))
                        sb.AppendLine($"{funcType.Name}.{func.Name}\r\n--------------------------\r\n\t{func.Description.Cr2Br()}\r\n");
                }
            }

            Functionality.MarkDown2Html markDown2Html = new MarkDown2Html();
            var html = markDown2Html.Md2Html(new MarkDown2Html.InputParams { MdContent = sb.ToString() });

            return html;
        }


        #endregion
    }
}
