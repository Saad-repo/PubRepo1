﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

[assembly: InternalsVisibleTo("ConsoleApp1")]
[assembly: InternalsVisibleTo("SDKLibV5_Tests")]
[assembly: InternalsVisibleTo("WpfApp1")]
[assembly: InternalsVisibleTo("SDKWebApi")]

namespace SDKLibV5
{
    public sealed class Constants
    {
        public const string MultiLineIndicator = "<<multi-line~entry>>";
        public const string CommentIndicator = "//##//";

        public const string VendorCompany = "SDK";
        public const string AssemblyName = "SDKLibV5";

        public static string GetEmbeddedResource(string resourceName)
        {
            var assembly = Assembly.GetExecutingAssembly();

            using Stream stream = assembly.GetManifestResourceStream(resourceName);
            using StreamReader reader = new StreamReader(stream);
            return reader.ReadToEnd();
        }
    }
}
