﻿using SDKLibV5.Functionality;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SDKLibV5
{
    /// <summary>
    /// Provides extension methods for frequently used functionalities
    /// </summary>
    internal static class CommonExtensionMethods
    {
        internal static string NoCRLF(this string input)
        {
            return input.Replace("\r\n", "");
        }

        /// <summary>
        /// Replaces the CR+LFs in the given input with <br/> for HTML Content
        /// </summary>
        /// <param name="input">Text that might contains CR+LF</param>
        /// <returns>Content with BR tags in place of CR+LF</returns>
        internal static string Cr2Br(this string input)
        {
            return input.Replace("\r\n", "<br/>");
        }

        internal static string[] ToLines(this string input)
            => input.Split(new string[] { "\r\n", "\r", "\n" }, StringSplitOptions.RemoveEmptyEntries);

        internal static string[] ToColumns(this string input)
            => input.Split(new string[] { "\t" }, StringSplitOptions.RemoveEmptyEntries);

        internal static string PascalCase(this string input)
        {
            StringBuilder sb = new();

            for (int i = 0; i < input.Length; i++)
            {
                if (i == 0)
                    sb.Append(Char.ToUpper(input[i]));
                else if (input[i] == '_' || input[i] == '.')
                {
                    while (input[i] == '_' || input[i] == '.')
                        i++;
                    sb.Append(Char.ToUpper(input[i]));
                }
                else
                    sb.Append(Char.ToLower(input[i]));
            }

            return sb.ToString();
        }

        /// <summary>
        /// Converts StudentRecordsMax to student_record_max
        /// </summary>
        /// <param name="input">StudentRecordsMax</param>
        /// <returns>student_record_max</returns>
        internal static string ToLowerWithUnderscore(this string input)
        {
            StringBuilder sb = new();
            for (int i = 0; i < input.Length; i++)
            {
                if (i == 0)
                    sb.Append(Char.ToLower(input[i]));
                else if (Char.IsUpper(input[i]))
                {
                    sb.Append("_" + Char.ToLower(input[i]));
                }
                else
                    sb.Append(Char.ToLower(input[i]));
            }

            return sb.ToString();
        }

        internal static string Pad2Center(this string content, int width, char chr)
        {
            content = content.Trim();
            int len = content.Length;
            if (len > width)
            {
                return content;
            }

            StringBuilder sb = new();
            double left = (width - len) / 2.0;
            double ll = System.Math.Floor(left) + 1;
            double rr = System.Math.Ceiling(left) + 1;
            for (int i = 0; i < ll; i++)
            {
                sb.Append(chr);
            }

            sb.Append(content);
            for (int i = 0; i < rr; i++)
            {
                sb.Append(chr);
            }

            return sb.ToString();
        }

        /// <summary>
        ///     Puts the given partial HTML into a basic HTML template
        /// </summary>
        /// <param name="content">The partial HTML content to be included in HTML page</param>
        /// <param name="javaScript">JavaScript to be included in the page</param>
        /// <param name="style">CSS Style to be included in the page</param>
        /// <returns>Content with given style and script in a simple HTML page</returns>
        internal static string WrapInHTML(this string content, string style = null, string javaScript = null)
        {
            StringBuilder sb = new();
            sb.AppendLine($"<!DOCTYPE html><html><head><meta http-equiv=\"Content-Type\" content=\"text/html;charset=UTF-8\">\r\n<title>Code</title>");
            sb.AppendLine($"<style>{style}</style>");
            sb.AppendLine("</head><body>");

            sb.AppendLine(content);

            sb.AppendLine($"<script>{javaScript}</script>");
            sb.AppendLine($"</body></html>");
            return sb.ToString();
        }

        internal static string Md2Html(this  string content)
        {
            MarkDown2Html markDown2Html = new();
            var html = markDown2Html.Md2Html(new MarkDown2Html.InputParams() { MdContent = content });
            return html;
        }
    }
}
