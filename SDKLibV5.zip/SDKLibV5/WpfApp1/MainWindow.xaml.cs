﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.Win32;
using SDKLibV5;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        int parDx = 0;

        private void txtInput_PreviewMouseWheel(object sender, MouseWheelEventArgs e)
        {
            ChangeFontSizeWithOfTextBox((TextBox)sender, e);
        }

        private void ChangeFontSizeWithOfTextBox(TextBox txt, MouseWheelEventArgs e)
        {
            if (Keyboard.Modifiers != ModifierKeys.Control)
            {
                return;
            }

            e.Handled = true;
            if (e.Delta > 0)
            {
                ++txt.FontSize;
            }
            else
            {
                --txt.FontSize;
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            LoadCommandButtons();
            txtFilterCommands.Focus();
            LoadLastSessionState();
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            SaveSessionState();
        }

        private void LoadLastSessionState()
        {
            var appName = Assembly.GetExecutingAssembly().GetName().Name;
            RegistryKey key = Registry.CurrentUser.OpenSubKey(@"SOFTWARE\"
                + Constants.VendorCompany + "\\" + appName);

            if (key != null)
            {
                var lastOpenTab = key.GetValue("LastTabName");
                if (lastOpenTab != null)
                {
                    var ctx = (ViewModel1)tabCtrlCommands.DataContext;
                    var selItmDx = ctx.Tabs.IndexOf(ctx.Tabs.First(t => t.Header == lastOpenTab.ToString()));
                    tabCtrlCommands.SelectedIndex = selItmDx;
                }
                txtInput.Text = $"{key.GetValue("LastCmdParams")}";
            }
        }

        private void SaveSessionState()
        {
            string userRoot = "Software";
            var appName = Assembly.GetExecutingAssembly().GetName().Name;
            string subkey = Constants.VendorCompany + "\\" + appName;
            string keyName = userRoot + "\\" + subkey;

            using RegistryKey key3 = Registry.CurrentUser.CreateSubKey(keyName);
            var tabItemRepresenter = tabCtrlCommands.SelectedItem as TabItemRepresenter;
            key3.SetValue("LastTabName", tabItemRepresenter.Header);
            key3.SetValue("LastCmdParams", txtInput.Text);
            key3.Close();
        }

        private void LoadCommandButtons(string filter = null)
        {
            tabCtrlCommands.DataContext = new ViewModel1(filter);
            tabCtrlCommands.Items.Refresh();
            tabCtrlCommands.SelectedIndex = 1;
            tabCtrlCommands.SelectedIndex = 0;
        }

        private void Button_PreviewMouseRightButtonUp(object sender, MouseButtonEventArgs e)
        {
            var btn = sender as Button;
            btn.Background = new SolidColorBrush(Colors.LightGreen);
            var preDefinedParams = (IEnumerable<InputParamsBase>)btn.Tag;
            var nextParam = preDefinedParams.ElementAt(parDx++ % preDefinedParams.Count());
            var selTab = (TabItemRepresenter)tabCtrlCommands.SelectedItem;
            txtInput.Text =
                            $">> Command: {selTab.ImplementationType.Name}.{btn.Content.ToString().ToUpper()}\r\n\r\n"
                            + nextParam.ToString();
            txtInput.Focus();
        }

        private async void Button_Click(object sender, RoutedEventArgs e)
        {
            var btn = (Button)sender;
            var btnRep = (ButtonRepresenter)btn.DataContext;
            // TabItem's header contains a TextBlock -- the Tag of which is the Type of implementing class
            var selTab = (TabItemRepresenter)tabCtrlCommands.SelectedItem;
            if (!txtInput.Text.StartsWith($">> Command: {selTab.ImplementationType.Name}."))
            {
                MessageBox.Show("Wrong input parameters. Right click the command button for valid sample input parameters");
                return;
            }

            try
            {
                var preDefinedParams = (IEnumerable<InputParamsBase>)btn.Tag;
                var implementationObj = (FunctionalityBase)Activator.CreateInstance(selTab.ImplementationType);
                var getSampleInputsMethod = implementationObj.GetType().GetRuntimeMethods().First(p => p.Name == btnRep.Name);
                // var inParams = InputParamsBase.FromString(txtInput.Text, selTab.Params.ElementAt((parDx + 1) % selTab.Params.Count()));
                var inParams = InputParamsBase.FromString(txtInput.Text, preDefinedParams.ElementAt((parDx + 1) % preDefinedParams.Count()));
                txtOutput.Text = getSampleInputsMethod.Invoke(implementationObj, new object[] { inParams }).ToString();
            }
            catch (Exception ex)
            {
                txtOutput.Text = GetErrorDetails(ex, btnRep.Name);
            }
            // CommonActionAfterButtonClick((Button)sender);
            // txtOutput.Text = FileSystemOps.GetJsonTextTokenInfo(txtInput.Text);

            await OpenAppropriateResultsTabAsync();
        }

        private async Task OpenAppropriateResultsTabAsync()
        {
            tabCtrlOutput.SelectedIndex = 0;
            if (txtOutput.Text.StartsWith("<!DOCTYPE html>"))
            {
                tabCtrlOutput.SelectedIndex = 1;
                await webBrowser.EnsureCoreWebView2Async();
                webBrowser.NavigateToString(txtOutput.Text);
                //webBrowser.Navigate("file:///C:/SDK/temp/test2.html");
            }
        }

        private static string GetErrorDetails(Exception ex, string commandBtnName = null)
        {
            var msg = @$"Error: {ex.Message}
Stack: {ex.StackTrace}";

            if (commandBtnName != null)
                msg = $"Error occurred when running {commandBtnName}. \r\nImplementation class must have the {commandBtnName} method. " + Environment.NewLine
                       + @$"Details:{ex.Message}
Stack: {ex.StackTrace}";

            if (ex.InnerException != null)
                return msg + "\r\n\tInner Error:\r\n" + GetErrorDetails(ex.InnerException);

            return msg;
        }

        private void btnCopyOutput2Clipboard_Click(object sender, RoutedEventArgs e)
        {
            Clipboard.SetText(txtOutput.Text);
        }

        private void chkWordWrap_Checked(object sender, RoutedEventArgs e)
        {
            if (txtOutput.TextWrapping == TextWrapping.NoWrap)
                txtOutput.TextWrapping = TextWrapping.Wrap;
            else
                txtOutput.TextWrapping = TextWrapping.NoWrap;
        }

        private void chkWordWrap_Unchecked(object sender, RoutedEventArgs e)
        {
            chkWordWrap_Checked(sender, e);
        }

        private void txtFilterCommands_TextChanged(object sender, TextChangedEventArgs e)
        {
            LoadCommandButtons(txtFilterCommands.Text);
        }

        private void btnOpenInChrome_Click(object sender, RoutedEventArgs e)
        {
            var tempFile = System.IO.Path.GetTempFileName() + ".html";
            using (System.IO.StreamWriter sw = new System.IO.StreamWriter(tempFile))
            {
                sw.WriteLine(txtOutput.Text);
            }

            var browserExe = @"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe";
            Process.Start(browserExe, tempFile);
        }

        private void btnSaveInputParam_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("The values in the input-textbox get persisted into the params collection of the current command for later use", "Implementation pending");
        }
    }



    public sealed class ButtonTagData
    {
        public Type ParamType { get; set; }
        public string InputParamStr { get; set; }
        public string ExecuteMethod { get; set; }
    }

    public sealed class ViewModel1
    {
        public ObservableCollection<TabItemRepresenter> Tabs { get; set; }

        public ViewModel1(string filter = null)
        {
            Tabs = new ObservableCollection<TabItemRepresenter>();
            List<Type> functionlityTypes = DescribeMyFunctionality<InputParamsBase>.GetAllFunctionalityTypes();

            foreach (var funcType in functionlityTypes)
            {
                var infoPropInfo = funcType.GetRuntimeProperties().Where(p => p.Name == "Info").First();

                var staticInfoObj = infoPropInfo.GetValue(null); // type: DescribeMyFunctionality<InputParams>
                var inputParamsParamsType = infoPropInfo.PropertyType.GenericTypeArguments[0]; // InputParams
                var genericBase = typeof(DescribeMyFunctionality<>);
                Type funcInputParamsType = genericBase.MakeGenericType(inputParamsParamsType);
                var funcInputParamsInstance = Activator.CreateInstance(funcInputParamsType); // type: DescribeMyFunctionality<InputParams>

                //var describeAllProperty = funcInputParamsInstance.GetType().GetRuntimeProperties().First(p => p.Name == "DescribeAll");
                //var describeAll = describeAllProperty.GetValue(staticInfoObj).ToString();
                var funcsProperty = funcInputParamsInstance.GetType().GetRuntimeProperties().First(p => p.Name == "Functionalities");
                var funcsValue = (IEnumerable<FunctionalityInfo<InputParamsBase>>)funcsProperty.GetValue(staticInfoObj);

                var funcNamesProperty = funcInputParamsInstance.GetType().GetRuntimeProperties().First(p => p.Name == "FunctionalyNames");
                var funcNamesValue = (IEnumerable<string>)funcNamesProperty.GetValue(staticInfoObj); // as List<FunctionalityParamsBase>;

                var ti = new TabItemRepresenter
                {
                    Header = funcType.Name,
                    ImplementationType = funcType,
                    Buttons = new List<ButtonRepresenter>()
                };

                Tabs.Add(ti);

                var oneOrMoreFilterButtonsMatch = false;
                foreach (var funcName in funcNamesValue)
                {
                    var getSampleInputMethods = funcInputParamsInstance.GetType().GetRuntimeMethods().First(p => p.Name == "GetSampleInputs");
                    ti.Params = (IEnumerable<InputParamsBase>)getSampleInputMethods.Invoke(staticInfoObj, new object[] { funcName });
                    var inParInstance = (IEnumerable<InputParamsBase>)Activator.CreateInstance(ti.Params.GetType());
                    // var inputParamsPopulatedObj = InputParamsBase.FromString(ti.Params.ToString(), inParInstance);

                    var funcTitle = $">> Command: {funcType.Name}.{funcName.ToUpper()}\r\n\r\n";
                    // funcsValue.First(f=>f.)
                    var toolTip = funcsValue.First(f => f.Name == funcName).Description;
                    var buttonRepresenter = new ButtonRepresenter(funcName, ti.Params, toolTip);

                    if (string.IsNullOrEmpty(filter))
                    {
                        ti.Buttons.Add(buttonRepresenter);
                    }
                    else if (toolTip.ToLower().Contains(filter.ToLower())
                        || funcName.ToLower().Contains(filter.ToLower()))
                    {
                        oneOrMoreFilterButtonsMatch = true;
                        ti.Buttons.Add(buttonRepresenter);
                    }
                }

                if (!string.IsNullOrEmpty(filter)
                    && !oneOrMoreFilterButtonsMatch)
                {
                    Tabs.Remove(ti);
                }
            }

            /*
            var excludedMethod = new string[]
            {
                "GetType",
                "ToString",
                "Equals",
                "GetHashCode"
            };

            foreach (var funcType in functionlityTypes)
            {
                var infoPropInfo = funcType.GetRuntimeProperties().Where(p => p.Name == "Info").First();
                var staticInfoObj = infoPropInfo.GetValue(null); // type: DescribeMyFunctionality<InputParams>

                // List<FunctionalityInfo<T>>
                var methods = funcType.GetMethods(BindingFlags.Instance | BindingFlags.Public)
                                      .Where(m => !excludedMethod.Any(n => n == m.Name));
                var ti = new TabItemRepresenter(funcType, funcType, methods);
                Tabs.Add(ti);
            }
            */
        }
    }

    public sealed class TabItemRepresenter
    {
        public TabItemRepresenter()
        {

        }
        public TabItemRepresenter(Type funcType, Type implementationType, IEnumerable<MethodInfo> methodInfos)
        {
            Header = funcType.Name;
            var infoPropInfo = implementationType.GetRuntimeProperties().Where(p => p.Name == "Info").First();

            var staticInfoObj = infoPropInfo.GetValue(null); // type: DescribeMyFunctionality<InputParams>
            Type typeOfInputParams = infoPropInfo.PropertyType.GenericTypeArguments[0]; // InputParams
            var genericBase = typeof(DescribeMyFunctionality<>);
            var combinedType = genericBase.MakeGenericType(typeOfInputParams);
            var inputParamsInstance = Activator.CreateInstance(combinedType);
            var describeAllProperty = inputParamsInstance.GetType().GetRuntimeProperties().First(p => p.Name == "DescribeAll");
            var describeAll = describeAllProperty.GetValue(staticInfoObj).ToString();

            var functionalitiesProperty = inputParamsInstance.GetType().GetRuntimeProperties().First(p => p.Name == "Functionalities");
            var functionalitiesValue = functionalitiesProperty.GetValue(staticInfoObj); // as List<FunctionalityParamsBase>;

            //foreach (var item in functionalitiesValue)
            {

            }

            var getSampleInputMethodInfo = inputParamsInstance.GetType().GetRuntimeMethods().First(m => m.Name == "GetSampleInput");

            Buttons = new List<ButtonRepresenter>();
            foreach (var m in methodInfos)
            {
                var vvv = getSampleInputMethodInfo.Invoke(staticInfoObj, new object[] { m.Name });
                //var describeFunction = getSampleInputInc.Invoke(inputParamsInstance, new object[] { "Convert" });
                // Buttons.Add(new ButtonRepresenter(m.Name, describeAll, "TT"));
            }
        }

        public string Header { get; set; }
        public Type ImplementationType { get; set; }
        public string ExecuteMethod { get; set; }
        public List<ButtonRepresenter> Buttons { get; set; }
        public IEnumerable<InputParamsBase> Params { get; internal set; }
    }

    public sealed class ButtonRepresenter
    {
        public string Name { get; set; }
        public IEnumerable<InputParamsBase> Tag { get; set; }
        public string ToolTip { get; set; }
        public ButtonRepresenter(string name, IEnumerable<InputParamsBase> predefinedParams, string toolTip)
        {
            Name = name;
            Tag = predefinedParams;
            ToolTip = toolTip;
        }


    }

}
