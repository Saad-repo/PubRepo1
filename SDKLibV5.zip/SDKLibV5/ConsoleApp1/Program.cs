﻿using SDKLibV5;
using SDKLibV5.Functionality;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;

namespace ConsoleApp1
{

    class Program
    {
        static void Main(string[] args)
        {
            // MarkDown2Html markDown2Html = new();

            //markDown2Html.ConvertMd2Html(null, null);

            //Console.WriteLine(MarkDown2Html.Info.DescribeAll);


            // TabItem's header contains a TextBlock -- the Tag of which is the Type of implementing class


        }
    }



    public class RegularCls2
    {
        public virtual void MyMethod2()
        {
            var tst = System.Security.Cryptography.MD5.Create();
            // tst.ComputeHash
        }
    }
}
