S
O
L
I
D
==================

+ Use solid to achieve maintainability/extensibility/understand
+ Adherence to SOLID does require more spending more time writing the code but it results in spending less time reading it.
+ SOLID is a tool not a goal or rule.




**Single Responsibility Principle / SRP** -- a class should only do one thing
Small classes with very specific names
* So, instead of having a few big classes, your code should have many smaller classes
* Each of your classes should know as little as possible
* Note: Single responsibility applies to methods too.

**Open/Closed principle**
* You code should be open for extension Closed for modification
  * You can modify code by adding new classes as opposed to modifying the existing classes
  * You simple write wrappers to get the code to do what you need
* Example: if your payment logic has payment types hard coded, that scenario requires changes to this logic for introducing new payment types. That's a violation of the Open/Closed principle
    * Fix: use factory pattern

**Liskov substitution**
* Introduced by Barbara Liskov
* Any derived class should be able to substitute its parent class without the consumer knowing it
* Every class that implements an interface must be able to substitute any reference throughout the code that implements that same interface
* Every part of the code should get the expected result no matter what instance of a class you send to it, given it implements the same interface.
* Example: Changing your persistence layer -- changing from file system storage to DB storage

**Interface Segregation**
* No client should be forced to depend on methods/properties/... it does not use
* Changing one method in  a class shouldn't affect classes that don't depend on it
* Replace fat interfaces with many small, specific interfaces

**Dependency inversion**
* High-level modules should not depend on low-level modules. Both should depend on abstractions.
* Never depend on anything concrete, only depend on abstractions
* Purpose: Able to change an implementation easily without altering the high level code





