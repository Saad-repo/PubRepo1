﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SDKLibV5.Functionality;
using SDKWebApi.Models;

namespace SDKWebApi.Services
{
    internal sealed class EventsService
    {
        private static string dbFilePath = @"C:\SDK\MyData\SDKs_DB.db3";

        internal static IEnumerable<Models.SdkEvent> GetEvents()
        {
            SqLiteOps sqLiteOps = new();
            return sqLiteOps.GetEvents(new SqLiteOps.InputParams(dbFilePath)).Select(x => Convert(x));
        }

        internal static IEnumerable<Models.SdkEvent> GetEventsByNote(string noteKeyword)
        {
            SqLiteOps sqLiteOps = new();
            return sqLiteOps.GetEvents(new SqLiteOps.InputParams(dbFilePath))
                            .Where(e => e.Notes.IndexOf(noteKeyword, StringComparison.OrdinalIgnoreCase) != -1)
                            .Select(x => Convert(x));
        }

        internal static int SaveEvent(SdkEvent sdkEvent)
        {
            SqLiteOps sqLiteOps = new();
            return sqLiteOps.SaveEvent(dbFilePath, sdkEvent.ToDomain());
        }

        internal static int DeleteEvent(int eventId)
        {
            SqLiteOps sqLiteOps = new();
            return sqLiteOps.DeleteEvent(dbFilePath, eventId);
        }

        private static Models.SdkEvent Convert(SqLiteOps.SdkEvent sdkEvent)
        {
            return new Models.SdkEvent
            {
                EventId = sdkEvent.EventId,
                EventDt = sdkEvent.EventDt,
                Notes = sdkEvent.Notes
            };
        }
    }
}
