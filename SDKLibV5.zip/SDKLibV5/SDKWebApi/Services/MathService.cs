﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SDKLibV5.Functionality;

namespace SDKWebApi.Services
{
    public class MathService
    {
        public static IEnumerable<ulong> GetFibs(int count)
        {
            SDKLibV5.Functionality.Math math = new();
            return math.FibonacciNums(new SDKLibV5.Functionality.Math.InputParams() { Format = "txt", UpTo = count });
        }
    }
}
