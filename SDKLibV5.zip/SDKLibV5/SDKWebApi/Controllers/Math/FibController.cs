﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace SDKWebApi.Controllers.Math
{
    [Route("api/[controller]")]
    [ApiController]
    public class FibController : ControllerBase
    {
        // GET: api/<FibController>
        [HttpGet]
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        [HttpGet("{parOne}/{parTwo}")]
        public string GetTwo(int parOne)
        {
            return "value1";
        }

        // GET api/<FibController>/5
        [HttpGet("{id}")]
        public IEnumerable<ulong> GetFib(int id)
        {
            return Services.MathService.GetFibs(id);
            // return "value";
        }

        // POST api/<FibController>
        [HttpPost]
        public void Post([FromBody] string value)
        {
        }

        // PUT api/<FibController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/<FibController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
