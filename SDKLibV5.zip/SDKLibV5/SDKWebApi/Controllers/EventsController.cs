﻿using Microsoft.AspNetCore.Mvc;
using SDKLibV5.Functionality;
using SDKWebApi.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SDKWebApi.Models;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace SDKWebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EventsController : ControllerBase
    {
        // GET: api/<EventsController>
        [HttpGet]
        public IEnumerable<SdkEvent> Get()
        {
            return EventsService.GetEvents();
        }

        // GET api/<EventsController>/5
        [HttpGet("{id}")]
        public string Get(int id)
        {
            return "value";
        }

        // GET api/<EventsController>/5
        [HttpGet("search")]
        public IEnumerable<SdkEvent> Get([FromQuery] string searchEvent)
        {
            return EventsService.GetEventsByNote(searchEvent);
        }

        // POST api/<EventsController>
        [HttpPost]
        public int Post([FromBody] SdkEvent value)
        {
            value.EventDt = value.EventDt.ToLocalTime();
            return EventsService.SaveEvent(value);
        }

        // PUT api/<EventsController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/<EventsController>/5
        [HttpDelete("{id}")]
        public int Delete(int id)
        {
            return EventsService.DeleteEvent(id);
        }
    }
}
