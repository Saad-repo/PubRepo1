﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SDKWebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class HeroesController : ControllerBase
    {
        private Stack<Hero> stackOfHeros = new();

        public HeroesController()
        {
            stackOfHeros.Push(new Hero { Id = 11, Name = "One" });
            stackOfHeros.Push(new Hero { Id = 12, Name = "Two" });
            stackOfHeros.Push(new Hero { Id = 13, Name = "Three" });
            stackOfHeros.Push(new Hero { Id = 14, Name = "Four" });
            stackOfHeros.Push(new Hero { Id = 15, Name = "Five" });
            stackOfHeros.Push(new Hero { Id = 16, Name = "Six" });
            stackOfHeros.Push(new Hero { Id = 17, Name = "Seven" });
            stackOfHeros.Push(new Hero { Id = 18, Name = "Eight" });
            stackOfHeros.Push(new Hero { Id = 19, Name = "Nine" });
        }

        [HttpGet]
        public IEnumerable<Hero> Get()
        {
            return stackOfHeros;
        }


        // GET api/<EventsController>/5
        [HttpGet("{id}")]
        public Hero Get(int id)
        {
            return stackOfHeros.Where(h => h.Id == id).FirstOrDefault();
        }

    }

    public class Hero
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
