﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SDKLibV5.Functionality;

namespace SDKWebApi.Models
{
    public class SdkEvent
    {
        public int? EventId { get; set; }

        public DateTime EventDt { get; set; }

        public string Notes { get; set; }

        internal SqLiteOps.SdkEvent ToDomain()
        {
            return new SqLiteOps.SdkEvent
            {
                EventDt = EventDt,
                EventId = EventId,
                Notes = Notes
            };
        }
    }
}
