using SDKLibV5;
using SDKLibV5.Functionality;
using System;
using System.Text.RegularExpressions;
using Xunit;

namespace SDKLibV5_Tests
{
    public class MarkDown2Html_Tests
    {
        [Fact]
        public void ToHTML_WhenHasTitle_ShouldContainTitleTag()
        {
            // Arrange
            var title = "<title>Visual Studio Notes</title>";
            var pattern = @"<title>(\w+\s*)+</title>";
            var rgx = new Regex(pattern, RegexOptions.IgnoreCase);

            var mdContent = @$"{title}

Visual Studio Notes
=========================================

https://docs.microsoft.com/en-us/visualstudio/ide/walkthrough-creating-a-code-snippet?view=vs-2019


How to add a new code snippet
----------------------------------------------

1. Create a new XML file in Visual Studio and add the following template.
";
            MarkDown2Html m2h = new(mdContent);

            // Act 
            var htmlContent = m2h.ToHTML(true);

            // Assert
            Assert.Contains(title, htmlContent);
            Assert.Single(rgx.Matches(htmlContent));
        }
    }
}
