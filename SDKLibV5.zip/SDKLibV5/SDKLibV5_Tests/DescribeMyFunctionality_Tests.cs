﻿using SDKLibV5;
using SDKLibV5.Functionality;
using System;
using System.Runtime.CompilerServices;
using Xunit;


namespace SDKLibV5_Tests
{
    public class DescribeMyFunctionality_Tests
    {
        #region FunctionalityParamsBase class tests
        // Note: Normally we don't use Regions like this. In this case we are handling multiple class in the same source file
        [Fact]
        public void FromString_ValidInputString_ShouldProduceInputParamsObj()
        {
            // Arrange
            string inputMdFile = "c:\\temp\\file3.md";
            string outputHtmlFile = "c:\\temp\\output\\file3.html";
            string inputString = @$"========[ MarkDown2Html ]==========
This class provides an implementation for converting MD content to HTML content

CONVERTMD2HTML: Makes a cup of coffee
--------------------------
Parameters---
        MdFileFullPath: {inputMdFile}
        HtmlOutputFile: {outputHtmlFile}
";
            var inputParamsEmpty = new MarkDown2Html.InputParams(@"C:\temp\f1.md");

            // Act
            var inputParamsPopulated = InputParamsBase.FromString(inputString, inputParamsEmpty)
                as MarkDown2Html.InputParams;

            // Assert
            Assert.True(inputParamsPopulated is MarkDown2Html.InputParams);
            Assert.Equal(inputMdFile, inputParamsPopulated.MdFileFullPath);
            Assert.Equal(outputHtmlFile, inputParamsPopulated.HtmlOutputFile);
        }

        #endregion

    }
}
